# Phoenix v0.18 for Atari 5200

Phoenix for an NTSC Atari 5200 with 16 KiB RAM. This 256 KiB CAR type 73 cartridge includes the repeating five-wave game: two small-bird waves, two large-bird waves and the mothership, followed by harder cycles.

[Current cartridge](Phoenix5200.car) · [Source and tests](Phoenix5200-Source-and-Tests.zip)

## Changes in v0.18

- GAME OVER flashes for three seconds. Fire cannot restart during that interval; afterward, release fire and press again to restart.
- Restart blanks the display, clears both screen buffers and restores the display only after the first complete new frame. Old mothership tiles no longer appear during the redraw.
- The mothership uses the arcade's separate particle burst and pink core animation, followed by the red bonus and scrolling starfield. The bonus stays in its original screen position. The original 96-tick destruction and 64-tick award sequence are retained.

The animation uses the original particle and core tables, with all 63 visual snapshots and no vertical compression. Horizontal pairs are quantized for the Atari display; red particles share pink because of the available playfield colors.

`Phoenix5200-Preview.mp4` is a 21-second Altirra capture of staged victory and game-over/restart tests. Its scene setup uses RAM fixtures; the full controller-only completion test is recorded separately in the evidence. Video audio is the game's native output with a 6 dB volume increase.

## Changes in v0.17

Equal three-pixel gaps between all seven letters. P has one-pixel horizontal gaps after its first and second birds only. Existing one-pixel gaps within H, O and E remain.

## Changes in v0.16

- The shield uses all 32 original arcade rows again. Removing the old 24-row vertical compression restores its round outline. All four animation frames fit within the screen and clear completely on expiry.
- H, O and E in the bird-built title have one empty native pixel column between horizontally adjacent birds. The original gameplay sprites, pink wings, green centers, tall P and flat large bird are retained.

![Shield in the emulator](shield.png)

## Changes in v0.15

- The ship is eight pixels higher. Its shots, shield, collision checks and explosion move with it.
- A small bird returning from a fully hidden bottom or side position near the ship enters in a clear lane. The check uses the current ship position, preserves the bird's fine animation phase and keeps it shootable. Already visible dives continue normally; this is entry protection, not player invulnerability.
- The mothership has four replenishing escorts. They accelerate when fewer than three remain, and replacements start at normal speed. Ordinary small-bird waves retain their previous acceleration threshold.
- Large-bird flight and wing damage are unchanged. Their ship-contact checks follow the raised player.

Score explanations, audio, wave colors and wipe transitions are retained.

![Title screen](title.png)
![Score table](scores.png)

## Controls and game

Move with the joystick. The lower fire button starts and shoots; release and press again for each shot. After GAME OVER, wait three seconds, release fire and press again to restart. The upper button activates the shield. The test keyboard mapping uses Left/Right, Left Ctrl for fire, and Left Shift for shield.

There are sixteen small birds, six large birds, and four replenishing mothership escorts. The mothership has destructible armor, a moving barrier, a pilot hit gate and a victory sequence. Opening/victory music and effects use POKEY arrangements of recovered arcade data. Large-bird waves have bird tones over a black background, without an added continuous melody. Atari colors and sound approximate the arcade hardware.

## Verification

The final v0.18 cartridge passed the following checks. Reports and controller inputs are in `evidence/current`.

- The three-second delay, flashing banner, held-fire lockout and release/new-press rule passed focused CPU tests and actual Altirra input checks.
- Actual emulator captures showed a blank interval followed by clean screen buffers during restart; no old mothership tiles remained.
- The ending tables matched 17,120 original MAME tile observations. All 189 rendered scenes (63 animation snapshots at three mothership heights) passed pixel checks without layout faults. Bonus position, timing and 32-pixel starfield scroll passed.
- 411 campaign checks covered 16 rounds, armor/barrier collisions, entry, victory and the next-wave transition.
- A cold-boot controller-only run completed all five waves, destroyed the mothership and entered wave six with two lives remaining. RAM was observed for targeting but was never written; there were no stage skips, loaded states or invulnerability.

Earlier title checks are retained in `evidence/v017`; gameplay, shield and performance checks from v0.16 are retained in `evidence/v016`. These historical reports identify their own cartridge hashes. The v0.18 changes retain the corrected title spacing, round shield, raised ship, safe small-bird returns and four mothership escorts.

Validation used AltirraSDL and focused CPU tests, not a physical 5200. The mothership renderer updates less frequently than bird waves; input, audio and simulation continue on their existing clocks.

## Build and tests

Use LLVM-MOS SDK v23.4.0 (clang 24.0.0git, commit `a40207a371b60ff787ece46817d9c0f62eada719`) and Python 3. CPU tests require `py65`; pixel tests also require `numpy` and `Pillow`.

```sh
export LLVM_MOS=/absolute/path/to/llvm-mos
python tools/build.py
mkdir -p evidence/v018 evidence/v016 evidence/v015 evidence/v013 evidence/v011
python tests/endings_v018.py
python tests/shield_v016.py
python tests/changes_v015.py
python tests/escort_collision_v013.py
python tests/renderer_native.py
python tests/flight_acceptance.py
python tests/campaign_cache.py
python tests/campaign_acceptance.py
```

The build output is `build/Phoenix-First-Flight.car`; `Phoenix5200.car` is the release copy. Eight 32 KiB banks retain identical fixed lower 16 KiB and vectors. Checksums are in `SHA256SUMS.txt`.

For emulator checks use AltirraSDL commit `6ec52575a851e160df070733bd43f955572db5dc` with the included frontend pipe patch, which changes test transport only. Set `ALTIRRA_BRIDGE_SDK` to its Python SDK and `ATARI5200_BIOS` to an original BIOS with SHA-256 `06b250f18983d058c0f156ce7ee88ae48b6eaf11e6f10f21dccf6ac7ffb6a6af`.

```sh
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
python tests/endings_capture.py --out tests/new-endings --exe /absolute/path/to/AltirraSDL
python tests/presentation_v013.py --out tests/new-presentation --exe /absolute/path/to/AltirraSDL
python tests/shield_v016.py --out tests/new-shield --exe /absolute/path/to/AltirraSDL
python tests/play_campaign.py --out tests/new-playthrough --exe /absolute/path/to/AltirraSDL --frames 26000 --opening-delay 640 --goal-wave 6 --record
```

Original BIOS, full arcade ROMs, emulator binaries, local configuration and authentication logs are excluded. Source notices are preserved in `src/arcade-assets` and `reference/notices`.
