local m=manager.machine;local mem=m.devices[':maincpu'].spaces['program'];local scr=m.screens[':screen']
local out=assert(io.open(os.getenv('PHX_OUT')..'/trace.bin','wb'));local n=0;local large_start=0
local fields={}
for tag,p in pairs(m.ioport.ports) do for name,f in pairs(p.fields) do fields[name]=f end end
local function set(k,v) if fields[k] then fields[k]:set_value(v and 1 or 0) end end
print('PERIOD',scr.frame_period)
for _,tag in ipairs({':DSW0',':CAB'}) do
 for name,f in pairs(m.ioport.ports[tag].fields) do print('SETTING',name,f.user_value,f.settings and f.settings[f.user_value]) end
end
local seedfile=assert(io.open(os.getenv('PHX_OUT')..'/seed.bin','rb'));local seed=seedfile:read('*a');seedfile:close()
local start=0;local fixture=0
emu.register_frame_done(function()
 n=n+1
 set('Coin 1',n>=120 and n<125);set('1 Player Start',n>=180 and n<185)
 if n==200 then start=1 end
 if start==1 then
  if fixture==0 or n%900==200 then
   fixture=fixture+1
   if fixture>16 then out:close();m:exit();return end
   for i=0,3071 do mem:write_u8(0x4000+i,string.byte(seed,i+1)) end
   local count=8-((fixture-1)%8);local round=fixture<=8 and 5 or 7
   mem:write_u8(0x43b8,round);mem:write_u8(0x43bb,count);mem:write_u8(0x43ba,0)
   mem:write_u8(0x439a,0);mem:write_u8(0x439b,0);mem:write_u8(0x43b9,0)
   for a=0x4bd0,0x4bd7 do mem:write_u8(a,0) end
   for a=0x436d,0x436f do mem:write_u8(a,0) end
   for i=0,63 do mem:write_u8(0x4b70+i,mem:read_u8((round==5 and 0x3f80 or 0x3fc0)+i)) end
   for i=count,7 do mem:write_u8(0x4b70+i*8,0) end
  end
  mem:write_u8(0x43a4,3);mem:write_u8(0x43a6,0);mem:write_u8(0x43c2,100)
  mem:write_u8(0x43c6,0)
  for a=0x43cc,0x43dc,4 do mem:write_u8(a,0) end
  set('P1 Button 1',false);set('P1 Left',false);set('P1 Right',false)
  out:write(string.pack('<I4',n),mem:read_range(0x4000,0x4bff,8))
 end
end)
