local m=manager.machine
local cpu=m.devices[':maincpu'];local mem=cpu.spaces['program']
local f=assert(io.open(os.getenv('PHOENIX_FIXTURE'),'rb'));local data=f:read('*a');f:close()
local frame=0
emu.register_frame_done(function()
 frame=frame+1
 if frame==30 then
  mem:write_u8(0x5000,2)
  for i=1,#data do mem:write_u8(0x3fff+i,data:byte(i)) end
  cpu.state['SP'].value=0x4bff;cpu.state['PC'].value=0x001d
 elseif frame==32 then
  m.screens[':screen']:snapshot(os.getenv('PHOENIX_PNG'))
  m:exit()
 end
end)
