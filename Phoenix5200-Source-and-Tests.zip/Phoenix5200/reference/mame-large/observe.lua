local m=manager.machine;local mem=m.devices[':maincpu'].spaces['program'];local scr=m.screens[':screen']
local out=assert(io.open(os.getenv('PHX_OUT')..'/trace.bin','wb'));local n=0;local large_start=0
local fields={}
for tag,p in pairs(m.ioport.ports) do for name,f in pairs(p.fields) do fields[name]=f end end
local function set(k,v) if fields[k] then fields[k]:set_value(v and 1 or 0) end end
print('PERIOD',scr.frame_period)
for _,tag in ipairs({':DSW0',':CAB'}) do
 for name,f in pairs(m.ioport.ports[tag].fields) do print('SETTING',name,f.user_value,f.settings and f.settings[f.user_value]) end
end
emu.register_frame_done(function()
 n=n+1
 set('Coin 1',n>=120 and n<125);set('1 Player Start',n>=180 and n<185)
 local px=mem:read_u8(0x43c2);local goal=100;local best=999;local threat=false
 for a=0x4b70,0x4bac,4 do
  if (mem:read_u8(a)&8)~=0 then
   local x=mem:read_u8(a+2);local y=mem:read_u8(a+3);local cost=math.abs(x-px)
   if x>=12 and x<=192 and cost<best then best=cost;goal=x end
   if y>185 and math.abs(x-px)<20 then threat=true end
  end
 end
 for a=0x43cc,0x43dc,4 do
  if (mem:read_u8(a)&8)~=0 and mem:read_u8(a+3)>180 and math.abs(mem:read_u8(a+2)-px-4)<12 then threat=true;goal=px<100 and px+28 or px-28 end
 end
 if n<850 then goal=192 elseif n<1040 then goal=12 end
 set('P1 Right',px<goal);set('P1 Left',px>goal)
 set('P1 Button 2',n>1040 and threat and mem:read_u8(0x43a6)==0 and n%2==0)
 set('P1 Button 1',n>1040 and n%6<3)
 out:write(string.pack('<I4',n),mem:read_range(0x4000,0x4bff,8))
 if (n>=300 and n<580 and n%12==0) or (mem:read_u8(0x43b8)==2 and n%8==0) or (mem:read_u8(0x43b8)==3 and n%60==0) then scr:snapshot(os.getenv('PHX_OUT')..string.format('/frame-%04d.png',n)) end
 if mem:read_u8(0x43b8)>=4 and large_start==0 then large_start=n end
 if mem:read_u8(0x43b8)>=4 and n%12==0 then scr:snapshot(os.getenv('PHX_OUT')..string.format('/large-%05d.png',n)) end
 if n==20000 or (large_start>0 and n>=large_start+4000) then out:close();m:exit() end
end)