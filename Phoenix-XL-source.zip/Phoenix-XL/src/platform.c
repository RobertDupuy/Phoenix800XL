#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "arcade/phoenix_state.h"
#include "arcade/phoenix_hw.h"
PhoenixState state __attribute__((section(".state")));
volatile uint8_t frame_tick,render_tick,missed_frames,game_due;
volatile uint16_t logic_tick,dropped_ticks;
uint16_t tv_period,clock_phase;
uint8_t pal_mode;
extern void pm_update(void);
uint8_t g_vram_page,g_palette_bank,g_scroll;
volatile uint8_t g_sound_a,g_sound_b;
extern uint8_t full_dirty;
extern void video_init(void),render_frame(void);
#define HW(a) (*(volatile uint8_t*)(a))
#define OTHER ((uint8_t*)0xc000)
void hw_write_video_register(uint8_t val) {
 uint16_t i;uint8_t t;
 if((val&1)!=g_vram_page){
  for(i=0;i<sizeof(state);i++){t=((uint8_t*)&state)[i];((uint8_t*)&state)[i]=OTHER[i];OTHER[i]=t;}
  g_vram_page=val&1;full_dirty=1;
 }
 g_palette_bank=(val>>1)&1;
}
void copy_memory_bank(uint8_t from,uint8_t to){
 uint8_t *s=from==g_vram_page?(uint8_t*)&state:OTHER;
 uint8_t *d=to==g_vram_page?(uint8_t*)&state:OTHER;
 uint16_t i;
 for(i=0;i<832;i++)if((i&31)<4)d[i]=s[i];
 for(i=0x380;i<0x3b8;i++)d[i]=s[i];
 for(i=0xbc0;i<0xc00;i++)d[i]=s[i];
 hw_write_video_register(to);
}
void hw_toggle_palette_bank(void){g_palette_bank^=1;}
void hw_write_scroll_register(uint8_t v){g_scroll=v;}
void hw_write_sound_a(uint8_t v){g_sound_a=v;}
void hw_write_sound_b(uint8_t v){g_sound_b=v;}
uint8_t hw_read_dsw(void){return 0;}
bool hw_is_vblank(void){return false;}
static void inputs_init(void){
 /* Own the joystick port after the OS is disabled. Bit 2 selects the PIA
    data-direction register; zero makes all eight joystick pins inputs. */
 HW(0xd302)=0x38;
 HW(0xd300)=0;
 HW(0xd302)=0x3c;
}
uint8_t hw_read_inputs(void){
 uint8_t b=255,j=HW(0xd300),k=HW(0xd01f);
 /* Poll the current active-low joystick pins every game tick.
    Direction has no history, edge detection, latch or repeat timer. */
 if(!(j&4)) b&=~BTN_LEFT;
 if(!(j&8)) b&=~BTN_RIGHT;
 if(!(j&2)) b&=~BTN_SHIELD;
 if(!(HW(0xd010)&1)) b&=~BTN_FIRE;
 if(!(k&1))b&=~BTN_START_1P;
 if(state.GameOrAttract==0 && (!(k&1)||!(HW(0xd010)&1))){b&=~BTN_START_1P;if(state.CoinCount==0)b&=~BTN_COIN;}
 if(!(k&2))b&=~BTN_COIN;
 if(!(k&4))b&=~BTN_START_2P;
 return b;
}
void platform_ram_dump_hook(void){}
void platform_audio_frame_hook(void){}
bool platform_wait_vblank(void){
 static uint8_t begun,last_render,burst;
 pm_update();
 if(!begun){begun=1;render_frame();game_due=0;last_render=frame_tick;}
 if(burst>=8 || (uint8_t)(frame_tick-last_render)>=2 && game_due<=1){
  render_frame();last_render=frame_tick;burst=0;
 }
 while(!game_due){}
 /* A single 6502 instruction cannot lose a VBI increment between a load
    and store. SEI would not protect this counter from NMI. */
 __asm__ volatile("dec game_due" ::: "memory");
 burst++;logic_tick++;
 if(game_due>missed_frames)missed_frames=game_due;
 return true;
}
extern void phoenix_main_loop(void);
int main(void){
 pal_mode=(HW(0xd014)&15)==1;tv_period=pal_mode?12764:15340;
 inputs_init();
 memset(OTHER,0,0xc00);
 video_init();
 phoenix_main_loop();
 return 0;
}
void sound_set_frame_sample_index(uint16_t s){(void)s;}
