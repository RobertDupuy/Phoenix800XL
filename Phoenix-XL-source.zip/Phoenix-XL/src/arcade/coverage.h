#ifndef COVERAGE_H
#define COVERAGE_H
#define coverage_hit(x) ((void)0)
#endif
