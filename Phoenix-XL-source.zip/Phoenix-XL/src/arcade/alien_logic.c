#include "alien_logic.h"
#include "utilities.h"
#include "z80_core.h"
#include "phoenix_tables.h"
#include <stdio.h>
#include <stdbool.h>

extern PhoenixState state;

// Stubs for external logic routines
extern void update_screen_objects(uint16_t alien_state_addr, uint16_t screen_ram_addr); // L0718
extern void get_screen_ram_address(uint16_t alien_state_addr, uint16_t screen_ram_addr); // L09BA

/*
 * Translates L05EC
 * Initialize alien control states.
 * [ASM: 05EC-05F9]
 */
void init_alien_control_states(void) {
    uint8_t index = state.LevelAndRound & 0x0F;
    extern const uint8_t phoenix_alien_control_init_values[0x20];
    uint8_t d = phoenix_alien_control_init_values[index * 2];
    uint8_t e = phoenix_alien_control_init_values[index * 2 + 1];
    init_alien_control_states_05fa(d, e);
}

/*
 * Translates GetAnimationChrs for 'aliens fade in'
 * [ASM: 085A-0871]
 */
uint8_t get_animation_chrs_aliens_fade_in(void) {
    uint8_t a = state.CounterB4;
    if (a >= 0x11) return 0x6C;
    if (a >= 0x0D) return 0x6D;
    if (a >= 0x09) return 0x6E;
    if (a >= 0x05) return 0x6F;
    return 0x68;
}

/*
 * [ASM: 0FD8-0FEF]
 */
static void l0fd8(uint16_t hl) {
    uint8_t a = mem_read(hl);
    if (a == 0) return;

    uint8_t b = a;
    mem_write(hl, a - 1); // DEC (HL)

    hl += 2; // INC L, INC L
    uint8_t d = mem_read(hl);
    hl++; // INC L
    uint8_t e = mem_read(hl);

    uint16_t de = (d << 8) | e;

    extern uint16_t left_one_column(uint16_t de);
    de = left_one_column(de);

    uint8_t offset = (b & 0x0E) >> 1; // RRCA on an already-even value == >>1
    extern const uint8_t phoenix_alien_explosion_frames[0x08];
    uint8_t img = phoenix_alien_explosion_frames[offset];
    uint16_t img_addr = 0x1700 | img;

    // 0FF0: EX DE,HL -- de (screen target) becomes HL, img_addr (source)
    // becomes DE for Draw3x2 (L3540, entered via drawNx2 with n=3,
    // BC=$FFDF=-33). The earlier translation instead called
    // draw_image_c_by_b(img_addr, de-0x21, 2, 3), which is not what this
    // ASM does at all: there is no "-0x21 to the target" step here, and
    // Draw3x2 draws 3 row-pairs (2 bytes each) stepping HL by BC=-33
    // between pairs, then blanks a trailing pair -- exactly drawNx2(n=3).
    extern void drawNx2(uint16_t de, uint16_t hl, uint16_t bc, int n);
    drawNx2(img_addr, de, 0xFFDF, 3);
}

/*
 * Translates L37CC
 * Erases the bonus explosion animation once its counter reaches zero,
 * by blanking a full column (26 rows) of the foreground.
 * [ASM: 37CC-37E5]
 */
static void l37cc_erase_bonus_explosion(uint16_t hl) {
    uint8_t a = mem_read(hl + 3); // LSB of the screen anchor
    a = (uint8_t)((a & 0x1F) + 0x20);
    uint16_t addr = (uint16_t)(0x4300 | a);

    for (uint8_t count = 0x1A; count != 0; count--) {
        mem_write(addr, 0);
        addr++;
        mem_write(addr, 0);
        addr = (uint16_t)(addr + 0xFFDF); // ADD HL,BC (-33)
    }
}

/*
 * Translates L3796
 * Draws the left part of the bonus explosion animation.
 * [ASM: 3796-37AA]
 */
static void l3796_bonus_explosion_left(uint8_t a, uint16_t de) {
    extern void drawNx2(uint16_t de, uint16_t hl, uint16_t bc, int n);

    uint16_t hl = (uint16_t)(((uint16_t)a + 0x60) + de);
    if ((uint32_t)hl + 0xBCC0 > 0xFFFF) return; // RET C: out of range, skip

    drawNx2(0x17D0, hl, 0xFFDF, 3); // Draw3x2, T17D0 (left part)
}

/*
 * Translates the tail of L3758 (3772-3792)
 * Draws the right part of the bonus explosion animation.
 * [ASM: 3772-3792]
 */
static void l3758_bonus_explosion_right(uint8_t a, uint16_t de) {
    extern void drawNx2(uint16_t de, uint16_t hl, uint16_t bc, int n);

    uint16_t target = (uint16_t)(de - a);
    if ((uint32_t)target + 0xBFA0 <= 0xFFFF) return; // RET NC: out of range, skip

    mem_write(target, 0);
    target++;
    mem_write(target, 0);
    target = (uint16_t)(target + 0xFFDF); // ADD HL,BC (-33)

    drawNx2(0x17D6, target, 0xFFDF, 3); // Draw3x2, T17D6 (right part)
}

/*
 * Translates L37B0
 * Prints the score value in the middle of the bonus explosion
 * animation. The first two digits come from the stored score byte;
 * the last digit is always '0'.
 * [ASM: 37B0-37C6]
 */
static void l37b0_print_bonus_score(uint16_t hl) {
    extern uint16_t left_one_column(uint16_t de);
    extern uint16_t right_one_column(uint16_t de);
    extern void print_number(uint16_t screen_addr, uint16_t data_addr, uint8_t digits);

    uint16_t score_addr = hl + 1;
    uint8_t a = mem_read(score_addr);
    // DAA: flags coming in are always N=0, H=0, C=0 (from the caller's RRCA)
    if ((a & 0x0F) > 0x09) a = (uint8_t)(a + 0x06);
    if (a > 0x99) a = (uint8_t)(a + 0x60);
    mem_write(score_addr, a);

    uint8_t d = mem_read(hl + 2);
    uint8_t e = mem_read(hl + 3);
    uint16_t de = (uint16_t)((d << 8) | e);

    de = right_one_column(de);
    if (de >= 0x4000 && de < 0x4400) mem_write(de, 0x20); // rightmost digit is always '0'
    de = left_one_column(de);

    print_number(de, score_addr, 2);
}

/*
 * Translates L3758
 * Advances the bonus explosion animation for a killed (grown) bird.
 * base is 0x4378 or 0x437C. While the counter is odd, draws the
 * left/right explosion halves; on even counts, prints the score;
 * once it reaches zero, erases the animation.
 * [ASM: 3758-37CC]
 */
static void l3758_bonus_explosion_animation(uint16_t hl) {
    if (mem_read(hl) == 0) return;

    mem_write(hl, mem_read(hl) - 1);
    uint8_t counter = mem_read(hl);
    if (counter == 0) {
        l37cc_erase_bonus_explosion(hl);
        return;
    }

    if ((counter & 0x01) == 0) {
        l37b0_print_bonus_score(hl);
        return;
    }

    uint8_t a = (uint8_t)(((0x0F - counter) & 0x0E) << 4);
    uint8_t d = mem_read(hl + 2);
    uint8_t e = mem_read(hl + 3);
    uint16_t de = (uint16_t)((d << 8) | e);

    l3796_bonus_explosion_left(a, de);
    l3758_bonus_explosion_right(a, de);
}

/*
 * Translates L0FC0
 * Handles explosion animations for killed aliens
 * [ASM: 0FC0-0FFF]
 */
void handle_animations_for_killed_aliens(void) {
    l0fd8(0x4370);
    l0fd8(0x4374);
    l3758_bonus_explosion_animation(0x4378);
    l3758_bonus_explosion_animation(0x437C);
}

/*
 * Translates L05FA
 * Initialize alien control states (continuation).
 * [ASM: 05FA-060D]
 */
void init_alien_control_states_05fa(uint8_t d, uint8_t e) {
    if (state.AliensLeft == 0) return;
    
    uint16_t hl = 0x4B70;
    int count = state.AliensLeft > 16 ? 16 : state.AliensLeft;
    for (int i = 0; i < count; i++) {
        mem_write(hl, d);
        mem_write(hl + 1, e);
        hl += 4;
    }
}

/*
 * Translates L0610
 * Load alien screen coordinates (X,Y grid), for a new level and round.
 * [ASM: 0610-0638]
 */
void init_alien_positions(void) {
    if (state.AliensLeft == 0) return;
    
    uint8_t index = (state.LevelAndRound >> 1) & 0x0F;
    uint8_t lsb = phoenix_alien_position_pointer_table[index];
    uint8_t page_offset = lsb;

    uint16_t de = 0x4B72;

    int count = state.AliensLeft > 16 ? 16 : state.AliensLeft;
    for (int i = 0; i < count; i++) {
        mem_write(de, phoenix_alien_position_layout_page[page_offset]);
        de++;
        page_offset++;
        mem_write(de, phoenix_alien_position_layout_page[page_offset]);
        de += 3;
        page_offset++;
    }
}

/*
 * Translates L0650
 * Copy init values for 16 aliens.
 * [ASM: 0650-0679]
 */
void copy_init_values_for_16_aliens(void) {
    if (state.AliensLeft == 0) return;
    
    uint8_t index = state.LevelAndRound & 0x0F;
    extern const uint8_t phoenix_alien_layout_pointers[0x20];
    uint8_t d = phoenix_alien_layout_pointers[index * 2];
    uint8_t e = phoenix_alien_layout_pointers[index * 2 + 1];
    
    uint16_t de = 0x4B50;

    int count = state.AliensLeft > 16 ? 16 : state.AliensLeft;
    for (int i = 0; i < count; i++) {
        mem_write(de, d);
        mem_write(de + 1, e);
        de += 2;
    }
}

/*
 * Translates L0A50
 * Handle alien control states for all aliens.
 * Loop goes 20 times for 16 aliens. But bit 3 or 4 is not set at
 * UpdateScreenObjects. So luckily no effect.
 * [ASM: 0A50-0A6B]
 */
void alien_data_controller(void) ; /* native_hot.S */

/*
 * Translates L0A6C
 * Get screen ram adress for all aliens.
 * [ASM: 0A6C-0A99]
 */
/* get_screen_ram_address_for_all_aliens: native_hot.S */

/*
 * Translates L0D1C
 * Alien movement update.
 * [ASM: 0D1C-0D67]
 */
/* alien_movement_update: native_hot.S */

/*
 * Translates L0D70
 * Alien animation update.
 * [ASM: 0D70-0DB5] and [ASM: 0DBB-0DC6] and [ASM: 0DCC-0DEE]
 */
/* alien_animation_update: native_hot.S */

/*
 * Translates L3264
 * Rotate the alien movement start-value pointer LSB (0..15) and, every
 * time $4350 reaches 5, retarget all aliens still running the old
 * pattern (M4394:old LSB) to the new pattern (M4351:M4352) in the
 * pattern pointer table at $4B50-$4B6F.
 * [ASM: 3264-32AF]
 */
void l3264(void) {
    // 3264-326E: save old LSB in M4356, advance LSB modulo 16
    uint8_t old_lsb = state.M4395;
    state.M4356 = old_lsb;
    state.M4395 = (old_lsb + 1) & 0x0F;

    // 326F-3275: only continue every 5th time
    if (state.M4350 < 5) return;
    state.M4350 = 0;

    // 3277-328E: HL = 4B00|M4354, C pairs to scan, B pairs until wrap
    uint8_t c = state.M4353;
    uint8_t l = state.M4354;
    uint8_t d = state.M4356;   // old pattern LSB
    uint8_t e = state.M4394;   // pattern MSB
    uint8_t b = 0x10 - (uint8_t)((uint8_t)(l - 0x50) >> 1);

    if (c == 0) return; // DEC C on 0 would scan 256 pairs; be safe

    // 328F-32AE
    do {
        uint8_t msb_pos = l;
        uint8_t msb = mem_read(0x4B00 | l);
        l++;
        uint8_t lsb = mem_read(0x4B00 | l);
        if (msb == e && lsb == d) {
            mem_write(0x4B00 | msb_pos, state.M4351);
            mem_write(0x4B00 | l, state.M4352);
        }
        l++;
        b--;
        if (b == 0) l = 0x50; // wrap back to $4B50
        c--;
    } while (c != 0);
}

/*
 * Translates L3074
 * Difficulty value for the breakout scheduler: higher levels and fewer
 * aliens give a smaller value (faster breakouts), plus a random 0-7.
 * [ASM: 3074-30A8]
 */
static uint8_t l3074_breakout_delay(void) {
    extern uint8_t get_random_number(void);
    uint8_t lvl = state.LevelAndRound;

    // 3077-3080: C = 7 - (level bits 1-3)
    uint8_t c = (uint8_t)(7 - ((lvl >> 1) & 0x07));

    // 3081-3094: C += 7 - (round nibble, capped at $70 for rounds >= 8)
    uint8_t a = (lvl >= 0x80) ? 0x70 : lvl;
    c = (uint8_t)(c + 7 - ((a >> 4) & 0x07));

    // 3095-30A0: C += AliensLeft - 5, or $10 when fewer than 5 left
    a = state.AliensLeft;
    c = (uint8_t)(c + ((a < 5) ? 0x10 : (uint8_t)(a - 5)));

    // 30A1-30A7: C += random 0-7
    return (uint8_t)(c + (get_random_number() & 0x07));
}

/*
 * Translates L3028 (l3000 dispatch when Counter93 & 7 == 1)
 * Breakout scheduler: counts down M4358 and, when it expires, arms the
 * pattern retargeting that L3264 performs (M4350=4; scan all 16 pattern
 * pointers at $4B50; new pattern MSB M4351=$2E, LSB M4352 depending on
 * the player X parity). At most 3 aliens (M4357) fly out per wave pass.
 * [ASM: 3028-3059] and [ASM: 305C-306D]
 */
void l3028(void) {
    if (state.M4357 >= 3) return;
    if (state.M4350 >= 4) return;

    if (state.M4358 != 0) {
        // 303C-3059: countdown; on expiry arm the retarget pass
        state.M4358--;
        if (state.M4358 != 0) return;
        state.M4357++;
        state.M4350 = 0x04;
        state.M4353 = 0x10;
        state.M4354 = 0x50;
        state.M4351 = 0x2E;
        state.M4352 = 0x00;
        // 3052-3057: RRCA / RET C -- odd player X keeps M4352 at 0
        if ((state.PlayerShipX & 0x01) == 0) {
            state.M4352 = 0x40;
        }
        return;
    }

    // 305C-306D: schedule the next countdown
    uint8_t c = l3074_breakout_delay();
    uint8_t a = state.M4357;
    a = (uint8_t)((a << 2) | (a >> 6)); // RLCA x2
    state.M4358 = (uint8_t)(a + c + 0x07);
}

/*
 * Translates L30BA (l3000 dispatch when Counter93 & 7 == 2)
 * Bomb-drop scheduler. M4359-M435B are three per-bomb countdown slots;
 * M4355 delays arming M4350=1 (which triggers the actual drop pass).
 * [ASM: 30BA-30D8] and [ASM: 30E4-310F] and [ASM: 3112-3121]
 */
void l30ba(void) {
    // 30BD-30C5 (L30DA x3): tick down the nonzero bomb timers
    if (state.M4359 != 0) state.M4359--;
    if (state.M435A != 0) state.M435A--;
    if (state.M435B != 0) state.M435B--;

    // 30C6-30CA: nothing to schedule while a pass is armed
    if (state.M4350 != 0) return;

    if (state.M4355 != 0) {
        // 30D2-30D8: countdown; on expiry arm the drop pass
        state.M4355--;
        if (state.M4355 != 0) return;
        state.M4350 = 0x01;
        return;
    }

    // L30E4: compute the next delay
    uint8_t c = l3074_breakout_delay();
    uint8_t a = state.Counter9A;
    if (a >= 0x10) a = 0x0F;
    c = (uint8_t)(c + 0x0F - a);

    // L3112 x3: give the first free timer slot 0x0C; each free slot
    // seen halves the delay value
    uint8_t b = 1;
    uint8_t* slots[3] = { &state.M4359, &state.M435A, &state.M435B };
    for (int i = 0; i < 3; i++) {
        if (*slots[i] != 0) continue;
        c >>= 1; // RRCA; AND $7F
        if (b == 0) continue;
        b--;
        *slots[i] = 0x0C;
    }

    // 3105-310F
    state.M4355 = (uint8_t)(((c >> 2) & 0x3F) + 1);
}

/*
 * Translates L3124 (l3000 dispatch when Counter93 & 7 == 3)
 * Phase 1 -> 2 of the pattern retarget: decide how many pattern pairs
 * (M4353) the scan in L3264 may touch, based on the round and a random.
 * [ASM: 3124-314E]
 */
void l3124(void) {
    extern uint8_t get_random_number(void);
    if (state.M4350 != 1) return;
    state.M4350 = 0x02;

    // 312D-313B: 5 + round nibble, capped back to 5 at 0x11
    uint8_t a = (uint8_t)(((state.LevelAndRound >> 2) & 0x0F) + 5);
    if (a >= 0x11) a = 0x05;

    uint8_t b = (uint8_t)(a - state.M4357);
    a = (uint8_t)(get_random_number() + 1);
    if (a >= b) a = 0x01;
    state.M4353 = a;
}

/*
 * Translates L315A + L3192 (l3000 dispatch when Counter93 & 7 == 4)
 * Phase 2 -> 3: starting from a random alien, find the first active
 * alien still on the old pattern (M4394:M4356) and remember its pattern
 * pointer position in M4354.
 * [ASM: 315A-318E] and [ASM: 3192-31AD]
 */
void l315a(void) {
    extern uint8_t get_random_number(void);
    if (state.M4350 != 2) return;

    uint8_t rnd = get_random_number();          // 0-15
    uint8_t l = (uint8_t)(rnd * 2 + 0x50);
    uint8_t e = (uint8_t)(rnd * 4 + 0x70);
    uint8_t b = (uint8_t)(0x10 - rnd);          // pairs until wrap

    for (int c = 0x10; c > 0; c--) {
        // L3192
        if (mem_read(0x4B00 | e) & 0x08) {
            if (state.M4394 == mem_read(0x4B00 | l) &&
                state.M4356 == mem_read(0x4B00 | (uint8_t)(l + 1))) {
                state.M4354 = l;
                state.M4350 = 0x03;
                return; // 31AC: POP HL / RET -- leaves the whole scan
            }
        }
        e += 4;
        l += 2;
        b--;
        if (b == 0) { e = 0x70; l = 0x50; }     // wrap to alien 0
    }
}

/*
 * Translates L31B4 + L3210 (l3000 dispatch when Counter93 & 7 == 5)
 * Phase 3 -> 5: pick the new closed-loop movement pattern for the
 * selected alien from the T3300/T3310/T3330 tables, based on its
 * distance/side relative to the player, its height band and a random.
 * [ASM: 31B4-320D] and [ASM: 3210-3228]
 */
void l31b4(void) {
    extern uint8_t get_random_number(void);
    if (state.M4350 != 3) return;

    // 31BA-31C7: grid X/Y of the alien selected by L315A
    uint8_t l = (uint8_t)(((uint8_t)(state.M4354 - 0x50) << 1) + 0x72);
    uint8_t ax = mem_read(0x4B00 | l);
    uint8_t ay = mem_read(0x4B00 | (uint8_t)(l + 1));

    // 31C8-31D6: distance to the player; C=4 when the player is right
    uint8_t a = state.PlayerShipX;
    uint8_t c, diff;
    if (a >= ax) { c = 4; diff = (uint8_t)(a - ax); }
    else         { c = 0; diff = (uint8_t)(ax - a); }

    // 31D7-31E1: T3300 lookup on the distance band (32-pixel steps)
    extern const uint8_t phoenix_alien_distance_bands[0x08];
    uint8_t t = phoenix_alien_distance_bands[(diff >> 5) & 0x07];

    // 31E2-31E5: C = rotate-left-2 of (band value + side)
    a = (uint8_t)(t + c);
    c = (uint8_t)((a << 2) | (a >> 6));

    // 31E9-31EC + L3210: B from M4357, or the alien height band when
    // only one pattern pair is in play (M4353 == 1)
    uint8_t b = state.M4357;
    if (state.M4353 == 1) {
        if (ay < 0x58)      b = 0;
        else if (ay < 0x78) b = 1;
        else if (ay < 0x98) b = 2;
        else                b = 3;
    }

    // 31F0-31F7: T3310 lookup
    extern const uint8_t phoenix_alien_pattern_selectors[0x20];
    uint8_t lsb = (uint8_t)(c + b + 0x10);
    c = phoenix_alien_pattern_selectors[lsb - 0x10];

    // 31F8-3203: random entry from the closed-loop base table T3330
    extern const uint8_t phoenix_alien_closed_loop_pointers[0xD0];
    lsb = (uint8_t)((get_random_number() & 0x06) + c);
    uint8_t msb_new = phoenix_alien_closed_loop_pointers[lsb - 0x30];
    uint8_t lsb_new = phoenix_alien_closed_loop_pointers[(uint8_t)(lsb + 1) - 0x30];

    // 3204-320D: phase 5, publish the new pattern for L3264
    state.M4350 = 0x05;
    state.M4351 = msb_new;
    state.M4352 = lsb_new;
}

/*
 * Translates L322C (l3000 dispatch when Counter93 & 7 == 6)
 * Phase 4 -> 6: only when every active alien runs exactly the pattern
 * (M4394:M4356) does the pass advance; any deviating alien aborts.
 * [ASM: 322C-325E]
 */
void l322c(void) {
    if (state.M4350 != 4) return;

    uint8_t b = state.M4394;
    uint8_t c = state.M4356;
    for (int i = 0; i < 16; i++) {
        if (mem_read(0x4B70 + i * 4) & 0x08) {
            if (mem_read(0x4B50 + i * 2) != b) return;
            if (mem_read(0x4B51 + i * 2) != c) return;
        }
    }
    state.M4350 = 0x06;
}

/*
 * Translates L2596
 * Per-candidate check for an alien dive-bomb trigger: is this alien
 * slot active, within the right shape range, and within the player's
 * position window? On success falls through to L25B7 to claim an
 * enemy bullet slot.
 * Returns true once L25B7 is reached (regardless of whether a free
 * bullet slot was actually found there) -- in the original this is a
 * fallthrough into a routine whose double-POP trampoline unconditionally
 * aborts the caller's (L2560's) scan.
 * [ASM: 2596-25B6]
 */
static bool l2596(uint16_t hl, uint8_t b, uint8_t c, uint8_t d) {
    uint8_t a = mem_read(hl);
    if ((a & 0x08) == 0) return false;

    hl++;
    a = mem_read(hl);
    if (a == 0x08) return false;
    if (a >= 0x88) return false;

    hl++;
    a = mem_read(hl);
    if (a < b) return false;
    if (a >= c) return false;

    hl++;
    a = mem_read(hl);
    if (a >= d) return false;
    if (a < 0x80) return false;

    uint8_t new_c = a;
    uint8_t new_b = mem_read(hl - 1);

    extern void l25b7(uint8_t b, uint8_t c);
    l25b7(new_b, new_c);
    return true;
}

/*
 * Translates L2560
 * Scans 8 alien candidates (bird0/bird1-style 4-byte-stride records,
 * base $4B70 or $4B90 depending on Counter93 bit 0) for a dive-bomb
 * trigger. Stops at the first candidate that reaches L25B7.
 * [ASM: 2560-2595]
 */
void l2560(void) {
    uint8_t a = (uint8_t)(state.Counter93 & 0x01);
    a = (uint8_t)(a << 5); // RLCA x5 on a 0/1 value: safe as a shift
    a = (uint8_t)(a + 0x70);
    uint16_t hl = (uint16_t)(0x4B00 | a);

    a = (uint8_t)(state.M4357 << 3); // RLCA x3; M4357 is bounds-checked <3 elsewhere
    uint8_t d = (uint8_t)(a + 0xAD);

    uint8_t c = (uint8_t)(state.M439F + 0x03);
    uint8_t b = (uint8_t)(state.M439E - 0x0A);

    for (uint8_t e = 0x08; e != 0; e--) {
        if (l2596(hl, b, c, d)) return;
        hl += 4;
    }
}
