#ifndef Z80_CORE_H
#define Z80_CORE_H

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "phoenix_state.h"
#include "phoenix_hw.h"

/*
 * Central Z80 address-space decoder: the sole path for all memory and
 * memory-mapped I/O access, replacing the raw `(uint8_t*)&state +
 * offset` pointer arithmetic previously scattered across the codebase.
 * An address that's ever computed wrong (an 8-bit wraparound, a stale
 * pointer, an off-by-one) now reads as 0 / writes as a no-op instead of
 * silently corrupting adjacent PhoenixState fields.
 *
 * Real hardware map (see context/RAMUse.md and phoenix_hw.h):
 *   $0000-$3FFF  ROM (read-only)
 *   $4000-$4BFF  RAM (PhoenixState)
 *   $5000        video register (write)
 *   $5800        scroll register (write)
 *   $6000        sound A (write)
 *   $6800        sound B (write)
 *   $7000        inputs / IN0 (read)
 *   $7800        DIP switches (read)
 * Each port is aliased across a $400 range on real hardware (only the
 * high bits are decoded), matched here for parity with mem_write's
 * existing port ranges.
 */
extern PhoenixState state;

static inline uint8_t mem_read(uint16_t addr) {
 if (addr>=0x4000 && addr<0x4c00) return *(const uint8_t*)(addr-0x3000);
 return 0;
}
void mem_write(uint16_t addr,uint8_t val);
#endif
