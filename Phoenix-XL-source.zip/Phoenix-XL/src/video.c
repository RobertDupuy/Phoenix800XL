#include <stdint.h>
#include <string.h>
#include "arcade/phoenix_state.h"
#define HW(a) (*(volatile uint8_t*)(a))
#define PLATFORM __attribute__((noinline,section(".platform")))
extern PhoenixState state;
extern uint8_t g_scroll,g_palette_bank;
extern volatile uint8_t frame_tick,render_tick;
#include "render_tables.h"
uint8_t last_scroll,last_palette;
volatile uint16_t dirty_cells;
uint8_t full_dirty,bg_any_dirty;
volatile uint16_t queue_count;
#define PF ((uint8_t*)0xcc00)
#define PB ((uint8_t*)0x0c00)
#define PC ((uint8_t*)0x0200)
extern void nmi(void),entry(void);
PLATFORM void video_init(void){
 uint16_t i;uint8_t r,c;
 last_palette=255;full_dirty=1;
 memset((void*)0x8000,0,8192);
 memset(PF,255,832);memset(PB,255,832);memset(PC,255,832);
 uint8_t *dl=(uint8_t*)0x0600;
 *dl++=0x70;*dl++=0x70;*dl++=0x70;
 for(r=0;r<24;r++){
  *dl++=0x44|((r==2 || (r%4==3 && r<23))?0x80:0);
  i=r<3?0x0540+(uint16_t)r*40:0x0800+(uint16_t)r*32;*dl++=i;*dl++=i>>8;
  i=0x0800+(uint16_t)r*32;
  for(c=0;c<32;c++)HW(i+c)=(c<3||c>=29)?0:1+(r%4)*26+c-3+((r<3)?128:0);
 }
 *dl++=0x41;*dl++=0;*dl++=6;
 HW(0xd402)=0;HW(0xd403)=6;HW(0xd409)=0x14;
 HW(0xd017)=0x5a;HW(0xd016)=0xa8;HW(0xd018)=0x2c;HW(0xd019)=0x0e;HW(0xd01a)=0;
 HW(0xd01b)=1;HW(0xd407)=0x98;HW(0xd01d)=3;
 HW(0xd008)=0;HW(0xd009)=0;HW(0xd00a)=0;HW(0xd00b)=0;HW(0xd00c)=0;
 HW(0xd012)=0x0e;HW(0xd013)=0x36;HW(0xd014)=0x0e;HW(0xd015)=0xa8;
 HW(0xd40e)=0;*(uint16_t*)0xfffa=(uint16_t)nmi;*(uint16_t*)0xfffc=(uint16_t)entry;*(uint16_t*)0xfffe=(uint16_t)entry;
 HW(0xe8)=0x14;
 HW(0xd400)=0x3e;HW(0xd40e)=0xc0;
}
