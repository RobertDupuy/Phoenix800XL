.setcpu "6502"
.segment "CODE"
.org $0700
loader:
 sei
 cld
 lda #0
 sta $d40e
 sta $d20e
 sta $d400
 lda #$fe
 sta $d301
 lda #0
 sta $e0
 sta $e2
 sta $e4
 lda #$a4
 sta $e5
next:
 sta $d50f
 ldy #0
 lda ($e4),y
 cmp #$ff
 beq done
 tax
 iny
 lda ($e4),y
 sta $e1
 iny
 lda ($e4),y
 sta $e3
 clc
 lda $e4
 adc #3
 sta $e4
 bcc :+
 inc $e5
:
 sta $d500,x
 ldy #0
copy:
 lda ($e0),y
 sta ($e2),y
 iny
 bne copy
 jmp next
done:
 sta $d500
 jmp $2000
