; z80dasm 1.1.6
; command line: /workspace/scratch/eb19bf6d9f73/toolchain/root/usr/bin/z80dasm -a -g 0 -l reference/program.rom

	org	00000h

l0000h:
	nop			;0000
l0001h:
	nop			;0001
l0002h:
	nop			;0002
	nop			;0003
	nop			;0004
	nop			;0005
	nop			;0006
	nop			;0007
l0008h:
	ld sp,04bffh		;0008
	ld h,050h		;000b
	ld (hl),000h		;000d
	call sub_0050h		;000f
l0012h:
	ld hl,l1800h		;0012
	ld c,003h		;0015
	call sub_01d0h		;0017
l001ah:
	call sub_0080h		;001a
	ld a,(043a2h)		;001d
l0020h:
	and a			;0020
	jp z,l002dh		;0021
	call sub_0400h		;0024
	call sub_2700h		;0027
l002ah:
	jp l001ah		;002a
l002dh:
	ld a,00fh		;002d
	ld h,060h		;002f
	ld (hl),a			;0031
	ld h,068h		;0032
	ld (hl),a			;0034
	call sub_0377h		;0035
	nop			;0038
	call sub_17e0h		;0039
	and a			;003c
	jp z,l0046h		;003d
l0040h:
	call sub_0288h		;0040
	jp l001ah		;0043
l0046h:
	call sub_00e3h		;0046
	jp l001ah		;0049
	rst 38h			;004c
	rst 38h			;004d
	rst 38h			;004e
	rst 38h			;004f
sub_0050h:
	ld h,068h		;0050
	ld (hl),000h		;0052
	ld h,060h		;0054
	ld (hl),000h		;0056
	ld h,058h		;0058
	ld (hl),000h		;005a
	call sub_006bh		;005c
	ld h,050h		;005f
	ld (hl),001h		;0061
	call sub_006bh		;0063
	ld h,050h		;0066
	ld (hl),000h		;0068
	ret			;006a
sub_006bh:
	ld hl,04bf8h		;006b
	ld a,03fh		;006e
l0070h:
	ld (hl),000h		;0070
	dec hl			;0072
	cp h			;0073
	jp nz,l0070h		;0074
	ret			;0077
l0078h:
	call sub_0196h		;0078
	jp l06f0h		;007b
	rst 38h			;007e
	rst 38h			;007f
sub_0080h:
	ld h,078h		;0080
l0082h:
	ld a,(hl)			;0082
	and 080h		;0083
	jp z,sub_0080h		;0085
l0088h:
	ld a,(hl)			;0088
	and 080h		;0089
	jp nz,l0088h		;008b
	ld h,070h		;008e
	ld a,(hl)			;0090
	ld hl,043a0h		;0091
	ld b,(hl)			;0094
	ld (hl),a			;0095
	inc l			;0096
	ld (hl),b			;0097
	ld l,09bh		;0098
	call sub_0200h		;009a
	ld l,08fh		;009d
	ld a,(hl)			;009f
	cp 009h		;00a0
	ret z			;00a2
	jp nc,l0000h		;00a3
	ld b,001h		;00a6
	call sub_00bbh		;00a8
	ret z			;00ab
	ld l,08fh		;00ac
	inc (hl)			;00ae
	ld a,(hl)			;00af
	add a,020h		;00b0
	ld (04142h),a		;00b2
	ret			;00b5
	nop			;00b6
	ret			;00b7
	rst 38h			;00b8
	rst 38h			;00b9
	rst 38h			;00ba
sub_00bbh:
	ld hl,043a0h		;00bb
	ld a,(hl)			;00be
	cpl			;00bf
	and b			;00c0
	inc l			;00c1
	and (hl)			;00c2
	ret			;00c3
l00c4h:
	ld a,(hl)			;00c4
	and 00fh		;00c5
	or 020h		;00c7
	ld (de),a			;00c9
	call sub_0210h		;00ca
	dec b			;00cd
	ret z			;00ce
	ld a,(hl)			;00cf
	rrca			;00d0
	rrca			;00d1
l00d2h:
	rrca			;00d2
l00d3h:
	rrca			;00d3
	and 00fh		;00d4
	or 020h		;00d6
	ld (de),a			;00d8
	call sub_0210h		;00d9
	dec hl			;00dc
	dec b			;00dd
	jp nz,l00c4h		;00de
l00e1h:
	ret			;00e1
	rst 38h			;00e2
sub_00e3h:
	ld hl,04399h		;00e3
sub_00e6h:
	call sub_0200h		;00e6
	ld bc,l0001h		;00e9
	call sub_0258h		;00ec
	jp z,l01e1h		;00ef
	ld bc,l0002h		;00f2
	ld de,l011fh		;00f5
	call sub_0260h		;00f8
	jp nc,sub_0196h		;00fb
	ld bc,l011fh+1		;00fe
l0101h:
	call sub_0258h		;0101
l0104h:
	jp z,l0bcah		;0104
	ld c,0b0h		;0107
	call sub_0258h		;0109
	jp z,l01e1h		;010c
	ld c,0b8h		;010f
	call sub_0258h		;0111
	jp z,00580h		;0114
	ld c,0c0h		;0117
	ld de,002dfh		;0119
	call sub_0260h		;011c
l011fh:
	jp nc,l0078h		;011f
	ld bc,l0300h		;0122
	ld de,l03afh		;0125
	call sub_0260h		;0128
	jp nc,l21dch		;012b
	ld bc,003e6h		;012e
	ld de,0ffffh		;0131
	call sub_0260h		;0134
	jp nc,l03b0h		;0137
	ret			;013a
	rst 38h			;013b
	rst 38h			;013c
	rst 38h			;013d
	rst 38h			;013e
	rst 38h			;013f
sub_0140h:
	call sub_03a0h		;0140
	call sub_0080h		;0143
	call sub_0380h		;0146
	ld hl,043a3h		;0149
	ld (hl),002h		;014c
	inc l			;014e
	ld (hl),000h		;014f
	nop			;0151
	nop			;0152
	nop			;0153
	ld l,0b8h		;0154
	ld b,008h		;0156
	call sub_05d8h		;0158
	ld l,0bah		;015b
	ld (hl),010h		;015d
	ld l,0beh		;015f
	ld a,(07800h)		;0161
	and 00ch		;0164
	rlca			;0166
	rlca			;0167
	add a,030h		;0168
	ld (hl),a			;016a
	ld h,058h		;016b
	ld (hl),000h		;016d
	call sub_0080h		;016f
	ret			;0172
sub_0173h:
	ld a,(hl)			;0173
	and 07fh		;0174
	ld b,0ceh		;0176
	cp 01fh		;0178
	ret c			;017a
	ld b,0feh		;017b
	ret z			;017d
	ld b,0aeh		;017e
	cp 05fh		;0180
	ret c			;0182
	ld b,0feh		;0183
	ret z			;0185
	ld b,0ceh		;0186
	cp 07fh		;0188
	ret c			;018a
	ld b,0feh		;018b
	dec l			;018d
	ld a,(hl)			;018e
	cp 009h		;018f
	ret nz			;0191
	ld b,07eh		;0192
	ret			;0194
	rst 38h			;0195
sub_0196h:
	ld a,(hl)			;0196
	and 01fh		;0197
	cp 006h		;0199
	ret c			;019b
	ld e,a			;019c
	ld a,(hl)			;019d
	and 0e0h		;019e
	ld c,a			;01a0
	dec l			;01a1
	ld b,(hl)			;01a2
	ld l,0a8h		;01a3
	ld (hl),b			;01a5
	inc l			;01a6
	ld (hl),c			;01a7
	ld bc,l1860h		;01a8
	call sub_0206h		;01ab
	ld a,(hl)			;01ae
	dec l			;01af
	ld h,(hl)			;01b0
	ld l,a			;01b1
	ld a,e			;01b2
	ld d,(hl)			;01b3
	inc l			;01b4
	ld e,(hl)			;01b5
	dec l			;01b6
	ld c,a			;01b7
	add a,l			;01b8
	ld l,a			;01b9
	ld a,c			;01ba
	sub 006h		;01bb
	ld c,a			;01bd
	jp z,l01c8h		;01be
l01c1h:
	call sub_0217h		;01c1
	dec c			;01c4
	jp nz,l01c1h		;01c5
l01c8h:
	ld a,(hl)			;01c8
	ld (de),a			;01c9
	jp l14e0h		;01ca
	jp nz,001c0h		;01cd
sub_01d0h:
	ld d,(hl)			;01d0
	inc l			;01d1
	ld e,(hl)			;01d2
	ld a,l			;01d3
	add a,005h		;01d4
	ld l,a			;01d6
	ld b,01ah		;01d7
	call sub_01edh		;01d9
	dec c			;01dc
	jp nz,sub_01d0h		;01dd
	ret			;01e0
l01e1h:
	call sub_0140h		;01e1
sub_01e4h:
	ld hl,l1960h		;01e4
	ld c,003h		;01e7
	jp sub_01d0h		;01e9
	rst 38h			;01ec
sub_01edh:
	ld a,(hl)			;01ed
	ld (de),a			;01ee
	inc hl			;01ef
	call sub_0217h		;01f0
	dec b			;01f3
	jp nz,sub_01edh		;01f4
	ret			;01f7
	rst 38h			;01f8
	rst 38h			;01f9
	rst 38h			;01fa
	rst 38h			;01fb
	rst 38h			;01fc
	rst 38h			;01fd
	rst 38h			;01fe
	rst 38h			;01ff
sub_0200h:
	inc (hl)			;0200
	ret nz			;0201
l0202h:
	dec l			;0202
	inc (hl)			;0203
	inc l			;0204
	ret			;0205
sub_0206h:
	ld a,(hl)			;0206
	add a,c			;0207
	ld (hl),a			;0208
l0209h:
	dec l			;0209
	ld a,(hl)			;020a
	adc a,b			;020b
	ld (hl),a			;020c
	inc l			;020d
	ret			;020e
	rst 38h			;020f
sub_0210h:
	ld a,e			;0210
	add a,020h		;0211
	ld e,a			;0213
	ret nc			;0214
	inc d			;0215
	ret			;0216
sub_0217h:
	ld a,e			;0217
	sub 020h		;0218
	ld e,a			;021a
	ret nc			;021b
	dec d			;021c
	ret			;021d
	rst 38h			;021e
	rst 38h			;021f
sub_0220h:
	xor a			;0220
	ld a,(hl)			;0221
	add a,c			;0222
	daa			;0223
	ld (hl),a			;0224
	dec l			;0225
	ld a,(hl)			;0226
	adc a,b			;0227
	daa			;0228
	ld (hl),a			;0229
	dec l			;022a
	ld a,(hl)			;022b
	adc a,000h		;022c
	daa			;022e
	ld (hl),a			;022f
	inc l			;0230
	inc l			;0231
	ret			;0232
	rst 38h			;0233
	rst 38h			;0234
	rst 38h			;0235
	scf			;0236
	ld a,099h		;0237
	adc a,000h		;0239
	sub c			;023b
	add a,(hl)			;023c
	daa			;023d
	ld (hl),a			;023e
	dec l			;023f
l0240h:
	ld a,099h		;0240
	adc a,000h		;0242
	sub b			;0244
	add a,(hl)			;0245
	daa			;0246
	ld (hl),a			;0247
	dec l			;0248
	ld a,099h		;0249
	adc a,000h		;024b
	add a,(hl)			;024d
	daa			;024e
	ld (hl),a			;024f
	inc l			;0250
	inc l			;0251
	ret			;0252
	rst 38h			;0253
	rst 38h			;0254
	rst 38h			;0255
	rst 38h			;0256
	rst 38h			;0257
sub_0258h:
	ld a,(hl)			;0258
	cp c			;0259
	ret nz			;025a
	dec l			;025b
	ld a,(hl)			;025c
	inc l			;025d
	cp b			;025e
	ret			;025f
sub_0260h:
	call sub_0270h		;0260
	ret c			;0263
	call sub_0277h		;0264
	ret			;0267
	rst 38h			;0268
	rst 38h			;0269
	rst 38h			;026a
	rst 38h			;026b
	rst 38h			;026c
	rst 38h			;026d
	rst 38h			;026e
	rst 38h			;026f
sub_0270h:
	ld a,(hl)			;0270
	sub c			;0271
	dec l			;0272
	ld a,(hl)			;0273
	sbc a,b			;0274
	inc l			;0275
	ret			;0276
sub_0277h:
	ld a,e			;0277
	sub (hl)			;0278
	dec l			;0279
	ld a,d			;027a
	sbc a,(hl)			;027b
	inc l			;027c
	ret			;027d
	rst 38h			;027e
	rst 38h			;027f
	ld a,l			;0280
	cp c			;0281
	ret nz			;0282
	ld a,h			;0283
	cp b			;0284
	ret			;0285
	rst 38h			;0286
	rst 38h			;0287
sub_0288h:
	call sub_0140h		;0288
	ld hl,l19c0h		;028b
	ld c,002h		;028e
	call sub_01d0h		;0290
	ld c,002h		;0293
	call sub_17e0h		;0295
	cp 002h		;0298
	jp c,l02a7h		;029a
	ld hl,l1ba0h		;029d
	ld c,001h		;02a0
	call sub_01d0h		;02a2
	ld c,006h		;02a5
l02a7h:
	ld a,(07000h)		;02a7
	cpl			;02aa
	and c			;02ab
	ret z			;02ac
	call sub_02cbh		;02ad
	call sub_02f0h		;02b0
	call sub_032eh		;02b3
	call sub_0350h		;02b6
	call sub_0140h		;02b9
	ld h,050h		;02bc
	ld (hl),001h		;02be
	call sub_0140h		;02c0
	ld h,050h		;02c3
	ld (hl),000h		;02c5
	ret			;02c7
	rst 38h			;02c8
	rst 38h			;02c9
	rst 38h			;02ca
sub_02cbh:
	ld c,001h		;02cb
	cp 002h		;02cd
	jp z,l02d4h		;02cf
	ld c,002h		;02d2
l02d4h:
	ld hl,043a2h		;02d4
	ld (hl),c			;02d7
	ld a,(07800h)		;02d8
	and 010h		;02db
	jp z,l02e3h		;02dd
	ld a,c			;02e0
	rlca			;02e1
	ld c,a			;02e2
l02e3h:
	ld l,08fh		;02e3
	ld a,(hl)			;02e5
	sub c			;02e6
	ld (hl),a			;02e7
	add a,020h		;02e8
	ld (04142h),a		;02ea
	ret			;02ed
	rst 38h			;02ee
	rst 38h			;02ef
sub_02f0h:
	ld de,04383h		;02f0
	ld hl,0438bh		;02f3
	call sub_0314h		;02f6
	call nc,sub_0320h		;02f9
	ld e,087h		;02fc
	ld l,08bh		;02fe
l0300h:
	call sub_0314h		;0300
	call nc,sub_0320h		;0303
	ld l,08bh		;0306
	ld de,04141h		;0308
	ld b,006h		;030b
	call l00c4h		;030d
	ret			;0310
	rst 38h			;0311
	rst 38h			;0312
	rst 38h			;0313
sub_0314h:
	ld a,(de)			;0314
	sub (hl)			;0315
	dec e			;0316
	dec l			;0317
	ld a,(de)			;0318
	sbc a,(hl)			;0319
	dec e			;031a
	dec l			;031b
	ld a,(de)			;031c
	sbc a,(hl)			;031d
	ret			;031e
	rst 38h			;031f
sub_0320h:
	ld a,(de)			;0320
	ld (hl),a			;0321
	inc de			;0322
	inc hl			;0323
	ld a,(de)			;0324
	ld (hl),a			;0325
	inc de			;0326
	inc hl			;0327
	ld a,(de)			;0328
	ld (hl),a			;0329
	ret			;032a
	rst 38h			;032b
	rst 38h			;032c
	rst 38h			;032d
sub_032eh:
	ld hl,04380h		;032e
l0331h:
	ld (hl),000h		;0331
	inc hl			;0333
	ld a,l			;0334
	cp 088h		;0335
	jp nz,l0331h		;0337
	ld l,083h		;033a
	ld de,04261h		;033c
l033fh:
	ld b,006h		;033f
	call l00c4h		;0341
	ld l,087h		;0344
	ld de,04021h		;0346
	ld b,006h		;0349
	call l00c4h		;034b
	ret			;034e
	rst 38h			;034f
sub_0350h:
	ld a,(07800h)		;0350
	and 003h		;0353
	add a,003h		;0355
	ld b,a			;0357
	ld hl,04390h		;0358
	ld (hl),b			;035b
	ld l,0a2h		;035c
	ld a,(hl)			;035e
	cp 001h		;035f
	jp z,l0367h		;0361
	ld l,091h		;0364
	ld (hl),b			;0366
l0367h:
	ld l,090h		;0367
	ld a,(hl)			;0369
	or 020h		;036a
	ld (042a2h),a		;036c
	inc l			;036f
	ld a,(hl)			;0370
	or 020h		;0371
	ld (04062h),a		;0373
	ret			;0376
sub_0377h:
	ld hl,0438ch		;0377
	ld (hl),a			;037a
	inc l			;037b
	ld (hl),a			;037c
	ret			;037d
	rst 38h			;037e
	rst 38h			;037f
sub_0380h:
	ld hl,0433fh		;0380
	ld de,0001fh		;0383
	ld bc,l033fh		;0386
l0389h:
	ld (hl),d			;0389
	dec hl			;038a
	ld (hl),d			;038b
	dec hl			;038c
	ld a,l			;038d
	and e			;038e
	cp b			;038f
	jp nz,l0389h		;0390
	ld (hl),d			;0393
	dec hl			;0394
	dec hl			;0395
	dec hl			;0396
	dec hl			;0397
	ld a,h			;0398
	cp c			;0399
	jp nz,l0389h		;039a
	ret			;039d
	rst 38h			;039e
	rst 38h			;039f
sub_03a0h:
	ld hl,04b3fh		;03a0
	ld de,l0046h+1		;03a3
l03a6h:
	ld (hl),d			;03a6
	dec hl			;03a7
	ld (hl),d			;03a8
	dec hl			;03a9
	ld a,h			;03aa
	cp e			;03ab
	jp nz,l03a6h		;03ac
l03afh:
	ret			;03af
l03b0h:
	ld bc,l07a0h		;03b0
	call sub_0270h		;03b3
	jp c,l03ceh		;03b6
	call sub_0258h		;03b9
	jp z,l03ebh		;03bc
	ld bc,l0b60h		;03bf
	call sub_0270h		;03c2
	jp c,l03ceh		;03c5
	call sub_0258h		;03c8
	jp z,l03e2h		;03cb
l03ceh:
	call sub_0173h		;03ce
	ld hl,043a0h		;03d1
	ld a,(hl)			;03d4
	and 001h		;03d5
	or b			;03d7
	ld (hl),a			;03d8
	jp sub_0400h		;03d9
	jp sub_0400h		;03dc
	rst 38h			;03df
l03e0h:
	rst 38h			;03e0
	rst 38h			;03e1
l03e2h:
	ld bc,00108h		;03e2
	ld de,l1000h		;03e5
	jp l03f1h		;03e8
l03ebh:
	ld bc,l0104h		;03eb
	ld de,l0008h		;03ee
l03f1h:
	ld hl,043a4h		;03f1
	ld (hl),b			;03f4
	ld l,0b8h		;03f5
	ld (hl),c			;03f7
	ld l,0bah		;03f8
	ld (hl),d			;03fa
	inc l			;03fb
	ld (hl),e			;03fc
	ret			;03fd
	rst 38h			;03fe
	rst 38h			;03ff
sub_0400h:
	ld hl,l040eh		;0400
l0403h:
	ld a,(043a4h)		;0403
	rlca			;0406
	add a,l			;0407
	ld l,a			;0408
	ld a,(hl)			;0409
	inc l			;040a
	ld l,(hl)			;040b
	ld h,a			;040c
l040dh:
	jp (hl)			;040d
l040eh:
	inc b			;040e
	jr nc,l0415h		;040f
	xor h			;0411
	dec b			;0412
	dec d			;0413
	ex af,af'			;0414
l0415h:
	nop			;0415
	ld a,(bc)			;0416
	jp pe,0600bh		;0417
	inc h			;041a
	nop			;041b
	inc h			;041c
	ld c,h			;041d
sub_041eh:
	ld a,(043a3h)		;041e
	and 001h		;0421
	ld b,a			;0423
	ld a,(043b8h)		;0424
	and 002h		;0427
	or b			;0429
	ld (05000h),a		;042a
	ret			;042d
	jr l0435h		;042e
	ld hl,043a4h		;0430
	ld (hl),001h		;0433
l0435h:
	inc l			;0435
	ld (hl),080h		;0436
	ld l,0a3h		;0438
	ld a,(hl)			;043a
	ld (hl),000h		;043b
	cp 002h		;043d
	ret z			;043f
	ld (hl),a			;0440
	dec l			;0441
	ld a,(hl)			;0442
	cp 001h		;0443
	ret z			;0445
	inc l			;0446
	ld a,(hl)			;0447
	and a			;0448
	jp z,l04a0h		;0449
	ld l,090h		;044c
	ld a,(hl)			;044e
	and a			;044f
	ret z			;0450
	ld l,0a3h		;0451
	ld (hl),000h		;0453
	ld bc,00100h		;0455
	call sub_0460h		;0458
	ret			;045b
	rst 38h			;045c
	rst 38h			;045d
	rst 38h			;045e
	rst 38h			;045f
sub_0460h:
	ld hl,05000h		;0460
	ld de,04320h		;0463
l0466h:
	ld (hl),b			;0466
	ld a,(de)			;0467
	ld (hl),c			;0468
	ld (de),a			;0469
	inc e			;046a
	ld a,e			;046b
	and 003h		;046c
	jp nz,l0466h		;046e
	ld a,e			;0471
	and 0f0h		;0472
	sub 020h		;0474
	ld e,a			;0476
	jp nc,l0466h		;0477
	dec d			;047a
	ld a,d			;047b
	cp 03fh		;047c
	jp nz,l0466h		;047e
	ld de,04380h		;0481
l0484h:
	ld (hl),b			;0484
	ld a,(de)			;0485
	ld (hl),c			;0486
	ld (de),a			;0487
l0488h:
	inc e			;0488
	ld a,e			;0489
	cp 0b8h		;048a
	jp nz,l0484h		;048c
	ld de,04bc0h		;048f
l0492h:
	ld (hl),b			;0492
	ld a,(de)			;0493
	ld (hl),c			;0494
	ld (de),a			;0495
	inc e			;0496
	ld a,e			;0497
	cp 000h		;0498
	jp nz,l0492h		;049a
	ret			;049d
	rst 38h			;049e
	rst 38h			;049f
l04a0h:
	ld l,0a3h		;04a0
	ld (hl),001h		;04a2
	ld bc,l0001h		;04a4
	call sub_0460h		;04a7
	ret			;04aa
	rst 38h			;04ab
	ld hl,043a5h		;04ac
	dec (hl)			;04af
	ld a,(hl)			;04b0
	dec l			;04b1
	ld (hl),002h		;04b2
	and a			;04b4
	ret z			;04b5
	ld (hl),001h		;04b6
	cp 07fh		;04b8
	jp z,l07f0h		;04ba
	ld l,09ah		;04bd
	ld (hl),000h		;04bf
	inc l			;04c1
	ld (hl),000h		;04c2
	and 008h		;04c4
	jp nz,l04e6h		;04c6
	call sub_06e8h		;04c9
	nop			;04cc
	ld hl,043a3h		;04cd
	ld a,(hl)			;04d0
	and a			;04d1
	ld l,083h		;04d2
	ld de,04261h		;04d4
	jp z,l04dfh		;04d7
	ld l,087h		;04da
	ld de,04021h		;04dc
l04dfh:
	ld b,006h		;04df
	call l00c4h		;04e1
	ret			;04e4
	rst 38h			;04e5
l04e6h:
	ld hl,043a3h		;04e6
	ld a,(hl)			;04e9
	and a			;04ea
	ld de,04261h		;04eb
	jp z,l04f4h		;04ee
	ld de,04021h		;04f1
l04f4h:
	ld b,006h		;04f4
	call sub_04fbh		;04f6
	ret			;04f9
	rst 38h			;04fa
sub_04fbh:
	ld a,000h		;04fb
	ld (de),a			;04fd
	call sub_0210h		;04fe
l0501h:
	dec b			;0501
	jp nz,sub_04fbh		;0502
l0505h:
	ret			;0505
sub_0506h:
	ld hl,04392h		;0506
	ld b,006h		;0509
	call sub_05d8h		;050b
l050eh:
	ld a,(04b50h)		;050e
	ld (04394h),a		;0511
	ret			;0514
	call sub_041eh		;0515
	ld hl,043a4h		;0518
	ld (hl),003h		;051b
	call 00580h		;051d
	call sub_0547h		;0520
	call sub_09a0h		;0523
l0526h:
	call sub_0532h		;0526
	call sub_0a6ch		;0529
	call sub_0506h		;052c
	jp l32b0h		;052f
sub_0532h:
	ld hl,04b50h		;0532
	ld b,0a0h		;0535
	call sub_05d8h		;0537
	call sub_05ech		;053a
	call sub_0650h		;053d
	call sub_0610h		;0540
	ret			;0543
	rst 38h			;0544
	rst 38h			;0545
	rst 38h			;0546
sub_0547h:
	ld hl,l0560h		;0547
	ld de,043c0h		;054a
	ld b,020h		;054d
	call sub_05e0h		;054f
	ld hl,043e0h		;0552
	ld b,020h		;0555
	call sub_05d8h		;0557
	ret			;055a
	rst 38h			;055b
	rst 38h			;055c
	rst 38h			;055d
	rst 38h			;055e
	rst 38h			;055f
l0560h:
	inc c			;0560
	djnz l05c7h		;0561
	ret c			;0563
	nop			;0564
	ld d,b			;0565
	nop			;0566
	ret nc			;0567
	nop			;0568
	ld d,b			;0569
	nop			;056a
	ret nc			;056b
	nop			;056c
	ld e,b			;056d
	nop			;056e
	jr nz,l0571h		;056f
l0571h:
	ld e,b			;0571
	nop			;0572
	jr nz,l0575h		;0573
l0575h:
	ld e,b			;0575
	nop			;0576
	jr nz,l0579h		;0577
l0579h:
	ld e,b			;0579
	nop			;057a
	jr nz,l057dh		;057b
l057dh:
	ld e,b			;057d
	nop			;057e
	jr nz,$+35		;057f
	sbc a,b			;0581
	dec b			;0582
	ld a,(043b8h)		;0583
	and 00fh		;0586
	add a,l			;0588
	ld l,a			;0589
	ld l,(hl)			;058a
	ld h,005h		;058b
	ld de,043abh		;058d
	ld b,00ch		;0590
	call sub_05e0h		;0592
	ret			;0595
	rst 38h			;0596
	rst 38h			;0597
	xor b			;0598
	xor b			;0599
	ret nz			;059a
	ret nz			;059b
	xor b			;059c
	xor b			;059d
	xor b			;059e
	xor b			;059f
	or h			;05a0
	call z,0b4b4h		;05a1
	xor b			;05a4
	xor b			;05a5
	xor b			;05a6
	xor b			;05a7
	add a,b			;05a8
	ld a,a			;05a9
	nop			;05aa
	nop			;05ab
	ld b,b			;05ac
	ccf			;05ad
	nop			;05ae
	inc e			;05af
	nop			;05b0
	rst 38h			;05b1
	rst 38h			;05b2
	rst 38h			;05b3
	ld h,b			;05b4
	ld e,a			;05b5
	ld bc,sub_3000h+2		;05b6
	cpl			;05b9
	nop			;05ba
	inc e			;05bb
	nop			;05bc
	ret nz			;05bd
	rst 38h			;05be
	rst 38h			;05bf
	add a,b			;05c0
	ld a,a			;05c1
	inc bc			;05c2
	inc b			;05c3
	ld b,b			;05c4
	ccf			;05c5
	nop			;05c6
l05c7h:
	rra			;05c7
	nop			;05c8
	and b			;05c9
	rst 38h			;05ca
	rst 38h			;05cb
	ld h,b			;05cc
	ld h,b			;05cd
	dec b			;05ce
	ld b,050h		;05cf
	jr nc,l05d3h		;05d1
l05d3h:
	dec e			;05d3
	nop			;05d4
	ld c,b			;05d5
	rst 38h			;05d6
	rst 38h			;05d7
sub_05d8h:
	xor a			;05d8
l05d9h:
	ld (hl),a			;05d9
	inc hl			;05da
	dec b			;05db
	jp nz,l05d9h		;05dc
	ret			;05df
sub_05e0h:
	ld a,(hl)			;05e0
	ld (de),a			;05e1
	inc hl			;05e2
	inc de			;05e3
	dec b			;05e4
	jp nz,sub_05e0h		;05e5
	ret			;05e8
	rst 38h			;05e9
	rst 38h			;05ea
	rst 38h			;05eb
sub_05ech:
	ld hl,l1500h		;05ec
	ld a,(043b8h)		;05ef
	and 00fh		;05f2
	rlca			;05f4
	add a,l			;05f5
	ld l,a			;05f6
	ld d,(hl)			;05f7
	inc hl			;05f8
	ld e,(hl)			;05f9
sub_05fah:
	ld hl,04b70h		;05fa
	ld a,(043bah)		;05fd
l0600h:
	ld b,a			;0600
	and a			;0601
l0602h:
	ret z			;0602
l0603h:
	ld (hl),d			;0603
	inc l			;0604
	ld (hl),e			;0605
	inc l			;0606
	inc l			;0607
	inc l			;0608
	dec b			;0609
	jp nz,l0603h		;060a
	ret			;060d
	rst 38h			;060e
	rst 38h			;060f
sub_0610h:
	ld hl,l063ah		;0610
	ld a,(043b8h)		;0613
	rrca			;0616
	and 00fh		;0617
	add a,l			;0619
	ld l,a			;061a
	nop			;061b
	nop			;061c
	nop			;061d
	ld l,(hl)			;061e
	ld h,015h		;061f
	ld de,04b72h		;0621
	ld a,(043bah)		;0624
	ld b,a			;0627
	and a			;0628
	ret z			;0629
l062ah:
	ld a,(hl)			;062a
	ld (de),a			;062b
	inc hl			;062c
	inc de			;062d
	ld a,(hl)			;062e
	ld (de),a			;062f
	inc hl			;0630
	inc de			;0631
	inc de			;0632
	inc de			;0633
	dec b			;0634
	jp nz,l062ah		;0635
	ret			;0638
	rst 38h			;0639
l063ah:
	ld h,b			;063a
	ld b,b			;063b
	ret po			;063c
	ret po			;063d
	ret po			;063e
	ret po			;063f
	rst 38h			;0640
	rst 38h			;0641
	ret nz			;0642
	and b			;0643
	add a,b			;0644
	add a,b			;0645
	add a,b			;0646
	add a,b			;0647
	rst 38h			;0648
	rst 38h			;0649
	rst 38h			;064a
	rst 38h			;064b
	rst 38h			;064c
	rst 38h			;064d
	rst 38h			;064e
	rst 38h			;064f
sub_0650h:
	ld hl,l1520h		;0650
	ld a,(043b8h)		;0653
	and 00fh		;0656
	rlca			;0658
	add a,l			;0659
	ld l,a			;065a
	ld d,(hl)			;065b
	inc hl			;065c
	ld e,(hl)			;065d
	ld hl,04b50h		;065e
	ld a,(043bah)		;0661
	ld b,a			;0664
	and a			;0665
	ret z			;0666
l0667h:
	ld (hl),d			;0667
	inc l			;0668
	ld (hl),e			;0669
	inc l			;066a
	dec b			;066b
	jp nz,l0667h		;066c
	ret			;066f
	ld hl,043b1h		;0670
	ld b,(hl)			;0673
	ld l,0b9h		;0674
	ld c,(hl)			;0676
	ld a,c			;0677
	sub b			;0678
	ld (hl),a			;0679
sub_067ah:
	ld hl,043b9h		;067a
	ld a,(hl)			;067d
	dec (hl)			;067e
	ld (05800h),a		;067f
	and 007h		;0682
	ret nz			;0684
	ld bc,l2047h		;0685
	ld de,04b21h		;0688
	ld a,(hl)			;068b
	rrca			;068c
	rrca			;068d
	rrca			;068e
	and 01fh		;068f
	add a,e			;0691
	ld e,a			;0692
	ld l,0b2h		;0693
	ld a,(hl)			;0695
	inc l			;0696
	ld l,(hl)			;0697
	ld h,a			;0698
l0699h:
	ld a,(hl)			;0699
	ld (de),a			;069a
	inc l			;069b
	ld a,e			;069c
	sub b			;069d
	ld e,a			;069e
	jp nc,l0699h		;069f
	dec d			;06a2
	ld a,d			;06a3
	cp c			;06a4
	jp nz,l0699h		;06a5
	ld a,l			;06a8
	ld (043b3h),a		;06a9
	ret			;06ac
	rst 38h			;06ad
	rst 38h			;06ae
	rst 38h			;06af
l06b0h:
	ld hl,043abh		;06b0
	ld a,(043b9h)		;06b3
	ld c,a			;06b6
	cp (hl)			;06b7
	ret nz			;06b8
	ld a,(hl)			;06b9
	inc l			;06ba
	add a,(hl)			;06bb
	dec l			;06bc
	ld (hl),a			;06bd
	inc l			;06be
	inc l			;06bf
	inc (hl)			;06c0
	ld b,(hl)			;06c1
	inc l			;06c2
	inc (hl)			;06c3
	ld a,(hl)			;06c4
	ld hl,l1e20h		;06c5
	and 01fh		;06c8
	add a,l			;06ca
	ld l,a			;06cb
	ld d,(hl)			;06cc
	add a,020h		;06cd
	ld l,a			;06cf
	ld e,(hl)			;06d0
	ld a,c			;06d1
	rrca			;06d2
	rrca			;06d3
	rrca			;06d4
	and 01eh		;06d5
	add a,e			;06d7
	add a,002h		;06d8
	ld e,a			;06da
	ld hl,l1e60h		;06db
	ld a,b			;06de
	and 01fh		;06df
	add a,l			;06e1
	ld l,a			;06e2
	ld l,(hl)			;06e3
	call sub_07dch		;06e4
	ret			;06e7
sub_06e8h:
	ld hl,l1800h		;06e8
	ld c,001h		;06eb
	jp sub_01d0h		;06ed
l06f0h:
	call sub_067ah		;06f0
	call sub_2040h		;06f3
	jp l06b0h		;06f6
	rst 38h			;06f9
	rst 38h			;06fa
	rst 38h			;06fb
	rst 38h			;06fc
	rst 38h			;06fd
	rst 38h			;06fe
	rst 38h			;06ff
sub_0700h:
	ld bc,043c0h		;0700
	ld de,043e0h		;0703
l0706h:
	call sub_0718h		;0706
	ld a,c			;0709
	add a,004h		;070a
l070ch:
	ld c,a			;070c
	add a,020h		;070d
	ld e,a			;070f
	ld d,b			;0710
	cp 0ech		;0711
	jp nz,l0706h		;0713
	ret			;0716
	ret			;0717
sub_0718h:
	call sub_0720h		;0718
	jp l0740h		;071b
	and 0efh		;071e
sub_0720h:
	ld a,(bc)			;0720
	ld h,a			;0721
	and 010h		;0722
	ret z			;0724
	ld a,h			;0725
	and 0efh		;0726
	ld (bc),a			;0728
	rlca			;0729
	rlca			;072a
	rlca			;072b
	and 007h		;072c
	add a,038h		;072e
	ld l,a			;0730
	ld h,007h		;0731
	ld l,(hl)			;0733
	jp (hl)			;0734
	ld l,h			;0735
	rst 38h			;0736
	adc a,d			;0737
	ld h,e			;0738
	ld a,c			;0739
	rst 38h			;073a
	sbc a,(hl)			;073b
	cp (hl)			;073c
	rst 38h			;073d
	rst 38h			;073e
	rst 38h			;073f
l0740h:
	ld a,(bc)			;0740
	ld h,a			;0741
	and 008h		;0742
	ret z			;0744
	ld a,h			;0745
	and 007h		;0746
	ld h,a			;0748
	rrca			;0749
	rrca			;074a
	rrca			;074b
	or h			;074c
	or 018h		;074d
	ld (bc),a			;074f
	inc bc			;0750
	ld a,h			;0751
	add a,05bh		;0752
	ld l,a			;0754
	ld h,007h		;0755
	ld l,(hl)			;0757
	jp (hl)			;0758
	ld e,(hl)			;0759
	ld a,(bc)			;075a
	ld l,l			;075b
	adc a,b			;075c
	rst 38h			;075d
	xor d			;075e
	jp nc,0ffffh		;075f
	rst 38h			;0762
	ex de,hl			;0763
	ld d,(hl)			;0764
	inc hl			;0765
	ld e,(hl)			;0766
	dec hl			;0767
	xor a			;0768
	ld (de),a			;0769
	ex de,hl			;076a
	ret			;076b
	ex de,hl			;076c
	ex de,hl			;076d
	inc hl			;076e
	inc hl			;076f
	ld d,(hl)			;0770
	inc hl			;0771
	ld e,(hl)			;0772
	ld a,(bc)			;0773
	ld (de),a			;0774
	dec bc			;0775
	ret			;0776
	ld (de),a			;0777
	inc hl			;0778
	ex de,hl			;0779
	ld d,(hl)			;077a
	inc hl			;077b
	ld e,(hl)			;077c
	dec hl			;077d
	xor a			;077e
	ld (de),a			;077f
	call sub_0217h		;0780
	xor a			;0783
	ld (de),a			;0784
	ex de,hl			;0785
	ret			;0786
	inc hl			;0787
	ex de,hl			;0788
	inc hl			;0789
	inc hl			;078a
	ld d,(hl)			;078b
	inc hl			;078c
	ld e,(hl)			;078d
	ld a,(bc)			;078e
	ld l,a			;078f
	ld h,014h		;0790
	ld a,(hl)			;0792
	ld (de),a			;0793
	inc hl			;0794
	call sub_0217h		;0795
	ld a,(hl)			;0798
	ld (de),a			;0799
	dec bc			;079a
	ret			;079b
	rst 38h			;079c
	ex de,hl			;079d
	ex de,hl			;079e
	ld d,(hl)			;079f
l07a0h:
	inc hl			;07a0
	ld e,(hl)			;07a1
	dec hl			;07a2
	xor a			;07a3
	ld (de),a			;07a4
	inc de			;07a5
	ld (de),a			;07a6
	ex de,hl			;07a7
	ret			;07a8
	rst 38h			;07a9
	ex de,hl			;07aa
	inc hl			;07ab
	inc hl			;07ac
	ld d,(hl)			;07ad
	inc hl			;07ae
	ld e,(hl)			;07af
	ld a,(bc)			;07b0
	ld l,a			;07b1
	ld h,014h		;07b2
	ld a,(hl)			;07b4
	ld (de),a			;07b5
	inc hl			;07b6
	inc de			;07b7
	ld a,(hl)			;07b8
	ld (de),a			;07b9
	dec bc			;07ba
	ret			;07bb
	inc hl			;07bc
	inc de			;07bd
	ex de,hl			;07be
	ld d,(hl)			;07bf
l07c0h:
	inc hl			;07c0
	ld e,(hl)			;07c1
	dec hl			;07c2
	xor a			;07c3
	ld (de),a			;07c4
	inc de			;07c5
	ld (de),a			;07c6
	call sub_0217h		;07c7
	xor a			;07ca
	ld (de),a			;07cb
	dec de			;07cc
	ld (de),a			;07cd
	ex de,hl			;07ce
	ret			;07cf
	call 0eb4ch		;07d0
	inc hl			;07d3
	inc hl			;07d4
	ld d,(hl)			;07d5
	inc hl			;07d6
	ld e,(hl)			;07d7
	ld a,(bc)			;07d8
	ld l,a			;07d9
	ld h,014h		;07da
sub_07dch:
	ld a,(hl)			;07dc
	ld (de),a			;07dd
	inc hl			;07de
	inc de			;07df
	ld a,(hl)			;07e0
	ld (de),a			;07e1
	inc hl			;07e2
	dec de			;07e3
	call sub_0217h		;07e4
	ld a,(hl)			;07e7
	ld (de),a			;07e8
	inc hl			;07e9
	inc de			;07ea
	ld a,(hl)			;07eb
	ld (de),a			;07ec
	dec bc			;07ed
	ret			;07ee
	rst 38h			;07ef
l07f0h:
	ld a,(043b9h)		;07f0
	ld (05800h),a		;07f3
	call sub_0380h		;07f6
	jp sub_041eh		;07f9
	rst 38h			;07fc
	rst 38h			;07fd
	rst 38h			;07fe
sub_07ffh:
	rst 38h			;07ff
l0800h:
	ld hl,l0814h		;0800
	ld a,(043b8h)		;0803
	rlca			;0806
l0807h:
	and 01eh		;0807
	add a,l			;0809
	ld l,a			;080a
	ld a,(hl)			;080b
	inc l			;080c
	ld l,(hl)			;080d
	ld h,a			;080e
	jp (hl)			;080f
l0810h:
	rst 38h			;0810
	rst 38h			;0811
	rst 38h			;0812
	rst 38h			;0813
l0814h:
	ex af,af'			;0814
	inc (hl)			;0815
	jr nz,l0818h		;0816
l0818h:
	ex af,af'			;0818
	inc (hl)			;0819
	jr nz,l081ch		;081a
l081ch:
	ld (03430h),hl		;081c
	nop			;081f
	ld (03430h),hl		;0820
	nop			;0823
	ld (l2230h),hl		;0824
	or h			;0827
	ld (020cah),hl		;0828
	nop			;082b
	ld (l224ch),hl		;082c
	ld c,h			;082f
	ld (l224ch),hl		;0830
	ld c,h			;0833
l0834h:
	call l06f0h		;0834
	ld hl,043b4h		;0837
	dec (hl)			;083a
	ld a,(hl)			;083b
	cp 015h		;083c
	ret nc			;083e
	call sub_085ah		;083f
	call sub_05fah		;0842
	call sub_0a50h		;0845
l0848h:
	ld hl,043b4h		;0848
	ld a,(hl)			;084b
	and a			;084c
	ret nz			;084d
	ld l,0b8h		;084e
	inc (hl)			;0850
	ld l,0a4h		;0851
	ld (hl),002h		;0853
	ret			;0855
	rst 38h			;0856
	rst 38h			;0857
	rst 38h			;0858
	rst 38h			;0859
sub_085ah:
	ld de,l086ch		;085a
	cp 011h		;085d
	ret nc			;085f
	ld e,06dh		;0860
	cp 00dh		;0862
	ret nc			;0864
	ld e,06eh		;0865
	cp 009h		;0867
	ret nc			;0869
	ld e,06fh		;086a
l086ch:
	cp 005h		;086c
	ret nc			;086e
	ld e,068h		;086f
	ret			;0871
	rst 38h			;0872
	rst 38h			;0873
	rst 38h			;0874
	rst 38h			;0875
sub_0876h:
	call sub_0700h		;0876
	call sub_0886h		;0879
	call sub_08a0h		;087c
	call sub_09a0h		;087f
	call 0097ah		;0882
	ret			;0885
sub_0886h:
	ld hl,043ebh		;0886
	ld b,003h		;0889
l088bh:
	ld d,(hl)			;088b
	dec hl			;088c
	ld e,(hl)			;088d
	dec hl			;088e
	ld (hl),d			;088f
	dec hl			;0890
	ld (hl),e			;0891
	dec hl			;0892
	dec b			;0893
	jp nz,l088bh		;0894
	ret			;0897
	rst 38h			;0898
	rst 38h			;0899
	rst 38h			;089a
	rst 38h			;089b
	rst 38h			;089c
	rst 38h			;089d
	rst 38h			;089e
	rst 38h			;089f
sub_08a0h:
	call sub_08c4h		;08a0
	ld hl,043c4h		;08a3
	call sub_0930h		;08a6
	ld a,(043b8h)		;08a9
	and 00fh		;08ac
	cp 003h		;08ae
	ret nz			;08b0
	ld hl,043c8h		;08b1
	call sub_0930h		;08b4
	ret			;08b7
	rst 38h			;08b8
	rst 38h			;08b9
	rst 38h			;08ba
	rst 38h			;08bb
	rst 38h			;08bc
	rst 38h			;08bd
	rst 38h			;08be
	rst 38h			;08bf
	rst 38h			;08c0
	rst 38h			;08c1
	rst 38h			;08c2
	rst 38h			;08c3
sub_08c4h:
	ld hl,043c0h		;08c4
	ld a,(hl)			;08c7
	and 008h		;08c8
	jp z,l0aa0h		;08ca
	ld l,0a6h		;08cd
	ld a,(hl)			;08cf
	and a			;08d0
	jp nz,l08eah		;08d1
	ld b,080h		;08d4
	call sub_00bbh		;08d6
	jp z,l08ebh		;08d9
	ld l,062h		;08dc
	ld (hl),040h		;08de
	ld l,0c0h		;08e0
	ld a,(hl)			;08e2
	and 0f7h		;08e3
	ld (hl),a			;08e5
	ld l,0a6h		;08e6
	ld (hl),0ffh		;08e8
l08eah:
	dec (hl)			;08ea
l08ebh:
	ld l,0c2h		;08eb
	call sub_0900h		;08ed
	ld bc,01600h		;08f0
	jp l0926h		;08f3
	rst 38h			;08f6
	rst 38h			;08f7
	rst 38h			;08f8
	rst 38h			;08f9
	rst 38h			;08fa
	rst 38h			;08fb
	rst 38h			;08fc
	rst 38h			;08fd
	rst 38h			;08fe
l08ffh:
	rst 38h			;08ff
sub_0900h:
	ld a,(043a0h)		;0900
	cpl			;0903
	and 060h		;0904
	ret z			;0906
	and 040h		;0907
	jp z,l0917h		;0909
	ld a,(hl)			;090c
	cp 00dh		;090d
	ret c			;090f
	dec (hl)			;0910
	ld a,0ffh		;0911
	ld (04360h),a		;0913
	ret			;0916
l0917h:
	ld a,(hl)			;0917
	cp 0c0h		;0918
	ret nc			;091a
	inc (hl)			;091b
	ld a,0ffh		;091c
	ld (04360h),a		;091e
	ret			;0921
	rst 38h			;0922
	rst 38h			;0923
	rst 38h			;0924
	rst 38h			;0925
l0926h:
	ld a,(hl)			;0926
	and 007h		;0927
	add a,c			;0929
	ld c,a			;092a
	ld a,(bc)			;092b
	dec l			;092c
	ld (hl),a			;092d
	ret			;092e
	rst 38h			;092f
sub_0930h:
	ld a,(hl)			;0930
	and 008h		;0931
	jp nz,l0964h		;0933
	ex de,hl			;0936
	ld b,010h		;0937
	call sub_00bbh		;0939
	ret z			;093c
	ld a,(hl)			;093d
	and 0efh		;093e
	ld (hl),a			;0940
	ld a,(de)			;0941
	or 008h		;0942
	ld (de),a			;0944
	inc de			;0945
	inc de			;0946
	ld a,(043c2h)		;0947
	add a,004h		;094a
	ld (de),a			;094c
	inc de			;094d
	ld a,(043c3h)		;094e
	sub 008h		;0951
	ld (de),a			;0953
	dec de			;0954
	ex de,hl			;0955
	ld bc,l1620h		;0956
	call l0926h		;0959
	ld a,030h		;095c
	ld (04361h),a		;095e
	ret			;0961
	rst 38h			;0962
	rst 38h			;0963
l0964h:
	inc l			;0964
	inc l			;0965
	inc l			;0966
	ld a,(hl)			;0967
	sub 008h		;0968
	ld (hl),a			;096a
	cp 01fh		;096b
	ret nc			;096d
l096eh:
	dec l			;096e
	dec l			;096f
	dec l			;0970
	ld a,(hl)			;0971
	and 0f7h		;0972
	ld (hl),a			;0974
	ret			;0975
	rst 38h			;0976
	rst 38h			;0977
	ld a,(hl)			;0978
	and 03ah		;0979
	jp nz,04743h		;097b
	and 007h		;097e
	rlca			;0980
	ld hl,l0b38h		;0981
	add a,l			;0984
	ld l,a			;0985
	ld a,b			;0986
	sub (hl)			;0987
	ld (0439eh),a		;0988
	inc hl			;098b
	ld a,b			;098c
	add a,(hl)			;098d
	ld (0439fh),a		;098e
	ret			;0991
	ld (0439fh),a		;0992
	ret			;0995
	rst 38h			;0996
	rst 38h			;0997
	rst 38h			;0998
	rst 38h			;0999
	rst 38h			;099a
	rst 38h			;099b
	rst 38h			;099c
	rst 38h			;099d
	rst 38h			;099e
	rst 38h			;099f
sub_09a0h:
	ld bc,043c2h		;09a0
	ld de,043e2h		;09a3
l09a6h:
	call sub_09bah		;09a6
	inc bc			;09a9
	inc bc			;09aa
	inc bc			;09ab
	inc de			;09ac
	inc de			;09ad
	inc de			;09ae
	ld a,c			;09af
	cp 0ceh		;09b0
	jp nz,l09a6h		;09b2
	ret			;09b5
	rst 38h			;09b6
	rst 38h			;09b7
	rst 38h			;09b8
	rst 38h			;09b9
sub_09bah:
	ld hl,l0a00h		;09ba
	ld a,(bc)			;09bd
	and 0f8h		;09be
	rrca			;09c0
	rrca			;09c1
	add a,l			;09c2
	ld l,a			;09c3
	ld a,(hl)			;09c4
	ld (de),a			;09c5
	inc bc			;09c6
	inc de			;09c7
	inc hl			;09c8
	ld a,(bc)			;09c9
	and 0f8h		;09ca
	rrca			;09cc
	rrca			;09cd
	rrca			;09ce
	add a,(hl)			;09cf
	ld (de),a			;09d0
	ret			;09d1
	rst 38h			;09d2
	rst 38h			;09d3
	rst 38h			;09d4
	rst 38h			;09d5
	rst 38h			;09d6
	rst 38h			;09d7
	rst 38h			;09d8
	rst 38h			;09d9
	rst 38h			;09da
	rst 38h			;09db
	rst 38h			;09dc
	rst 38h			;09dd
	rst 38h			;09de
	rst 38h			;09df
	rst 38h			;09e0
	rst 38h			;09e1
	rst 38h			;09e2
	rst 38h			;09e3
	rst 38h			;09e4
	rst 38h			;09e5
	rst 38h			;09e6
	rst 38h			;09e7
	rst 38h			;09e8
	rst 38h			;09e9
	rst 38h			;09ea
	rst 38h			;09eb
	rst 38h			;09ec
	rst 38h			;09ed
	rst 38h			;09ee
	rst 38h			;09ef
	rst 38h			;09f0
	rst 38h			;09f1
	rst 38h			;09f2
	rst 38h			;09f3
	rst 38h			;09f4
	rst 38h			;09f5
	rst 38h			;09f6
	rst 38h			;09f7
	rst 38h			;09f8
	rst 38h			;09f9
	rst 38h			;09fa
	rst 38h			;09fb
	rst 38h			;09fc
	rst 38h			;09fd
	rst 38h			;09fe
	rst 38h			;09ff
l0a00h:
	ld b,e			;0a00
	jr nz,l0a46h		;0a01
	nop			;0a03
	ld b,d			;0a04
	ret po			;0a05
	ld b,d			;0a06
	ret nz			;0a07
	ld b,d			;0a08
	and b			;0a09
	ld b,d			;0a0a
	add a,b			;0a0b
	ld b,d			;0a0c
	ld h,b			;0a0d
	ld b,d			;0a0e
	ld b,b			;0a0f
	ld b,d			;0a10
	jr nz,$+68		;0a11
	nop			;0a13
	ld b,c			;0a14
	ret po			;0a15
	ld b,c			;0a16
	ret nz			;0a17
	ld b,c			;0a18
	and b			;0a19
	ld b,c			;0a1a
	add a,b			;0a1b
	ld b,c			;0a1c
	ld h,b			;0a1d
	ld b,c			;0a1e
	ld b,b			;0a1f
	ld b,c			;0a20
	jr nz,l0a64h		;0a21
	nop			;0a23
	ld b,b			;0a24
	ret po			;0a25
	ld b,b			;0a26
	ret nz			;0a27
	ld b,b			;0a28
	and b			;0a29
	ld b,b			;0a2a
	add a,b			;0a2b
	ld b,b			;0a2c
	ld h,b			;0a2d
	ld b,b			;0a2e
	ld b,b			;0a2f
	ld b,b			;0a30
	jr nz,l0a73h		;0a31
	nop			;0a33
	nop			;0a34
	nop			;0a35
	nop			;0a36
	nop			;0a37
	nop			;0a38
	nop			;0a39
	nop			;0a3a
	nop			;0a3b
	nop			;0a3c
	nop			;0a3d
	nop			;0a3e
	nop			;0a3f
l0a40h:
	xor d			;0a40
	cp d			;0a41
	xor e			;0a42
	cp e			;0a43
	add a,b			;0a44
	sub b			;0a45
l0a46h:
	add a,c			;0a46
	sub c			;0a47
l0a48h:
	ld (hl),h			;0a48
	ld a,h			;0a49
	ld (hl),l			;0a4a
	ld a,l			;0a4b
	rst 38h			;0a4c
	rst 38h			;0a4d
	rst 38h			;0a4e
	rst 38h			;0a4f
sub_0a50h:
	ld bc,04b70h		;0a50
	ld de,04bb0h		;0a53
l0a56h:
	push bc			;0a56
	call sub_0718h		;0a57
	pop bc			;0a5a
	ld a,c			;0a5b
	add a,004h		;0a5c
	ld c,a			;0a5e
	add a,040h		;0a5f
	ld e,a			;0a61
	ld d,b			;0a62
	and a			;0a63
l0a64h:
	jp nz,l0a56h		;0a64
	ret			;0a67
	rst 38h			;0a68
	rst 38h			;0a69
	rst 38h			;0a6a
	rst 38h			;0a6b
sub_0a6ch:
	ld bc,04b70h		;0a6c
	ld de,04bb3h		;0a6f
l0a72h:
	push bc			;0a72
l0a73h:
	push de			;0a73
	ld a,(bc)			;0a74
	and 018h		;0a75
	jp z,l0a8ah		;0a77
	ex de,hl			;0a7a
	ld d,(hl)			;0a7b
	dec hl			;0a7c
	ld e,(hl)			;0a7d
	dec hl			;0a7e
	ld (hl),d			;0a7f
	dec hl			;0a80
	ld (hl),e			;0a81
	ex de,hl			;0a82
	inc de			;0a83
	inc de			;0a84
	inc bc			;0a85
	inc bc			;0a86
	call sub_09bah		;0a87
l0a8ah:
	pop de			;0a8a
	pop bc			;0a8b
	ld a,c			;0a8c
	add a,004h		;0a8d
	ld c,a			;0a8f
	ld a,e			;0a90
	add a,004h		;0a91
	ld e,a			;0a93
	cp 003h		;0a94
	jp nz,l0a72h		;0a96
	ret			;0a99
	rst 38h			;0a9a
	rst 38h			;0a9b
	rst 38h			;0a9c
	rst 38h			;0a9d
	rst 38h			;0a9e
	rst 38h			;0a9f
l0aa0h:
	ld l,0e2h		;0aa0
	ld d,(hl)			;0aa2
	inc hl			;0aa3
	ld e,(hl)			;0aa4
	call sub_0210h		;0aa5
	dec de			;0aa8
	ld bc,l0403h+1		;0aa9
	ld l,0a6h		;0aac
	dec (hl)			;0aae
	ld a,(hl)			;0aaf
	ld hl,l17f0h		;0ab0
	cp 0c0h		;0ab3
	jp z,l0b48h		;0ab5
	ld hl,l1770h		;0ab8
	and 00ch		;0abb
	rlca			;0abd
	rlca			;0abe
	add a,l			;0abf
	ld l,a			;0ac0
	jp l0ad6h		;0ac1
	rst 38h			;0ac4
	rst 38h			;0ac5
	rst 38h			;0ac6
	rst 38h			;0ac7
	rst 38h			;0ac8
	rst 38h			;0ac9
	rst 38h			;0aca
	rst 38h			;0acb
	rst 38h			;0acc
	rst 38h			;0acd
	rst 38h			;0ace
	rst 38h			;0acf
	rst 38h			;0ad0
	rst 38h			;0ad1
	rst 38h			;0ad2
	rst 38h			;0ad3
	rst 38h			;0ad4
	rst 38h			;0ad5
l0ad6h:
	push de			;0ad6
	push bc			;0ad7
l0ad8h:
	ld a,(hl)			;0ad8
	ld (de),a			;0ad9
	inc hl			;0ada
	inc de			;0adb
	dec b			;0adc
	jp nz,l0ad8h		;0add
	pop bc			;0ae0
	pop de			;0ae1
	call sub_0217h		;0ae2
	dec c			;0ae5
	jp nz,l0ad6h		;0ae6
	ret			;0ae9
	ld hl,043b9h		;0aea
	ld a,(hl)			;0aed
	and 0f8h		;0aee
	ld (hl),a			;0af0
	ld (05800h),a		;0af1
	ld l,0e2h		;0af4
	ld d,(hl)			;0af6
	inc l			;0af7
	ld e,(hl)			;0af8
	call sub_0210h		;0af9
	dec de			;0afc
	nop			;0afd
	ld l,0a5h		;0afe
	dec (hl)			;0b00
l0b01h:
	ld a,(hl)			;0b01
	jp z,00b15h		;0b02
	cp 020h		;0b05
	jp c,l0ba0h		;0b07
	jp z,sub_0380h		;0b0a
	jp l0bbah		;0b0d
	ld (hl),b			;0b10
	jr nz,l0ad6h		;0b11
	ret pe			;0b13
	jr nz,l0b43h		;0b14
	ld (hl),005h		;0b16
	dec l			;0b18
	ld a,(hl)			;0b19
	add a,090h		;0b1a
	ld l,a			;0b1c
	ld a,(hl)			;0b1d
	and a			;0b1e
	ret z			;0b1f
	dec (hl)			;0b20
	push hl			;0b21
	call l0367h		;0b22
	pop hl			;0b25
	ld a,(hl)			;0b26
	and a			;0b27
	ret z			;0b28
	ld l,0a4h		;0b29
	ld (hl),000h		;0b2b
	ret			;0b2d
	rst 38h			;0b2e
	rst 38h			;0b2f
	rst 38h			;0b30
	ret p			;0b31
	ret po			;0b32
	or b			;0b33
	ret nz			;0b34
	ret nc			;0b35
	ret nz			;0b36
	or b			;0b37
l0b38h:
	nop			;0b38
	ex af,af'			;0b39
	ld bc,l0209h		;0b3a
	ld a,(bc)			;0b3d
	inc bc			;0b3e
	dec bc			;0b3f
	inc bc			;0b40
	dec bc			;0b41
	ld (bc),a			;0b42
l0b43h:
	ld a,(bc)			;0b43
	ld bc,l0008h+1		;0b44
	ex af,af'			;0b47
l0b48h:
	call l0ad6h		;0b48
	ld hl,043c0h		;0b4b
	ld (hl),00ch		;0b4e
	inc l			;0b50
	ld (hl),00ch		;0b51
	inc l			;0b53
	ld a,(hl)			;0b54
	and 0f8h		;0b55
	or 003h		;0b57
	ld (hl),a			;0b59
	ret			;0b5a
	rst 38h			;0b5b
	rst 38h			;0b5c
	rst 38h			;0b5d
	rst 38h			;0b5e
	rst 38h			;0b5f
l0b60h:
	ld hl,043a5h		;0b60
	inc (hl)			;0b63
	ld a,(hl)			;0b64
	cp 040h		;0b65
	jp z,sub_03a0h		;0b67
	ld hl,l1a00h		;0b6a
	ld c,001h		;0b6d
	cp 080h		;0b6f
	jp nz,l0b95h		;0b71
	ld hl,043a4h		;0b74
	ld (hl),000h		;0b77
	ld l,090h		;0b79
	ld a,(hl)			;0b7b
	inc l			;0b7c
	or (hl)			;0b7d
	ret nz			;0b7e
	xor a			;0b7f
	ld l,098h		;0b80
	ld (hl),a			;0b82
	inc l			;0b83
	ld (hl),a			;0b84
	ld l,0a2h		;0b85
	ld (hl),a			;0b87
	inc l			;0b88
	ld a,(hl)			;0b89
	and a			;0b8a
	ret z			;0b8b
	ld (hl),000h		;0b8c
	ld bc,00100h		;0b8e
	call sub_0460h		;0b91
	ret			;0b94
l0b95h:
	call sub_01d0h		;0b95
	call sub_01e4h		;0b98
	jp l1df0h		;0b9b
	rst 38h			;0b9e
	rst 38h			;0b9f
l0ba0h:
	ld hl,043b8h		;0ba0
	ld a,(hl)			;0ba3
	and 00fh		;0ba4
	cp 004h		;0ba6
	ret c			;0ba8
	cp 009h		;0ba9
	ret nc			;0bab
	inc l			;0bac
	xor a			;0bad
	ld (hl),a			;0bae
	ld (05800h),a		;0baf
	jp sub_03a0h		;0bb2
	rst 38h			;0bb5
	rst 38h			;0bb6
	rst 38h			;0bb7
	rst 38h			;0bb8
	rst 38h			;0bb9
l0bbah:
	ld b,a			;0bba
	rrca			;0bbb
	jp nc,l0fc0h		;0bbc
	rrca			;0bbf
	ld a,b			;0bc0
	jp c,l2070h		;0bc1
	jp l20e8h		;0bc4
	rst 38h			;0bc7
	rst 38h			;0bc8
	rst 38h			;0bc9
l0bcah:
	ld hl,042d0h		;0bca
	ld bc,0ffdfh		;0bcd
	ld (hl),064h		;0bd0
	add hl,bc			;0bd2
	inc hl			;0bd3
	ld (hl),065h		;0bd4
	ld hl,042f2h		;0bd6
	ld de,l0a40h		;0bd9
	call sub_3538h		;0bdc
	ld hl,04b15h		;0bdf
	ld de,l3c00h		;0be2
	call sub_3528h		;0be5
	ld hl,04ad8h		;0be8
	ld de,l0a48h		;0beb
	call sub_3548h		;0bee
	ret			;0bf1
	rst 38h			;0bf2
	rst 38h			;0bf3
	rst 38h			;0bf4
	rst 38h			;0bf5
	rst 38h			;0bf6
	rst 38h			;0bf7
	rst 38h			;0bf8
	rst 38h			;0bf9
	rst 38h			;0bfa
	rst 38h			;0bfb
	rst 38h			;0bfc
	rst 38h			;0bfd
	rst 38h			;0bfe
	rst 38h			;0bff
l0c00h:
	push hl			;0c00
	ld a,l			;0c01
l0c02h:
	sub 072h		;0c02
l0c04h:
	rrca			;0c04
	add a,050h		;0c05
	ld l,a			;0c07
	ld a,(hl)			;0c08
	inc l			;0c09
	ld l,(hl)			;0c0a
l0c0bh:
	ld h,a			;0c0b
	ld de,l0c04h		;0c0c
	ld a,(hl)			;0c0f
l0c10h:
	pop hl			;0c10
	cp 007h		;0c11
	jp c,l0ea4h		;0c13
	cp 009h		;0c16
	jp nc,l0ea4h		;0c18
	ld de,l1020h		;0c1b
	ld a,0ffh		;0c1e
	ld (04369h),a		;0c20
	jp l0ea4h		;0c23
	rst 38h			;0c26
	rst 38h			;0c27
	rst 38h			;0c28
	rst 38h			;0c29
	rst 38h			;0c2a
	rst 38h			;0c2b
	rst 38h			;0c2c
	rst 38h			;0c2d
	rst 38h			;0c2e
	rst 38h			;0c2f
	rst 38h			;0c30
	rst 38h			;0c31
	rst 38h			;0c32
	rst 38h			;0c33
	rst 38h			;0c34
	rst 38h			;0c35
	rst 38h			;0c36
	rst 38h			;0c37
	rst 38h			;0c38
	rst 38h			;0c39
	rst 38h			;0c3a
	rst 38h			;0c3b
	rst 38h			;0c3c
	rst 38h			;0c3d
	rst 38h			;0c3e
	rst 38h			;0c3f
sub_0c40h:
	ld hl,043ffh		;0c40
	ld b,005h		;0c43
	call l088bh		;0c45
	call sub_0c56h		;0c48
	call sub_0c6bh		;0c4b
	call sub_0cd8h		;0c4e
	ret			;0c51
	rst 38h			;0c52
	rst 38h			;0c53
	rst 38h			;0c54
	rst 38h			;0c55
sub_0c56h:
	ld hl,043cch		;0c56
l0c59h:
	push hl			;0c59
	call sub_0c84h		;0c5a
	pop hl			;0c5d
	ld a,l			;0c5e
	add a,004h		;0c5f
	ld l,a			;0c61
	cp 0e0h		;0c62
	jp nz,l0c59h		;0c64
	ret			;0c67
	rst 38h			;0c68
	rst 38h			;0c69
	rst 38h			;0c6a
sub_0c6bh:
	ld bc,043ceh		;0c6b
	ld de,043eeh		;0c6e
l0c71h:
	call sub_09bah		;0c71
	inc bc			;0c74
	inc bc			;0c75
	inc bc			;0c76
	inc de			;0c77
	inc de			;0c78
	inc de			;0c79
	ld a,c			;0c7a
	cp 0e2h		;0c7b
	jp nz,l0c71h		;0c7d
	ret			;0c80
	rst 38h			;0c81
	rst 38h			;0c82
	rst 38h			;0c83
sub_0c84h:
	ld a,(hl)			;0c84
	and 008h		;0c85
	ret z			;0c87
	nop			;0c88
	nop			;0c89
	inc l			;0c8a
	ld a,(hl)			;0c8b
	xor 004h		;0c8c
	ld (hl),a			;0c8e
	inc l			;0c8f
	inc l			;0c90
	ld a,(hl)			;0c91
	add a,004h		;0c92
	ld (hl),a			;0c94
	cp 0f9h		;0c95
	jp nc,l096eh		;0c97
	dec l			;0c9a
	call sub_0cb4h		;0c9b
	ld d,h			;0c9e
	ld a,l			;0c9f
	add a,020h		;0ca0
	ld e,a			;0ca2
	ex de,hl			;0ca3
	ld b,(hl)			;0ca4
	inc hl			;0ca5
	ld c,(hl)			;0ca6
	ld a,(bc)			;0ca7
	ex de,hl			;0ca8
	inc l			;0ca9
	cp 0e8h		;0caa
	jp nc,l096eh		;0cac
	ret			;0caf
	rst 38h			;0cb0
	rst 38h			;0cb1
	rst 38h			;0cb2
	rst 38h			;0cb3
sub_0cb4h:
	cp 0dch		;0cb4
	ret c			;0cb6
	cp 0e9h		;0cb7
	ret nc			;0cb9
	ld a,(0439fh)		;0cba
	cp (hl)			;0cbd
	ret c			;0cbe
	ld a,(0439eh)		;0cbf
	cp (hl)			;0cc2
	ret nc			;0cc3
sub_0cc4h:
	ld a,004h		;0cc4
	ld (043a4h),a		;0cc6
	ld a,060h		;0cc9
	ld (043a5h),a		;0ccb
	ld a,010h		;0cce
	ld (04363h),a		;0cd0
	ret			;0cd3
	rst 38h			;0cd4
	rst 38h			;0cd5
	rst 38h			;0cd6
	rst 38h			;0cd7
sub_0cd8h:
	ld bc,043cch		;0cd8
	ld de,043ech		;0cdb
l0cdeh:
	push bc			;0cde
	call sub_0718h		;0cdf
	pop bc			;0ce2
	ld a,c			;0ce3
	add a,004h		;0ce4
	ld c,a			;0ce6
	add a,020h		;0ce7
	ld e,a			;0ce9
	ld d,b			;0cea
	and a			;0ceb
	jp nz,l0cdeh		;0cec
	ret			;0cef
	rst 38h			;0cf0
	rst 38h			;0cf1
	rst 38h			;0cf2
	rst 38h			;0cf3
l0cf4h:
	pop de			;0cf4
	pop bc			;0cf5
	ret			;0cf6
	rst 38h			;0cf7
	rst 38h			;0cf8
	rst 38h			;0cf9
	rst 38h			;0cfa
	rst 38h			;0cfb
	rst 38h			;0cfc
	rst 38h			;0cfd
	rst 38h			;0cfe
	rst 38h			;0cff
	rst 38h			;0d00
	rst 38h			;0d01
l0d02h:
	rst 38h			;0d02
	rst 38h			;0d03
l0d04h:
	rst 38h			;0d04
l0d05h:
	rst 38h			;0d05
	rst 38h			;0d06
	rst 38h			;0d07
	ld hl,04393h		;0d08
	inc (hl)			;0d0b
	ld a,(hl)			;0d0c
	and 007h		;0d0d
	ret nz			;0d0f
	inc l			;0d10
	inc l			;0d11
	ld a,(hl)			;0d12
	inc a			;0d13
	and 00fh		;0d14
	ld (hl),a			;0d16
	ret			;0d17
	rst 38h			;0d18
	rst 38h			;0d19
	rst 38h			;0d1a
	rst 38h			;0d1b
sub_0d1ch:
	ld bc,04b70h		;0d1c
	ld hl,04b50h		;0d1f
l0d22h:
	call sub_0d30h		;0d22
	inc c			;0d25
	inc c			;0d26
	inc l			;0d27
	ld a,0b0h		;0d28
	cp c			;0d2a
	jp nz,l0d22h		;0d2b
	ret			;0d2e
	rst 38h			;0d2f
sub_0d30h:
	ld d,(hl)			;0d30
	inc hl			;0d31
	ld a,(bc)			;0d32
	inc bc			;0d33
	inc bc			;0d34
	and 008h		;0d35
	ret z			;0d37
	ld e,(hl)			;0d38
	ex de,hl			;0d39
	ld a,(hl)			;0d3a
	rlca			;0d3b
	add a,000h		;0d3c
	ld l,a			;0d3e
	ld h,017h		;0d3f
	xor a			;0d41
	cp (hl)			;0d42
	jp z,l0d4fh		;0d43
	inc hl			;0d46
	cp (hl)			;0d47
	jp z,l0d5eh		;0d48
	dec hl			;0d4b
	ld a,(bc)			;0d4c
	add a,(hl)			;0d4d
	ld (bc),a			;0d4e
l0d4fh:
	inc bc			;0d4f
	inc hl			;0d50
	ld a,(bc)			;0d51
	add a,(hl)			;0d52
	ld (bc),a			;0d53
	dec bc			;0d54
	and 007h		;0d55
	ex de,hl			;0d57
	ret nz			;0d58
	inc (hl)			;0d59
	ret			;0d5a
	rst 38h			;0d5b
	rst 38h			;0d5c
	rst 38h			;0d5d
l0d5eh:
	dec hl			;0d5e
	ld a,(bc)			;0d5f
	add a,(hl)			;0d60
	ld (bc),a			;0d61
	and 007h		;0d62
	ex de,hl			;0d64
	ret nz			;0d65
	inc (hl)			;0d66
	ret			;0d67
	rst 38h			;0d68
	rst 38h			;0d69
	rst 38h			;0d6a
	rst 38h			;0d6b
	rst 38h			;0d6c
	rst 38h			;0d6d
	rst 38h			;0d6e
	rst 38h			;0d6f
sub_0d70h:
	ld bc,04b70h		;0d70
	ld hl,04b50h		;0d73
l0d76h:
	call sub_0d86h		;0d76
	ld a,c			;0d79
	add a,004h		;0d7a
	ld c,a			;0d7c
	ld a,0b0h		;0d7d
	cp c			;0d7f
	jp nz,l0d76h		;0d80
	ret			;0d83
	rst 38h			;0d84
	rst 38h			;0d85
sub_0d86h:
	ld d,(hl)			;0d86
	inc hl			;0d87
	ld e,(hl)			;0d88
	inc hl			;0d89
	ld a,(bc)			;0d8a
	and 008h		;0d8b
	ret z			;0d8d
	ex de,hl			;0d8e
	ld a,(hl)			;0d8f
	and a			;0d90
	call z,sub_0ddeh		;0d91
	ld l,a			;0d94
	rlca			;0d95
	add a,l			;0d96
	add a,0a0h		;0d97
	ld l,a			;0d99
	ld h,016h		;0d9a
	ld a,(bc)			;0d9c
	and 0f8h		;0d9d
	or (hl)			;0d9f
	ld (bc),a			;0da0
	inc bc			;0da1
	inc bc			;0da2
	inc bc			;0da3
	inc hl			;0da4
	ld a,(hl)			;0da5
	inc hl			;0da6
	rrca			;0da7
	jp c,l0dbbh		;0da8
	rrca			;0dab
	jp c,l0dcch		;0dac
	ld a,(bc)			;0daf
	rrca			;0db0
	and 003h		;0db1
	add a,(hl)			;0db3
	dec bc			;0db4
	jp l0dd2h		;0db5
	rst 38h			;0db8
	rst 38h			;0db9
	rst 38h			;0dba
l0dbbh:
	ld a,(bc)			;0dbb
	rrca			;0dbc
	and 003h		;0dbd
	add a,(hl)			;0dbf
	ld h,a			;0dc0
	dec bc			;0dc1
	ld a,(bc)			;0dc2
	and 004h		;0dc3
	add a,h			;0dc5
	jp l0dd2h		;0dc6
	rst 38h			;0dc9
	rst 38h			;0dca
	rst 38h			;0dcb
l0dcch:
	dec bc			;0dcc
	ld a,(bc)			;0dcd
	rrca			;0dce
	and 003h		;0dcf
	add a,(hl)			;0dd1
l0dd2h:
	ld l,a			;0dd2
	ld h,016h		;0dd3
	ld a,(hl)			;0dd5
	dec bc			;0dd6
	ld (bc),a			;0dd7
	dec bc			;0dd8
	ex de,hl			;0dd9
	ret			;0dda
	rst 38h			;0ddb
	rst 38h			;0ddc
	rst 38h			;0ddd
sub_0ddeh:
	dec de			;0dde
	dec de			;0ddf
	ld a,(04394h)		;0de0
	ld (de),a			;0de3
	ld h,a			;0de4
	inc de			;0de5
	ld a,(04395h)		;0de6
	ld (de),a			;0de9
	ld l,a			;0dea
	inc de			;0deb
	ld a,(hl)			;0dec
	ret			;0ded
	rst 38h			;0dee
	rst 38h			;0def
sub_0df0h:
	ld bc,043c4h		;0df0
	ld hl,043e6h		;0df3
	call sub_0e10h		;0df6
	ld bc,043c8h		;0df9
	ld hl,043eah		;0dfc
	jp sub_0e10h		;0dff
l0e02h:
	ld bc,043cch		;0e02
	ld hl,043eeh		;0e05
	call sub_0e10h		;0e08
	ret			;0e0b
	rst 38h			;0e0c
	rst 38h			;0e0d
	rst 38h			;0e0e
	rst 38h			;0e0f
sub_0e10h:
	ld a,(bc)			;0e10
	and 008h		;0e11
	ret z			;0e13
	ld d,(hl)			;0e14
	inc l			;0e15
	ld e,(hl)			;0e16
	ld a,(de)			;0e17
	cp 0c0h		;0e18
	ret nc			;0e1a
	cp 060h		;0e1b
	ret c			;0e1d
	cp 068h		;0e1e
	jp nc,l0e39h		;0e20
	and 007h		;0e23
	rlca			;0e25
	rlca			;0e26
	add a,040h		;0e27
	ld l,a			;0e29
	ld h,017h		;0e2a
	inc bc			;0e2c
	inc bc			;0e2d
	ld a,(bc)			;0e2e
	and 007h		;0e2f
	cp (hl)			;0e31
	ret nc			;0e32
	inc hl			;0e33
	cp (hl)			;0e34
	ret c			;0e35
	jp l0e70h		;0e36
l0e39h:
	inc bc			;0e39
	inc bc			;0e3a
	ld a,(bc)			;0e3b
	ld d,a			;0e3c
	inc bc			;0e3d
	ld a,(bc)			;0e3e
	and 0f8h		;0e3f
	ld e,a			;0e41
	ld hl,04b70h		;0e42
l0e45h:
	ld a,(hl)			;0e45
	inc hl			;0e46
	inc hl			;0e47
	and 008h		;0e48
	call nz,sub_0e58h		;0e4a
	inc hl			;0e4d
	inc hl			;0e4e
	ld a,0b0h		;0e4f
	cp l			;0e51
	jp nz,l0e45h		;0e52
	ret			;0e55
	rst 38h			;0e56
	rst 38h			;0e57
sub_0e58h:
	ld a,d			;0e58
	cp (hl)			;0e59
	ret c			;0e5a
	ld a,(hl)			;0e5b
	add a,008h		;0e5c
	cp d			;0e5e
	ret c			;0e5f
	inc hl			;0e60
	ld a,(hl)			;0e61
	dec hl			;0e62
	add a,004h		;0e63
	cp e			;0e65
	ret c			;0e66
	sub 00ch		;0e67
	cp e			;0e69
	ret nc			;0e6a
	jp l0c00h		;0e6b
	rst 38h			;0e6e
	rst 38h			;0e6f
l0e70h:
	inc hl			;0e70
	ld a,(bc)			;0e71
	and 0f8h		;0e72
	add a,(hl)			;0e74
	ld d,a			;0e75
	inc bc			;0e76
	ld a,(bc)			;0e77
	and 0f8h		;0e78
	ld e,a			;0e7a
	ld hl,04b70h		;0e7b
l0e7eh:
	ld a,(hl)			;0e7e
	inc hl			;0e7f
	inc hl			;0e80
	and 008h		;0e81
	call nz,sub_0e90h		;0e83
	inc hl			;0e86
	inc hl			;0e87
	ld a,0b0h		;0e88
	cp l			;0e8a
	jp nz,l0e7eh		;0e8b
	ret			;0e8e
	rst 38h			;0e8f
sub_0e90h:
	ld a,(hl)			;0e90
	add a,002h		;0e91
	cp d			;0e93
	ret c			;0e94
	sub 005h		;0e95
	cp d			;0e97
	ret nc			;0e98
	inc hl			;0e99
	ld a,(hl)			;0e9a
	dec hl			;0e9b
	and 0f8h		;0e9c
	cp e			;0e9e
	ret nz			;0e9f
	ld de,l0c02h		;0ea0
	nop			;0ea3
l0ea4h:
	dec hl			;0ea4
	dec hl			;0ea5
	dec bc			;0ea6
	dec bc			;0ea7
	dec bc			;0ea8
	ld a,(bc)			;0ea9
	and 0f7h		;0eaa
	ld (bc),a			;0eac
l0eadh:
	ld a,(hl)			;0ead
	and 0f7h		;0eae
	ld (hl),a			;0eb0
	ld a,l			;0eb1
	add a,042h		;0eb2
	ld l,a			;0eb4
	ld b,(hl)			;0eb5
	inc hl			;0eb6
	ld c,(hl)			;0eb7
	ld hl,04378h		;0eb8
	ld a,d			;0ebb
	cp 010h		;0ebc
	jp z,l0ec3h		;0ebe
	ld l,070h		;0ec1
l0ec3h:
	ld a,(hl)			;0ec3
	and a			;0ec4
	jp z,l0ed5h		;0ec5
	inc l			;0ec8
	inc l			;0ec9
	inc l			;0eca
	inc l			;0ecb
	ld a,(hl)			;0ecc
	and a			;0ecd
	jp z,l0ed5h		;0ece
	inc l			;0ed1
	inc l			;0ed2
	inc l			;0ed3
	inc l			;0ed4
l0ed5h:
	ld (hl),d			;0ed5
	inc l			;0ed6
	ld (hl),e			;0ed7
	inc l			;0ed8
	ld (hl),b			;0ed9
	inc l			;0eda
	ld (hl),c			;0edb
	ld l,064h		;0edc
	ld (hl),0ffh		;0ede
	ld l,0bah		;0ee0
	dec (hl)			;0ee2
	pop hl			;0ee3
	pop hl			;0ee4
	jp (hl)			;0ee5
	rst 38h			;0ee6
	rst 38h			;0ee7
	rst 38h			;0ee8
	rst 38h			;0ee9
	rst 38h			;0eea
	rst 38h			;0eeb
	rst 38h			;0eec
	rst 38h			;0eed
	rst 38h			;0eee
	rst 38h			;0eef
	rst 38h			;0ef0
	rst 38h			;0ef1
	rst 38h			;0ef2
	rst 38h			;0ef3
	rst 38h			;0ef4
	rst 38h			;0ef5
	rst 38h			;0ef6
	rst 38h			;0ef7
	rst 38h			;0ef8
	rst 38h			;0ef9
	rst 38h			;0efa
	rst 38h			;0efb
	rst 38h			;0efc
	rst 38h			;0efd
	rst 38h			;0efe
	rst 38h			;0eff
l0f00h:
	ld hl,043a6h		;0f00
l0f03h:
	ld a,(hl)			;0f03
	cp 0c0h		;0f04
	jp nc,l0f74h		;0f06
	ld l,0e2h		;0f09
	ld d,(hl)			;0f0b
	inc l			;0f0c
	ld e,(hl)			;0f0d
	ld bc,l0202h		;0f0e
	call sub_0f56h		;0f11
	ret z			;0f14
	nop			;0f15
	nop			;0f16
	ld hl,0439eh		;0f17
	ld a,(hl)			;0f1a
	sub 006h		;0f1b
	ld b,a			;0f1d
	inc l			;0f1e
	ld c,(hl)			;0f1f
	ld hl,04b70h		;0f20
l0f23h:
	ld a,(hl)			;0f23
	inc l			;0f24
	inc l			;0f25
	and 008h		;0f26
	call nz,sub_0f38h		;0f28
	inc l			;0f2b
	inc l			;0f2c
	ld a,0b0h		;0f2d
	cp l			;0f2f
	jp nz,l0f23h		;0f30
	ret			;0f33
	rst 38h			;0f34
	rst 38h			;0f35
	rst 38h			;0f36
	rst 38h			;0f37
sub_0f38h:
	inc l			;0f38
	ld a,(hl)			;0f39
	dec l			;0f3a
	cp 0d2h		;0f3b
	ret c			;0f3d
	cp 0e7h		;0f3e
	ret nc			;0f40
	ld a,(hl)			;0f41
	cp c			;0f42
	ret nc			;0f43
	cp b			;0f44
	ret c			;0f45
	call sub_0cc4h		;0f46
	ld de,l0d04h		;0f49
	dec hl			;0f4c
	dec hl			;0f4d
	jp l0eadh		;0f4e
	xor l			;0f51
	ld c,0ffh		;0f52
	rst 38h			;0f54
	rst 38h			;0f55
sub_0f56h:
	push bc			;0f56
	push de			;0f57
l0f58h:
	ld a,(de)			;0f58
	cp 060h		;0f59
	jp c,l0f63h		;0f5b
	cp 0c0h		;0f5e
	jp c,l0cf4h		;0f60
l0f63h:
	inc de			;0f63
	dec b			;0f64
	jp nz,l0f58h		;0f65
	pop de			;0f68
	pop bc			;0f69
	call sub_0217h		;0f6a
	dec c			;0f6d
	jp nz,sub_0f56h		;0f6e
	ret			;0f71
	rst 38h			;0f72
	rst 38h			;0f73
l0f74h:
	ld l,0e2h		;0f74
	ld d,(hl)			;0f76
	inc l			;0f77
	ld e,(hl)			;0f78
	call sub_0217h		;0f79
	dec de			;0f7c
	ld bc,l0403h+1		;0f7d
	call sub_0f56h		;0f80
	ret z			;0f83
	nop			;0f84
	nop			;0f85
	ld a,(043c2h)		;0f86
	sub 00eh		;0f89
	ld b,a			;0f8b
	add a,02dh		;0f8c
	ld c,a			;0f8e
	ld hl,04b70h		;0f8f
l0f92h:
	ld a,(hl)			;0f92
	inc l			;0f93
	inc l			;0f94
	and 008h		;0f95
	call nz,sub_0fa6h		;0f97
	inc l			;0f9a
	inc l			;0f9b
	ld a,0b0h		;0f9c
	cp l			;0f9e
	jp nz,l0f92h		;0f9f
	ret			;0fa2
	rst 38h			;0fa3
	rst 38h			;0fa4
	rst 38h			;0fa5
sub_0fa6h:
	inc l			;0fa6
	ld a,(hl)			;0fa7
	dec l			;0fa8
	cp 0cah		;0fa9
	ret c			;0fab
	cp 0efh		;0fac
	ret nc			;0fae
	ld a,(hl)			;0faf
	cp c			;0fb0
	ret nc			;0fb1
	cp b			;0fb2
	ret c			;0fb3
	ld de,l0d02h		;0fb4
	dec hl			;0fb7
	dec hl			;0fb8
	jp l0eadh		;0fb9
	xor l			;0fbc
	ld c,0ffh		;0fbd
	rst 38h			;0fbf
l0fc0h:
	ld hl,04370h		;0fc0
	call sub_0fd8h		;0fc3
	ld hl,04374h		;0fc6
	call sub_0fd8h		;0fc9
	ld hl,04378h		;0fcc
	call sub_3758h		;0fcf
	ld hl,0437ch		;0fd2
	jp sub_3758h		;0fd5
sub_0fd8h:
	ld a,(hl)			;0fd8
	and a			;0fd9
	ret z			;0fda
	ld b,(hl)			;0fdb
	dec (hl)			;0fdc
	inc l			;0fdd
	inc l			;0fde
	ld d,(hl)			;0fdf
	inc l			;0fe0
	ld e,(hl)			;0fe1
	nop			;0fe2
	call sub_0210h		;0fe3
	ld a,b			;0fe6
	and 00eh		;0fe7
	rrca			;0fe9
	add a,0b0h		;0fea
	ld l,a			;0fec
	ld h,017h		;0fed
	ld l,(hl)			;0fef
	ex de,hl			;0ff0
	ld bc,0ffdfh		;0ff1
	jp l3540h		;0ff4
	ld l,b			;0ff7
	ld a,005h		;0ff8
	ld (04396h),a		;0ffa
	jp l0ea4h		;0ffd
l1000h:
	ld bc,l0101h		;1000
	ld bc,l0202h		;1003
	ld (bc),a			;1006
	ld (bc),a			;1007
	ld (bc),a			;1008
	ld (bc),a			;1009
	ld (bc),a			;100a
	ld (bc),a			;100b
	ld bc,l0101h		;100c
	ld bc,0ff00h		;100f
	rst 38h			;1012
	rst 38h			;1013
	rst 38h			;1014
	rst 38h			;1015
	rst 38h			;1016
	rst 38h			;1017
	rst 38h			;1018
	rst 38h			;1019
	rst 38h			;101a
	rst 38h			;101b
	rst 38h			;101c
	rst 38h			;101d
	rst 38h			;101e
	rst 38h			;101f
l1020h:
	djnz l1033h		;1020
	ld (de),a			;1022
	inc de			;1023
	djnz l1043h		;1024
	dec c			;1026
	ld c,00bh		;1027
	inc c			;1029
	dec c			;102a
	ld c,00bh		;102b
	inc c			;102d
	ld b,006h		;102e
	ld e,003h		;1030
	rra			;1032
l1033h:
	dec b			;1033
	inc e			;1034
	inc b			;1035
	dec e			;1036
	ld b,01eh		;1037
	inc bc			;1039
	inc bc			;103a
	inc bc			;103b
	inc bc			;103c
	inc bc			;103d
	rra			;103e
	inc e			;103f
	dec e			;1040
	ld e,003h		;1041
l1043h:
	inc bc			;1043
	inc bc			;1044
	inc bc			;1045
	inc bc			;1046
	rra			;1047
	dec b			;1048
	inc e			;1049
	inc b			;104a
	dec e			;104b
	ld b,01eh		;104c
	inc bc			;104e
	rra			;104f
	dec b			;1050
	dec b			;1051
	dec b			;1052
	dec b			;1053
	dec b			;1054
	dec b			;1055
	dec b			;1056
	dec b			;1057
	dec b			;1058
	dec b			;1059
	inc e			;105a
	inc b			;105b
	inc b			;105c
	ld de,l1312h		;105d
	nop			;1060
	rst 38h			;1061
	rst 38h			;1062
	rst 38h			;1063
	dec bc			;1064
	ld e,019h		;1065
	ld b,006h		;1067
	ld b,006h		;1069
	ld b,006h		;106b
	ld e,01fh		;106d
	inc e			;106f
	dec e			;1070
	ld b,006h		;1071
	ld b,006h		;1073
	ld b,01eh		;1075
	inc bc			;1077
	rra			;1078
	dec b			;1079
	inc e			;107a
	inc b			;107b
	dec e			;107c
	ld b,006h		;107d
	ld a,(de)			;107f
	inc b			;1080
	dec de			;1081
	dec b			;1082
	jr l109eh		;1083
	ld b,01ah		;1085
	inc b			;1087
	dec de			;1088
	dec b			;1089
	dec b			;108a
	inc e			;108b
	inc b			;108c
	dec e			;108d
	ld b,01eh		;108e
	inc bc			;1090
	rra			;1091
	dec b			;1092
	dec b			;1093
	dec b			;1094
	dec b			;1095
	dec b			;1096
	inc e			;1097
	dec e			;1098
	ld e,01fh		;1099
	dec b			;109b
	dec b			;109c
	dec b			;109d
l109eh:
	dec b			;109e
	dec b			;109f
	dec b			;10a0
	dec b			;10a1
	jr l10c3h		;10a2
	nop			;10a4
	rst 38h			;10a5
	rst 38h			;10a6
	rst 38h			;10a7
	djnz $+6		;10a8
	inc b			;10aa
	dec e			;10ab
	dec c			;10ac
	ld c,00bh		;10ad
	inc c			;10af
	dec c			;10b0
	ld c,001h		;10b1
	ld bc,l0101h		;10b3
	ld bc,l0101h		;10b6
	ld bc,l0505h		;10b9
	dec b			;10bc
	dec b			;10bd
	dec b			;10be
	inc e			;10bf
	inc b			;10c0
	inc b			;10c1
	dec e			;10c2
l10c3h:
	ld b,006h		;10c3
	ld e,003h		;10c5
	inc bc			;10c7
	rra			;10c8
	dec b			;10c9
	dec b			;10ca
	dec b			;10cb
	inc e			;10cc
	ld de,l1312h		;10cd
	nop			;10d0
	rst 38h			;10d1
	rst 38h			;10d2
	rst 38h			;10d3
	dec bc			;10d4
	inc c			;10d5
	dec c			;10d6
	ld c,00bh		;10d7
	inc c			;10d9
	dec c			;10da
	ld c,00bh		;10db
	inc c			;10dd
	ld a,(de)			;10de
	dec de			;10df
	dec b			;10e0
	jr l10fch		;10e1
	ld b,00dh		;10e3
	ld c,001h		;10e5
	ld bc,l0101h		;10e7
	ld bc,l0101h		;10ea
	ld bc,l0505h		;10ed
	inc e			;10f0
	dec de			;10f1
	dec b			;10f2
	dec b			;10f3
	inc e			;10f4
	inc b			;10f5
	dec de			;10f6
	dec b			;10f7
	dec b			;10f8
	inc e			;10f9
	inc b			;10fa
	dec de			;10fb
l10fch:
	nop			;10fc
	rst 38h			;10fd
	rst 38h			;10fe
	rst 38h			;10ff
l1100h:
	dec bc			;1100
	inc c			;1101
	dec c			;1102
	ld c,00bh		;1103
	inc c			;1105
	add hl,bc			;1106
	add hl,bc			;1107
	add hl,bc			;1108
	add hl,bc			;1109
	ld a,(bc)			;110a
	ld a,(bc)			;110b
	add hl,bc			;110c
	add hl,bc			;110d
	ld a,(bc)			;110e
	add hl,bc			;110f
	ld d,017h		;1110
	inc d			;1112
	rlca			;1113
	rlca			;1114
	rlca			;1115
	inc e			;1116
	inc b			;1117
	dec e			;1118
	ld b,01eh		;1119
	inc bc			;111b
	rra			;111c
	dec b			;111d
	inc e			;111e
	ex af,af'			;111f
	ex af,af'			;1120
	ex af,af'			;1121
	ex af,af'			;1122
	ex af,af'			;1123
	ex af,af'			;1124
	ex af,af'			;1125
	ex af,af'			;1126
	dec b			;1127
	dec b			;1128
	dec b			;1129
	dec b			;112a
	nop			;112b
	rst 38h			;112c
	rst 38h			;112d
	rst 38h			;112e
	rst 38h			;112f
	dec bc			;1130
	inc c			;1131
	dec c			;1132
	ld c,00bh		;1133
	inc c			;1135
	ld a,(bc)			;1136
	ld a,(bc)			;1137
	ld a,(bc)			;1138
	ld a,(bc)			;1139
	add hl,bc			;113a
	add hl,bc			;113b
	ld a,(bc)			;113c
	ld a,(bc)			;113d
	add hl,bc			;113e
	ld a,(bc)			;113f
	ld (de),a			;1140
	inc de			;1141
	djnz l114ch		;1142
	ex af,af'			;1144
	ex af,af'			;1145
	jr l114fh		;1146
	rlca			;1148
	rlca			;1149
	rlca			;114a
	dec b			;114b
l114ch:
	inc e			;114c
	inc b			;114d
	dec e			;114e
l114fh:
	ld b,01eh		;114f
	inc bc			;1151
	rra			;1152
	rlca			;1153
	rlca			;1154
	rlca			;1155
	rlca			;1156
	dec b			;1157
	dec b			;1158
	dec b			;1159
	dec b			;115a
	nop			;115b
	rst 38h			;115c
	rst 38h			;115d
	rst 38h			;115e
	rst 38h			;115f
	inc e			;1160
	inc b			;1161
	inc b			;1162
	inc b			;1163
	dec e			;1164
	ld b,00dh		;1165
	ld c,00bh		;1167
	inc c			;1169
	ld b,006h		;116a
	ld e,015h		;116c
	ld d,017h		;116e
	inc d			;1170
	add hl,de			;1171
	ld b,01ah		;1172
	inc b			;1174
	dec e			;1175
	ld b,01eh		;1176
	inc bc			;1178
	add hl,de			;1179
	ld b,01ah		;117a
	inc b			;117c
	dec e			;117d
	ld e,003h		;117e
	rra			;1180
	inc e			;1181
	inc b			;1182
	dec de			;1183
	dec b			;1184
	jr l118ah		;1185
	rra			;1187
	dec b			;1188
	inc e			;1189
l118ah:
	inc b			;118a
	dec de			;118b
	dec b			;118c
	jr l1192h		;118d
	dec d			;118f
	ld d,017h		;1190
l1192h:
	inc d			;1192
	rra			;1193
	dec b			;1194
	dec b			;1195
	dec b			;1196
	dec b			;1197
	dec b			;1198
	dec b			;1199
	dec b			;119a
	inc e			;119b
	inc b			;119c
	dec e			;119d
	ld a,(de)			;119e
	dec de			;119f
	nop			;11a0
	rst 38h			;11a1
	rst 38h			;11a2
	rst 38h			;11a3
	dec bc			;11a4
	inc c			;11a5
	dec c			;11a6
	ld c,00bh		;11a7
	inc c			;11a9
	dec c			;11aa
	ld c,00bh		;11ab
	inc c			;11ad
	dec c			;11ae
	ld c,002h		;11af
	ld (bc),a			;11b1
	ld (bc),a			;11b2
	ld (bc),a			;11b3
	ld (bc),a			;11b4
	ld (bc),a			;11b5
	ld (bc),a			;11b6
	ld (bc),a			;11b7
	dec b			;11b8
	dec b			;11b9
	jr l11bfh		;11ba
	add hl,de			;11bc
	ld a,(de)			;11bd
	inc b			;11be
l11bfh:
	dec de			;11bf
	dec b			;11c0
	jr $+5		;11c1
	rra			;11c3
	dec b			;11c4
	jr l11cah		;11c5
	rra			;11c7
	dec b			;11c8
	dec b			;11c9
l11cah:
	jr l11ebh		;11ca
	nop			;11cc
	rst 38h			;11cd
	rst 38h			;11ce
	rst 38h			;11cf
	dec bc			;11d0
	inc c			;11d1
	dec c			;11d2
	ld c,00bh		;11d3
	inc c			;11d5
	ld b,006h		;11d6
	add hl,bc			;11d8
	add hl,bc			;11d9
	add hl,bc			;11da
	ld a,(bc)			;11db
	add hl,bc			;11dc
	add hl,bc			;11dd
	ld a,(bc)			;11de
	add hl,bc			;11df
	add hl,bc			;11e0
	add hl,bc			;11e1
	ld b,01ah		;11e2
	inc b			;11e4
	ld de,l1312h		;11e5
	djnz l11f2h		;11e8
	ex af,af'			;11ea
l11ebh:
	ex af,af'			;11eb
	rlca			;11ec
	rlca			;11ed
	rlca			;11ee
	ex af,af'			;11ef
	ex af,af'			;11f0
	ex af,af'			;11f1
l11f2h:
	dec b			;11f2
	dec b			;11f3
	dec b			;11f4
	dec b			;11f5
	dec b			;11f6
	dec b			;11f7
	dec b			;11f8
	dec b			;11f9
	dec b			;11fa
	dec b			;11fb
	dec b			;11fc
	nop			;11fd
	rst 38h			;11fe
	rst 38h			;11ff
	inc e			;1200
	ld de,l1312h		;1201
	djnz l120ah		;1204
	dec e			;1206
	dec c			;1207
	ld c,00bh		;1208
l120ah:
	inc c			;120a
	dec c			;120b
	ld c,00bh		;120c
	inc c			;120e
	ld e,01fh		;120f
	dec b			;1211
	jr $+27		;1212
	dec c			;1214
	ld c,00bh		;1215
	inc c			;1217
	ld e,01fh		;1218
	dec b			;121a
	dec b			;121b
	dec b			;121c
	dec b			;121d
	dec b			;121e
	jr l123ah		;121f
	dec c			;1221
	ld c,00bh		;1222
	inc c			;1224
	ld b,01eh		;1225
	rra			;1227
	dec b			;1228
	dec b			;1229
	dec b			;122a
	dec b			;122b
	jr l1247h		;122c
	ld b,01eh		;122e
	rra			;1230
	dec b			;1231
	dec b			;1232
	dec b			;1233
	dec b			;1234
	dec b			;1235
	dec b			;1236
	dec b			;1237
	dec b			;1238
	inc e			;1239
l123ah:
	inc b			;123a
	inc b			;123b
	dec e			;123c
	ld a,(de)			;123d
	inc b			;123e
	dec de			;123f
l1240h:
	nop			;1240
	rst 38h			;1241
	rst 38h			;1242
	rst 38h			;1243
	jr $+5		;1244
	inc bc			;1246
l1247h:
	add hl,de			;1247
	ld b,006h		;1248
	ld b,006h		;124a
	ld b,006h		;124c
	ld b,006h		;124e
	ld b,006h		;1250
	ld b,006h		;1252
	ld a,(de)			;1254
	inc b			;1255
	dec de			;1256
	dec b			;1257
	inc e			;1258
	inc b			;1259
	dec e			;125a
	ld b,01eh		;125b
	inc bc			;125d
	inc bc			;125e
	add hl,de			;125f
l1260h:
	ld b,01ah		;1260
	inc b			;1262
	inc b			;1263
	inc b			;1264
	dec de			;1265
	dec b			;1266
	jr l126ch		;1267
	inc bc			;1269
	rra			;126a
	dec b			;126b
l126ch:
	inc e			;126c
	inc b			;126d
	dec e			;126e
	ld b,01ah		;126f
	inc b			;1271
	dec de			;1272
	dec b			;1273
	dec b			;1274
	dec b			;1275
	dec b			;1276
	dec b			;1277
	dec b			;1278
	dec b			;1279
	dec b			;127a
	dec b			;127b
	dec b			;127c
	dec b			;127d
	dec b			;127e
	jr l1284h		;127f
	add hl,de			;1281
	ld e,01fh		;1282
l1284h:
	nop			;1284
	rst 38h			;1285
	rst 38h			;1286
	rst 38h			;1287
	dec bc			;1288
	inc c			;1289
	ld a,(de)			;128a
	dec e			;128b
	ld e,003h		;128c
	add hl,de			;128e
	ld b,01ah		;128f
	inc b			;1291
	inc b			;1292
	dec e			;1293
	ld b,01eh		;1294
	inc bc			;1296
	inc bc			;1297
	inc bc			;1298
	add hl,de			;1299
	ld b,006h		;129a
	ld a,(de)			;129c
	inc b			;129d
	inc b			;129e
	inc b			;129f
	inc b			;12a0
	dec e			;12a1
	ld b,006h		;12a2
	ld e,003h		;12a4
	inc bc			;12a6
	inc bc			;12a7
	inc bc			;12a8
	inc bc			;12a9
	inc bc			;12aa
	rra			;12ab
	dec b			;12ac
	dec b			;12ad
	inc e			;12ae
	inc b			;12af
	inc b			;12b0
	inc b			;12b1
	inc b			;12b2
	dec de			;12b3
	dec b			;12b4
	dec b			;12b5
	jr l12bbh		;12b6
	inc bc			;12b8
	inc bc			;12b9
	rra			;12ba
l12bbh:
	dec b			;12bb
	inc e			;12bc
	inc b			;12bd
	inc b			;12be
	dec de			;12bf
	dec b			;12c0
	jr l12c6h		;12c1
	rra			;12c3
	inc e			;12c4
	dec de			;12c5
l12c6h:
	dec b			;12c6
	dec b			;12c7
	nop			;12c8
	rst 38h			;12c9
	jr l12cfh		;12ca
	add hl,de			;12cc
	ld b,006h		;12cd
l12cfh:
	ld b,006h		;12cf
	ld b,006h		;12d1
	ld a,(de)			;12d3
	dec e			;12d4
	ld e,019h		;12d5
	ld a,(de)			;12d7
	dec e			;12d8
	ld b,01eh		;12d9
	add hl,de			;12db
	ld b,01eh		;12dc
	dec d			;12de
	ld d,017h		;12df
	inc d			;12e1
	rlca			;12e2
	rlca			;12e3
	rlca			;12e4
	ex af,af'			;12e5
	ex af,af'			;12e6
	ex af,af'			;12e7
	ex af,af'			;12e8
	dec b			;12e9
	dec b			;12ea
	jr $+5		;12eb
	inc bc			;12ed
	add hl,de			;12ee
	ld b,006h		;12ef
	ld a,(de)			;12f1
	inc b			;12f2
	inc b			;12f3
	dec de			;12f4
	ex af,af'			;12f5
	ex af,af'			;12f6
	ex af,af'			;12f7
	ex af,af'			;12f8
	dec b			;12f9
	dec b			;12fa
	dec b			;12fb
	dec b			;12fc
	jr l131eh		;12fd
	nop			;12ff
l1300h:
	dec bc			;1300
	inc c			;1301
	ld a,(bc)			;1302
	ld a,(bc)			;1303
	add hl,bc			;1304
	add hl,bc			;1305
	add hl,bc			;1306
	ld a,(bc)			;1307
	ld a,(bc)			;1308
	add hl,bc			;1309
	add hl,bc			;130a
	add hl,bc			;130b
	ld a,(bc)			;130c
l130dh:
	add hl,bc			;130d
	add hl,bc			;130e
	ld d,017h		;130f
	inc d			;1311
l1312h:
	rlca			;1312
	rlca			;1313
	rlca			;1314
	ex af,af'			;1315
	ex af,af'			;1316
	ex af,af'			;1317
	ex af,af'			;1318
	rlca			;1319
	rlca			;131a
	ex af,af'			;131b
	ex af,af'			;131c
	ex af,af'			;131d
l131eh:
	ex af,af'			;131e
	rlca			;131f
	ex af,af'			;1320
	ld de,l1312h		;1321
	nop			;1324
	rst 38h			;1325
	rst 38h			;1326
	rst 38h			;1327
	dec bc			;1328
	inc c			;1329
	add hl,bc			;132a
	add hl,bc			;132b
	ld a,(bc)			;132c
	add hl,bc			;132d
	add hl,bc			;132e
	ld a,(bc)			;132f
l1330h:
	ld a,(bc)			;1330
	ld a,(bc)			;1331
	ld a,(bc)			;1332
	add hl,bc			;1333
	ld a,(bc)			;1334
	ld a,(bc)			;1335
	ld a,(bc)			;1336
	ld (de),a			;1337
	inc de			;1338
	djnz $+6		;1339
	inc b			;133b
	inc b			;133c
	dec de			;133d
	jr l1343h		;133e
	inc bc			;1340
	rlca			;1341
	rlca			;1342
l1343h:
	ex af,af'			;1343
	ex af,af'			;1344
	rlca			;1345
	rlca			;1346
	ex af,af'			;1347
	ex af,af'			;1348
	rlca			;1349
	rlca			;134a
	rlca			;134b
	rlca			;134c
	rlca			;134d
	nop			;134e
	rst 38h			;134f
	rst 38h			;1350
	rst 38h			;1351
	rst 38h			;1352
	rst 38h			;1353
	inc e			;1354
	ld de,l1312h		;1355
	djnz l1377h		;1358
	dec c			;135a
	ld c,00bh		;135b
	inc c			;135d
	add hl,bc			;135e
	ld a,(bc)			;135f
l1360h:
	add hl,bc			;1360
	add hl,bc			;1361
	ld a,(bc)			;1362
	add hl,bc			;1363
	add hl,bc			;1364
	add hl,bc			;1365
	ld b,01ah		;1366
	inc b			;1368
	dec de			;1369
	dec b			;136a
	jr l1370h		;136b
	add hl,de			;136d
	add hl,bc			;136e
	add hl,bc			;136f
l1370h:
	dec c			;1370
	ld c,00bh		;1371
	inc c			;1373
	dec c			;1374
	ld c,002h		;1375
l1377h:
	ld (bc),a			;1377
	ld (bc),a			;1378
	ld (bc),a			;1379
	ld (bc),a			;137a
	ld (bc),a			;137b
	ld (bc),a			;137c
	ld (bc),a			;137d
	ld (bc),a			;137e
	ld (bc),a			;137f
	ld (bc),a			;1380
	ld (bc),a			;1381
	ex af,af'			;1382
	rlca			;1383
	rlca			;1384
	ex af,af'			;1385
	rlca			;1386
	rlca			;1387
	ex af,af'			;1388
	ex af,af'			;1389
	rlca			;138a
	rlca			;138b
	rlca			;138c
	rlca			;138d
	rlca			;138e
	dec b			;138f
	dec b			;1390
	dec b			;1391
	dec b			;1392
	dec b			;1393
	dec b			;1394
	inc e			;1395
	ld de,l1312h		;1396
	nop			;1399
	rst 38h			;139a
	rst 38h			;139b
	dec bc			;139c
	inc c			;139d
	dec c			;139e
	ld c,00bh		;139f
	inc c			;13a1
	dec c			;13a2
	ld c,00bh		;13a3
	inc c			;13a5
	ld a,(de)			;13a6
	dec e			;13a7
	ld b,01eh		;13a8
	add hl,de			;13aa
	ld b,006h		;13ab
	ld a,(de)			;13ad
	inc b			;13ae
	dec de			;13af
	inc e			;13b0
	inc b			;13b1
	dec e			;13b2
	ld a,(de)			;13b3
	inc b			;13b4
	dec de			;13b5
	inc e			;13b6
	inc b			;13b7
	dec e			;13b8
	ld a,(de)			;13b9
	inc b			;13ba
	dec de			;13bb
	dec b			;13bc
	jr l13c6h		;13bd
	rlca			;13bf
	rlca			;13c0
	ex af,af'			;13c1
	ex af,af'			;13c2
	rlca			;13c3
	rlca			;13c4
	rlca			;13c5
l13c6h:
	rlca			;13c6
	ex af,af'			;13c7
	ex af,af'			;13c8
	rlca			;13c9
	rlca			;13ca
	rlca			;13cb
	rlca			;13cc
	nop			;13cd
	rst 38h			;13ce
	rst 38h			;13cf
	inc d			;13d0
	inc bc			;13d1
	add hl,de			;13d2
	dec c			;13d3
	ld c,00bh		;13d4
	inc c			;13d6
	ld a,(bc)			;13d7
	ld a,(bc)			;13d8
	ld a,(bc)			;13d9
	add hl,bc			;13da
	ld a,(bc)			;13db
	ld a,(bc)			;13dc
	ld a,(bc)			;13dd
	add hl,bc			;13de
	ld a,(bc)			;13df
	ld a,(bc)			;13e0
	ld a,(bc)			;13e1
	ld b,01eh		;13e2
	dec d			;13e4
	ld d,017h		;13e5
	inc d			;13e7
	inc bc			;13e8
	rra			;13e9
	dec b			;13ea
	dec b			;13eb
	ex af,af'			;13ec
	rlca			;13ed
	rlca			;13ee
	rlca			;13ef
	ex af,af'			;13f0
	rlca			;13f1
	rlca			;13f2
	rlca			;13f3
	ex af,af'			;13f4
	ex af,af'			;13f5
	dec b			;13f6
	dec b			;13f7
	dec b			;13f8
	dec b			;13f9
	dec b			;13fa
	nop			;13fb
	rst 38h			;13fc
	rst 38h			;13fd
	rst 38h			;13fe
	rst 38h			;13ff
	jr nc,l1442h		;1400
	ld sp,l3241h		;1402
	ld b,d			;1405
	inc sp			;1406
	ld b,e			;1407
	inc (hl)			;1408
	ld b,h			;1409
	dec (hl)			;140a
	ld b,l			;140b
	ld (hl),046h		;140c
	scf			;140e
	ld b,a			;140f
	jr c,l145ah		;1410
	add hl,sp			;1412
	ld c,c			;1413
	ld a,(03b4ah)		;1414
	ld c,e			;1417
	inc a			;1418
	ld c,h			;1419
	dec a			;141a
	ld c,l			;141b
	ld a,04eh		;141c
	ccf			;141e
	ld c,a			;141f
	ld h,b			;1420
	ld h,c			;1421
	ld h,d			;1422
	ld h,e			;1423
	ld h,h			;1424
	ld h,l			;1425
	ld h,(hl)			;1426
	ld h,a			;1427
	ld l,c			;1428
	nop			;1429
	ld l,c			;142a
	nop			;142b
	ld a,d			;142c
	ld a,e			;142d
	ld a,d			;142e
	ld a,e			;142f
	ld l,e			;1430
	nop			;1431
	ld l,e			;1432
	nop			;1433
	adc a,h			;1434
	adc a,l			;1435
	adc a,h			;1436
	adc a,l			;1437
	ld l,b			;1438
	nop			;1439
	ld l,b			;143a
	nop			;143b
	adc a,d			;143c
	sbc a,d			;143d
	adc a,d			;143e
	sbc a,d			;143f
	ld l,d			;1440
	nop			;1441
l1442h:
	ld l,d			;1442
	nop			;1443
	adc a,e			;1444
	sbc a,e			;1445
	adc a,e			;1446
	sbc a,e			;1447
	ld l,b			;1448
	nop			;1449
	ld l,e			;144a
	nop			;144b
	ld l,d			;144c
	nop			;144d
	ld l,c			;144e
	nop			;144f
	halt			;1450
	ld (hl),a			;1451
	ld (hl),h			;1452
	ld (hl),l			;1453
	ld (hl),d			;1454
	ld (hl),e			;1455
	ld (hl),b			;1456
	ld (hl),c			;1457
	ld l,b			;1458
	nop			;1459
l145ah:
	add a,(hl)			;145a
	sub (hl)			;145b
	ld l,c			;145c
	nop			;145d
	add a,a			;145e
	sub a			;145f
	ld l,d			;1460
	nop			;1461
	adc a,b			;1462
	sbc a,b			;1463
	ld l,e			;1464
	nop			;1465
	adc a,c			;1466
	sbc a,c			;1467
	ld l,b			;1468
	nop			;1469
	nop			;146a
	nop			;146b
	and d			;146c
	or d			;146d
	and e			;146e
	or e			;146f
	ld l,c			;1470
	nop			;1471
	nop			;1472
	nop			;1473
	and h			;1474
	or h			;1475
	and l			;1476
	or l			;1477
	ld l,d			;1478
	nop			;1479
	nop			;147a
	nop			;147b
	and (hl)			;147c
	or (hl)			;147d
	and a			;147e
	or a			;147f
	ld l,e			;1480
	nop			;1481
	nop			;1482
	nop			;1483
	xor b			;1484
	cp b			;1485
	xor c			;1486
	cp c			;1487
	rst 38h			;1488
	rst 38h			;1489
	rst 38h			;148a
	rst 38h			;148b
	adc a,d			;148c
	sbc a,d			;148d
	nop			;148e
	nop			;148f
	rst 38h			;1490
	rst 38h			;1491
	rst 38h			;1492
	rst 38h			;1493
	rst 38h			;1494
	rst 38h			;1495
	rst 38h			;1496
	rst 38h			;1497
	rst 38h			;1498
	rst 38h			;1499
	rst 38h			;149a
	rst 38h			;149b
	rst 38h			;149c
	rst 38h			;149d
	rst 38h			;149e
	rst 38h			;149f
	adc a,e			;14a0
	sbc a,e			;14a1
	nop			;14a2
	nop			;14a3
	rst 38h			;14a4
	rst 38h			;14a5
	rst 38h			;14a6
	rst 38h			;14a7
	adc a,(hl)			;14a8
	sbc a,(hl)			;14a9
	adc a,a			;14aa
	sbc a,a			;14ab
	and b			;14ac
	or b			;14ad
	and c			;14ae
	or c			;14af
	nop			;14b0
	nop			;14b1
	nop			;14b2
	nop			;14b3
	rst 38h			;14b4
	rst 38h			;14b5
	rst 38h			;14b6
	rst 38h			;14b7
	rst 38h			;14b8
	rst 38h			;14b9
	rst 38h			;14ba
	rst 38h			;14bb
	rst 38h			;14bc
	rst 38h			;14bd
	rst 38h			;14be
	rst 38h			;14bf
	sbc a,h			;14c0
	nop			;14c1
	nop			;14c2
	nop			;14c3
	add a,h			;14c4
	sub h			;14c5
	add a,l			;14c6
	sub l			;14c7
	add a,d			;14c8
	sub d			;14c9
	add a,e			;14ca
	sub e			;14cb
	add a,b			;14cc
	sub b			;14cd
	add a,c			;14ce
l14cfh:
	sub c			;14cf
	sbc a,l			;14d0
	nop			;14d1
	nop			;14d2
	nop			;14d3
	xor (hl)			;14d4
	cp (hl)			;14d5
	xor a			;14d6
	cp a			;14d7
	xor h			;14d8
	cp h			;14d9
	xor l			;14da
	nop			;14db
	xor d			;14dc
	cp d			;14dd
	xor e			;14de
	cp e			;14df
l14e0h:
	ld b,a			;14e0
	ld a,(07800h)		;14e1
	and 010h		;14e4
	ret z			;14e6
	ex de,hl			;14e7
	ld a,d			;14e8
	cp 018h		;14e9
	ret nz			;14eb
	ld a,e			;14ec
	cp 095h		;14ed
	ld (hl),022h		;14ef
	ret z			;14f1
	cp 09ah		;14f2
	ld (hl),013h		;14f4
	ret z			;14f6
l14f7h:
	cp 0b5h		;14f7
	ld (hl),024h		;14f9
	ret z			;14fb
	ld (hl),b			;14fc
	ret			;14fd
	rst 38h			;14fe
	rst 38h			;14ff
l1500h:
	ex af,af'			;1500
	ld l,h			;1501
	add hl,bc			;1502
	ld h,b			;1503
	ex af,af'			;1504
	ld l,h			;1505
	add hl,bc			;1506
l1507h:
	ld h,b			;1507
	ex af,af'			;1508
l1509h:
	ld l,h			;1509
	add hl,bc			;150a
	ld h,b			;150b
	ex af,af'			;150c
	ld l,h			;150d
	add hl,bc			;150e
	ld h,b			;150f
	ex af,af'			;1510
	ld l,h			;1511
	add hl,bc			;1512
l1513h:
	ld h,b			;1513
l1514h:
	ex af,af'			;1514
	ld l,h			;1515
	add hl,bc			;1516
	ld h,b			;1517
	ex af,af'			;1518
	ld l,h			;1519
	add hl,bc			;151a
	ld h,b			;151b
	add hl,bc			;151c
l151dh:
	ld h,b			;151d
	add hl,bc			;151e
	ld h,b			;151f
l1520h:
	djnz l1522h		;1520
l1522h:
	djnz l1524h		;1522
l1524h:
	djnz l1526h		;1524
l1526h:
	djnz l1528h		;1526
l1528h:
	djnz l152ah		;1528
l152ah:
	djnz l152ch		;152a
l152ch:
	djnz l152eh		;152c
l152eh:
	djnz l1530h		;152e
l1530h:
	djnz l1532h		;1530
l1532h:
	djnz l1534h		;1532
l1534h:
	djnz l1536h		;1534
l1536h:
	djnz l1538h		;1536
l1538h:
	djnz l153ah		;1538
l153ah:
	djnz l153ch		;153a
l153ch:
	djnz l153eh		;153c
l153eh:
	djnz l1540h		;153e
l1540h:
	ld d,b			;1540
	jr nz,l15b3h		;1541
	jr nz,l15a5h		;1543
	jr z,l15a7h		;1545
	jr c,l1599h		;1547
	ld b,b			;1549
	ld (hl),b			;154a
	ld b,b			;154b
	ld b,b			;154c
	jr c,l14cfh		;154d
	jr c,l1581h		;154f
	jr nc,$-110		;1551
l1553h:
	jr nc,$+34		;1553
	jr c,l14f7h		;1555
	jr c,$+26		;1557
	ld c,b			;1559
	xor b			;155a
	ld c,b			;155b
	ld h,b			;155c
	ld c,b			;155d
	ld h,b			;155e
	ld e,b			;155f
	ld h,b			;1560
	ld c,b			;1561
	ld h,b			;1562
	ld e,b			;1563
	ld c,b			;1564
	ld e,b			;1565
	ld a,b			;1566
l1567h:
	ld e,b			;1567
	jr c,l15bah		;1568
	adc a,b			;156a
	ld d,b			;156b
	jr z,l15b6h		;156c
	sbc a,b			;156e
	ld c,b			;156f
	jr l15b2h		;1570
	xor b			;1572
	ld b,b			;1573
	jr $+50		;1574
	xor b			;1576
	jr nc,l15a1h		;1577
	jr z,l1513h		;1579
l157bh:
	jr z,l15b5h		;157b
l157dh:
	jr nz,l1507h		;157d
	jr nz,l15e1h		;157f
l1581h:
	jr nz,l15d3h		;1581
	jr nz,l15f5h		;1583
	jr nz,l15c7h		;1585
	jr z,l1509h		;1587
	jr z,l15bbh		;1589
	jr nc,l151dh		;158b
	jr nc,l15afh		;158d
l158fh:
	jr c,$-94		;158f
	jr c,l15f3h		;1591
	ld e,b			;1593
	ld d,b			;1594
	ld e,b			;1595
	ld (hl),b			;1596
	ld e,b			;1597
	ld b,b			;1598
l1599h:
	ld e,b			;1599
	add a,b			;159a
	ld e,b			;159b
	jr nc,$+90		;159c
	sub b			;159e
	ld e,b			;159f
	ld h,b			;15a0
l15a1h:
	jr nz,l15f3h		;15a1
	jr z,l1615h		;15a3
l15a5h:
	jr z,l15e7h		;15a5
l15a7h:
	jr nc,$-126		;15a7
	jr nc,l15dbh		;15a9
	jr c,$-110		;15ab
	jr c,l15cfh		;15ad
l15afh:
	ld b,b			;15af
	and b			;15b0
	ld b,b			;15b1
l15b2h:
	ld h,b			;15b2
l15b3h:
	ld e,b			;15b3
	ld d,b			;15b4
l15b5h:
	ld e,b			;15b5
l15b6h:
	ld (hl),b			;15b6
	ld e,b			;15b7
	ld b,b			;15b8
	ld d,b			;15b9
l15bah:
	add a,b			;15ba
l15bbh:
	ld d,b			;15bb
	jr nc,l1606h		;15bc
	sub b			;15be
	ld c,b			;15bf
	ld h,b			;15c0
	ld e,b			;15c1
	ld d,b			;15c2
	ld d,b			;15c3
	ld (hl),b			;15c4
	ld d,b			;15c5
	ld h,b			;15c6
l15c7h:
	ld c,b			;15c7
	ld b,b			;15c8
	ld c,b			;15c9
	add a,b			;15ca
	ld c,b			;15cb
	ld d,b			;15cc
	ld b,b			;15cd
	ld (hl),b			;15ce
l15cfh:
	ld b,b			;15cf
	ld b,b			;15d0
	jr c,l1553h		;15d1
l15d3h:
	jr c,l1605h		;15d3
	jr nc,l1567h		;15d5
	jr nc,l15f9h		;15d7
	jr z,l157bh		;15d9
l15dbh:
	jr z,l15edh		;15db
	jr nz,l158fh		;15dd
	jr nz,l1641h		;15df
l15e1h:
	jr nz,l1633h		;15e1
	jr z,l1655h		;15e3
	jr z,l1627h		;15e5
l15e7h:
	jr nc,$-126		;15e7
	jr nc,l161bh		;15e9
	jr c,l157dh		;15eb
l15edh:
	jr c,$+34		;15ed
	ld b,b			;15ef
	and b			;15f0
	ld b,b			;15f1
	ld h,b			;15f2
l15f3h:
	jr nz,l1645h		;15f3
l15f5h:
	jr z,l1667h		;15f5
	jr z,l1639h		;15f7
l15f9h:
	jr nc,l157bh		;15f9
	jr nc,l162dh		;15fb
	jr c,l158fh		;15fd
	jr c,$+18		;15ff
	inc d			;1601
	jr l1620h		;1602
	nop			;1604
l1605h:
	inc b			;1605
l1606h:
	ex af,af'			;1606
	inc c			;1607
	jr nz,l162ch		;1608
	inc h			;160a
	ld h,028h		;160b
	ld hl,(l2e2ch)		;160d
	jr nc,l1644h		;1610
	inc (hl)			;1612
	ld (hl),038h		;1613
l1615h:
	ld a,(l3e3ch)		;1615
	ld b,b			;1618
	ld b,d			;1619
	ld b,h			;161a
l161bh:
	ld b,(hl)			;161b
	ld e,h			;161c
	ld e,h			;161d
	ld e,(hl)			;161e
	ld e,(hl)			;161f
l1620h:
	ld d,b			;1620
	ld d,c			;1621
	ld d,d			;1622
	ld d,e			;1623
	ld d,h			;1624
	ld d,l			;1625
	ld d,(hl)			;1626
l1627h:
	ld d,a			;1627
	rst 38h			;1628
	rst 38h			;1629
	rst 38h			;162a
	rst 38h			;162b
l162ch:
	rst 38h			;162c
l162dh:
	rst 38h			;162d
	rst 38h			;162e
	rst 38h			;162f
	ld c,b			;1630
	ld c,b			;1631
	ld d,b			;1632
l1633h:
	ld d,b			;1633
	ld c,d			;1634
	ld c,d			;1635
	ld d,d			;1636
	ld d,d			;1637
	ld c,h			;1638
l1639h:
	ld c,h			;1639
	ld d,h			;163a
	ld d,h			;163b
	ld c,(hl)			;163c
	ld c,(hl)			;163d
	ld d,(hl)			;163e
	ld d,(hl)			;163f
	ld c,b			;1640
l1641h:
	ld c,b			;1641
	ld d,(hl)			;1642
	ld d,(hl)			;1643
l1644h:
	ld c,(hl)			;1644
l1645h:
	ld c,(hl)			;1645
	ld d,h			;1646
	ld d,h			;1647
	ld c,h			;1648
	ld c,h			;1649
	ld d,d			;164a
	ld d,d			;164b
	ld c,d			;164c
	ld c,d			;164d
	ld d,b			;164e
	ld d,b			;164f
	ld l,b			;1650
	ld l,b			;1651
	ld l,h			;1652
	ld l,h			;1653
	ld (hl),b			;1654
l1655h:
	ld (hl),b			;1655
	ld (hl),h			;1656
	ld (hl),h			;1657
	ld a,b			;1658
	ld a,b			;1659
	ld a,h			;165a
	ld a,h			;165b
	add a,b			;165c
	add a,b			;165d
	add a,h			;165e
	add a,h			;165f
	ld l,b			;1660
	ld l,b			;1661
	add a,h			;1662
	add a,h			;1663
	add a,b			;1664
	add a,b			;1665
	ld a,h			;1666
l1667h:
	ld a,h			;1667
	ld a,b			;1668
	ld a,b			;1669
	ld (hl),h			;166a
	ld (hl),h			;166b
	ld (hl),b			;166c
	ld (hl),b			;166d
	ld l,h			;166e
	ld l,h			;166f
	ld e,b			;1670
	ld e,b			;1671
	ld e,d			;1672
	ld e,d			;1673
	ld e,h			;1674
	ld e,h			;1675
	ld e,(hl)			;1676
	ld e,(hl)			;1677
	ld h,b			;1678
	ld h,b			;1679
	ld h,d			;167a
	ld h,d			;167b
	ld h,h			;167c
	ld h,h			;167d
	ld h,(hl)			;167e
	ld h,(hl)			;167f
	ld a,b			;1680
	rst 38h			;1681
	and b			;1682
	rst 38h			;1683
	rst 38h			;1684
	xor b			;1685
	rst 38h			;1686
	xor h			;1687
	ret nz			;1688
	rst 38h			;1689
	ret z			;168a
	rst 38h			;168b
	rst 38h			;168c
	call nz,0ccffh		;168d
	ret nc			;1690
	rst 38h			;1691
	ret c			;1692
	rst 38h			;1693
	rst 38h			;1694
	call nc,0dcffh		;1695
	rst 38h			;1698
	rst 38h			;1699
	rst 38h			;169a
	rst 38h			;169b
	rst 38h			;169c
	rst 38h			;169d
	rst 38h			;169e
	rst 38h			;169f
	rst 38h			;16a0
	rst 38h			;16a1
	rst 38h			;16a2
	ld bc,l0800h+2		;16a3
	ld bc,l0800h+2		;16a6
	ld bc,l0c02h		;16a9
	ld bc,l1000h+2		;16ac
	inc bc			;16af
	inc b			;16b0
	inc d			;16b1
	inc bc			;16b2
	inc b			;16b3
	jr $+6		;16b4
	ld bc,l0488h		;16b6
	ld bc,00490h		;16b9
	ld bc,00480h		;16bc
	ld bc,sub_0380h		;16bf
	inc b			;16c2
	ld (hl),b			;16c3
	inc bc			;16c4
	inc b			;16c5
	ld (hl),h			;16c6
	inc bc			;16c7
	inc b			;16c8
	ld a,b			;16c9
	inc bc			;16ca
	inc b			;16cb
	ld a,h			;16cc
	rst 38h			;16cd
	rst 38h			;16ce
	rst 38h			;16cf
	ld bc,sub_3000h+2		;16d0
	ld bc,03402h		;16d3
	ld bc,sub_3800h+2		;16d6
	ld bc,l3c02h		;16d9
	ld bc,04002h		;16dc
	ld bc,04402h		;16df
	ld bc,04802h		;16e2
	ld bc,04c02h		;16e5
	inc b			;16e8
	inc b			;16e9
	ld d,b			;16ea
	inc b			;16eb
	inc b			;16ec
	ld d,h			;16ed
	inc b			;16ee
	inc b			;16ef
	ld e,b			;16f0
	inc b			;16f1
	inc b			;16f2
	ld e,h			;16f3
	inc b			;16f4
	inc b			;16f5
	ld h,b			;16f6
	inc b			;16f7
	inc b			;16f8
	ld h,h			;16f9
	inc b			;16fa
	inc b			;16fb
	ld l,b			;16fc
	inc b			;16fd
	inc b			;16fe
	ld l,h			;16ff
	rst 38h			;1700
	rst 38h			;1701
	ld bc,0ff00h		;1702
	nop			;1705
	inc b			;1706
	nop			;1707
	call m,l0000h		;1708
	call m,sub_0400h		;170b
	inc b			;170e
	cp 0fch		;170f
	cp 004h		;1711
	ld (bc),a			;1713
	call m,l0002h		;1714
	inc b			;1717
	nop			;1718
	inc b			;1719
	nop			;171a
	inc b			;171b
	nop			;171c
	inc b			;171d
	rst 38h			;171e
	rst 38h			;171f
	call m,0fc00h		;1720
	nop			;1723
	call m,0fc00h		;1724
	nop			;1727
	inc b			;1728
	nop			;1729
	inc b			;172a
	nop			;172b
	inc b			;172c
	nop			;172d
	inc b			;172e
	nop			;172f
	inc b			;1730
	call m,l0403h+1		;1731
	call m,0fc04h		;1734
	call m,0fcfch		;1737
	call m,l0403h+1		;173a
	inc b			;173d
	inc b			;173e
	call m,l0008h		;173f
	nop			;1742
	rst 38h			;1743
	ld bc,0f800h		;1744
	rst 38h			;1747
	ex af,af'			;1748
	ld bc,0ff02h		;1749
	inc b			;174c
	nop			;174d
	jp m,l08ffh		;174e
	ld bc,0ff04h		;1751
	ex af,af'			;1754
	nop			;1755
	call m,l08ffh		;1756
	dec b			;1759
	ld b,0ffh		;175a
	ex af,af'			;175c
	nop			;175d
	cp 0ffh		;175e
	djnz $+18		;1760
	adc a,b			;1762
	adc a,b			;1763
	djnz l1776h		;1764
	djnz l1778h		;1766
	rst 38h			;1768
	rst 38h			;1769
	rst 38h			;176a
	rst 38h			;176b
	rst 38h			;176c
	rst 38h			;176d
	rst 38h			;176e
	rst 38h			;176f
l1770h:
	call pe,0fdfch		;1770
	call p,sub_30edh		;1773
l1776h:
	ld b,b			;1776
	push af			;1777
l1778h:
	xor 031h		;1778
	ld b,c			;177a
	or 0efh		;177b
	rst 38h			;177d
	cp 0f7h		;177e
	ret pe			;1780
	ret m			;1781
	ld sp,hl			;1782
	ret p			;1783
	jp (hl)			;1784
	jr nc,l17c7h		;1785
	pop af			;1787
	jp pe,04131h		;1788
	jp p,0fbebh		;178b
	jp m,0e8f3h		;178e
	ret m			;1791
	ld sp,hl			;1792
	ret p			;1793
	jp (hl)			;1794
	call po,0f1e6h		;1795
	jp pe,0e7e5h		;1798
	jp p,0fbebh		;179b
	jp m,000f3h		;179e
	nop			;17a1
	nop			;17a2
	nop			;17a3
	nop			;17a4
	call po,sub_00e6h		;17a5
	nop			;17a8
	push hl			;17a9
	rst 20h			;17aa
	nop			;17ab
	nop			;17ac
	nop			;17ad
	nop			;17ae
	nop			;17af
	ret p			;17b0
	jp z,0bec4h		;17b1
	cp b			;17b4
	cp (hl)			;17b5
	cp b			;17b6
	cp (hl)			;17b7
	ret z			;17b8
	ret c			;17b9
	ret			;17ba
	exx			;17bb
	jp z,0cbdah		;17bc
	in a,(0cch)		;17bf
	call c,0ddcdh		;17c1
	ret nz			;17c4
	pop bc			;17c5
	pop bc			;17c6
l17c7h:
	jp nz,0c000h		;17c7
	nop			;17ca
	nop			;17cb
	nop			;17cc
	jp l0000h		;17cd
l17d0h:
	call nz,0c5d4h		;17d0
	push de			;17d3
	jp 0c3c3h		;17d4
	jp 0d6c6h		;17d7
	rst 0			;17da
	rst 10h			;17db
	rst 38h			;17dc
	rst 38h			;17dd
	rst 38h			;17de
	rst 38h			;17df
sub_17e0h:
	ld a,(07800h)		;17e0
	and 010h		;17e3
	ld a,(0438fh)		;17e5
	ret z			;17e8
	rrca			;17e9
	and 00fh		;17ea
	ret			;17ec
	rst 38h			;17ed
	rst 38h			;17ee
	rst 38h			;17ef
l17f0h:
	nop			;17f0
	nop			;17f1
	nop			;17f2
	nop			;17f3
	nop			;17f4
	nop			;17f5
	nop			;17f6
	nop			;17f7
	nop			;17f8
	nop			;17f9
	nop			;17fa
	nop			;17fb
	nop			;17fc
	nop			;17fd
	nop			;17fe
	nop			;17ff
l1800h:
	ld b,e			;1800
l1801h:
	jr nz,$+1		;1801
	rst 38h			;1803
	rst 38h			;1804
	rst 38h			;1805
	nop			;1806
	inc de			;1807
	inc bc			;1808
	rrca			;1809
	ld (de),a			;180a
	dec b			;180b
	ld hl,l0000h		;180c
	ex af,af'			;180f
	add hl,bc			;1810
	dec hl			;1811
	inc de			;1812
	inc bc			;1813
	rrca			;1814
	ld (de),a			;1815
	dec b			;1816
	nop			;1817
	nop			;1818
	inc de			;1819
	inc bc			;181a
	rrca			;181b
	ld (de),a			;181c
	dec b			;181d
	ld (04300h),hl		;181e
	ld hl,0ffffh		;1821
	rst 38h			;1824
	rst 38h			;1825
	nop			;1826
	jr nz,l1849h		;1827
	jr nz,$+34		;1829
	jr nz,l184dh		;182b
	nop			;182d
	nop			;182e
	nop			;182f
	jr nz,l1852h		;1830
	jr nz,$+34		;1832
	jr nz,$+34		;1834
	nop			;1836
	nop			;1837
	nop			;1838
	jr nz,l185bh		;1839
	jr nz,$+34		;183b
l183dh:
	jr nz,l185fh		;183d
	nop			;183f
	ld b,e			;1840
	ld (0ffffh),hl		;1841
	rst 38h			;1844
	rst 38h			;1845
	nop			;1846
	nop			;1847
	nop			;1848
l1849h:
	ld a,a			;1849
	jr nz,l184ch		;184a
l184ch:
	nop			;184c
l184dh:
	nop			;184d
	nop			;184e
	nop			;184f
	inc bc			;1850
	rrca			;1851
l1852h:
	add hl,bc			;1852
	ld c,020h		;1853
	jr nz,l1857h		;1855
l1857h:
	nop			;1857
	nop			;1858
	nop			;1859
	nop			;185a
l185bh:
	ld a,a			;185b
	jr nz,l185eh		;185c
l185eh:
	nop			;185e
l185fh:
	nop			;185f
l1860h:
	ld b,e			;1860
	dec h			;1861
	rst 38h			;1862
	rst 38h			;1863
	rst 38h			;1864
	rst 38h			;1865
	nop			;1866
	nop			;1867
	nop			;1868
	nop			;1869
	nop			;186a
	nop			;186b
	nop			;186c
	add hl,bc			;186d
	ld c,013h		;186e
	dec b			;1870
	ld (de),a			;1871
	inc d			;1872
	nop			;1873
	nop			;1874
	inc bc			;1875
	rrca			;1876
	add hl,bc			;1877
	ld c,000h		;1878
	nop			;187a
	nop			;187b
	nop			;187c
	nop			;187d
	nop			;187e
	nop			;187f
	ld b,e			;1880
	daa			;1881
	rst 38h			;1882
	rst 38h			;1883
	rst 38h			;1884
	rst 38h			;1885
	nop			;1886
	nop			;1887
	nop			;1888
	rra			;1889
	nop			;188a
	ld hl,l0c10h		;188b
	ld bc,00519h		;188e
	ld (de),a			;1891
	nop			;1892
	nop			;1893
	nop			;1894
	ld hl,l0f03h		;1895
	add hl,bc			;1898
	ld c,000h		;1899
	nop			;189b
	rra			;189c
	nop			;189d
	nop			;189e
	nop			;189f
	ld b,e			;18a0
	add hl,hl			;18a1
	rst 38h			;18a2
	rst 38h			;18a3
	rst 38h			;18a4
	rst 38h			;18a5
	nop			;18a6
	nop			;18a7
	nop			;18a8
	rra			;18a9
	nop			;18aa
	ld (l0c10h),hl		;18ab
	ld bc,00519h		;18ae
	ld (de),a			;18b1
	inc de			;18b2
	nop			;18b3
	nop			;18b4
	ld (l0f03h),hl		;18b5
	add hl,bc			;18b8
	ld c,013h		;18b9
	nop			;18bb
	rra			;18bc
	nop			;18bd
	nop			;18be
	nop			;18bf
	ld b,e			;18c0
	ld l,0ffh		;18c1
	rst 38h			;18c3
	rst 38h			;18c4
	rst 38h			;18c5
	nop			;18c6
	nop			;18c7
	nop			;18c8
	inc de			;18c9
	inc bc			;18ca
	rrca			;18cb
	ld (de),a			;18cc
	dec b			;18cd
	nop			;18ce
	ld bc,00516h		;18cf
	ld (de),a			;18d2
	ld bc,sub_0506h+1		;18d3
	nop			;18d6
	inc d			;18d7
	ld bc,l0c02h		;18d8
	dec b			;18db
	nop			;18dc
	nop			;18dd
	nop			;18de
	nop			;18df
	ld b,e			;18e0
	jr nc,$+1		;18e1
	rst 38h			;18e3
	rst 38h			;18e4
	rst 38h			;18e5
	nop			;18e6
	nop			;18e7
	nop			;18e8
	nop			;18e9
	nop			;18ea
	nop			;18eb
	nop			;18ec
	nop			;18ed
	ld (l0020h),hl		;18ee
	inc h			;18f1
	jr nz,l18f4h		;18f2
l18f4h:
	jr z,l1916h		;18f4
	nop			;18f6
	nop			;18f7
	nop			;18f8
	nop			;18f9
	nop			;18fa
	nop			;18fb
	nop			;18fc
	nop			;18fd
	nop			;18fe
	nop			;18ff
	ld b,e			;1900
	inc sp			;1901
	rst 38h			;1902
	rst 38h			;1903
	rst 38h			;1904
	rst 38h			;1905
	nop			;1906
	nop			;1907
	nop			;1908
	nop			;1909
	nop			;190a
	nop			;190b
	nop			;190c
	nop			;190d
	ld (l2020h),hl		;190e
	nop			;1911
	nop			;1912
	nop			;1913
	nop			;1914
	nop			;1915
l1916h:
	nop			;1916
	nop			;1917
	nop			;1918
	nop			;1919
	nop			;191a
	nop			;191b
	nop			;191c
	nop			;191d
	nop			;191e
	nop			;191f
	ld b,e			;1920
	ld (hl),0ffh		;1921
	rst 38h			;1923
	rst 38h			;1924
	rst 38h			;1925
	nop			;1926
	nop			;1927
	nop			;1928
	nop			;1929
	nop			;192a
	nop			;192b
	nop			;192c
	nop			;192d
	dec h			;192e
	jr nz,l1931h		;192f
l1931h:
	ld hl,l2020h		;1931
	nop			;1934
	cpl			;1935
	dec de			;1936
	ld hl,l2020h		;1937
	dec hl			;193a
	jr z,l195dh		;193b
	jr nz,l195bh		;193d
	nop			;193f
	ld b,e			;1940
	add hl,sp			;1941
	rst 38h			;1942
	rst 38h			;1943
	rst 38h			;1944
	rst 38h			;1945
	nop			;1946
	nop			;1947
	nop			;1948
	nop			;1949
	nop			;194a
	nop			;194b
	nop			;194c
	nop			;194d
	ld hl,l2020h		;194e
	jr nz,l197eh		;1951
	add hl,hl			;1953
	jr nz,l1976h		;1954
	jr nz,l1958h		;1956
l1958h:
	nop			;1958
	nop			;1959
	nop			;195a
l195bh:
	nop			;195b
	nop			;195c
l195dh:
	nop			;195d
	nop			;195e
	nop			;195f
l1960h:
	ld b,e			;1960
	inc a			;1961
	nop			;1962
	nop			;1963
	ld (l1020h+1),a		;1964
	ex af,af'			;1967
	rrca			;1968
	dec b			;1969
	ld c,009h		;196a
	jr $+128		;196c
	nop			;196e
	inc bc			;196f
	rrca			;1970
	djnz $+27		;1971
	ld (de),a			;1973
	add hl,bc			;1974
	rlca			;1975
l1976h:
	ex af,af'			;1976
	inc d			;1977
	nop			;1978
	ld hl,l2829h		;1979
	jr nz,l197eh		;197c
l197eh:
	nop			;197e
	nop			;197f
	ld b,e			;1980
	dec a			;1981
	ld (bc),a			;1982
	dec b			;1983
	ld hl,00028h		;1984
	ld bc,l130dh		;1987
	inc d			;198a
	ld bc,l0012h		;198b
	dec b			;198e
	inc c			;198f
	dec b			;1990
	inc bc			;1991
	inc d			;1992
	ld (de),a			;1993
	rrca			;1994
	ld c,009h		;1995
	inc bc			;1997
	inc de			;1998
	nop			;1999
	inc bc			;199a
	rrca			;199b
	ld (de),a			;199c
	djnz l19c9h		;199d
	nop			;199f
	ld b,e			;19a0
	ld a,0ffh		;19a1
	rst 38h			;19a3
	rst 38h			;19a4
	rst 38h			;19a5
	nop			;19a6
	nop			;19a7
	djnz $+10		;19a8
	rrca			;19aa
	dec b			;19ab
	ld c,009h		;19ac
	jr l19b0h		;19ae
l19b0h:
	ld bc,l2a1ah		;19b0
	nop			;19b3
	dec d			;19b4
	ld hl,(l2a13h)		;19b5
	ld bc,l002ah		;19b8
	nop			;19bb
	nop			;19bc
	nop			;19bd
	nop			;19be
	nop			;19bf
l19c0h:
	ld b,e			;19c0
	jr z,$+1		;19c1
	rst 38h			;19c3
	rst 38h			;19c4
	rst 38h			;19c5
	nop			;19c6
	nop			;19c7
	nop			;19c8
l19c9h:
	nop			;19c9
	nop			;19ca
	nop			;19cb
	nop			;19cc
	nop			;19cd
	nop			;19ce
	nop			;19cf
	nop			;19d0
	djnz l19e8h		;19d1
	inc de			;19d3
	ex af,af'			;19d4
	nop			;19d5
	nop			;19d6
	nop			;19d7
	nop			;19d8
	nop			;19d9
	nop			;19da
	nop			;19db
	nop			;19dc
	nop			;19dd
	nop			;19de
	nop			;19df
	ld b,e			;19e0
	inc l			;19e1
	rst 38h			;19e2
	rst 38h			;19e3
	rst 38h			;19e4
	rst 38h			;19e5
	nop			;19e6
	nop			;19e7
l19e8h:
	nop			;19e8
	nop			;19e9
	rrca			;19ea
	ld c,00ch		;19eb
	add hl,de			;19ed
	nop			;19ee
	ld hl,l0c10h		;19ef
	ld bc,00519h		;19f2
	ld (de),a			;19f5
	nop			;19f6
	ld (bc),a			;19f7
	dec d			;19f8
	inc d			;19f9
	inc d			;19fa
	rrca			;19fb
	ld c,000h		;19fc
	nop			;19fe
	nop			;19ff
l1a00h:
	ld b,e			;1a00
	jr z,$+1		;1a01
	rst 38h			;1a03
	rst 38h			;1a04
	rst 38h			;1a05
	nop			;1a06
	nop			;1a07
	nop			;1a08
	nop			;1a09
	nop			;1a0a
	nop			;1a0b
	nop			;1a0c
	nop			;1a0d
	rlca			;1a0e
	ld bc,0050dh		;1a0f
	nop			;1a12
	nop			;1a13
	rrca			;1a14
	ld d,005h		;1a15
	ld (de),a			;1a17
	nop			;1a18
	nop			;1a19
	nop			;1a1a
	nop			;1a1b
	nop			;1a1c
	nop			;1a1d
	nop			;1a1e
	nop			;1a1f
	ld b,e			;1a20
	jr z,l1a23h		;1a21
l1a23h:
	rst 38h			;1a23
	rst 38h			;1a24
	rst 38h			;1a25
	ld h,h			;1a26
	ld h,l			;1a27
	ld h,h			;1a28
	ld h,l			;1a29
	ld h,h			;1a2a
	ld h,l			;1a2b
	ld h,b			;1a2c
	ld h,c			;1a2d
	nop			;1a2e
	nop			;1a2f
	nop			;1a30
	nop			;1a31
	nop			;1a32
	nop			;1a33
	nop			;1a34
	nop			;1a35
	nop			;1a36
	nop			;1a37
	nop			;1a38
	nop			;1a39
	nop			;1a3a
	nop			;1a3b
	nop			;1a3c
	nop			;1a3d
	ld a,b			;1a3e
	ld a,c			;1a3f
	ld b,e			;1a40
	add hl,hl			;1a41
	rst 38h			;1a42
	rst 38h			;1a43
	rst 38h			;1a44
	rst 38h			;1a45
	ld h,h			;1a46
	ld h,l			;1a47
	nop			;1a48
	nop			;1a49
	nop			;1a4a
	nop			;1a4b
	ld h,h			;1a4c
	ld h,l			;1a4d
	nop			;1a4e
	nop			;1a4f
	nop			;1a50
	nop			;1a51
	nop			;1a52
	nop			;1a53
	nop			;1a54
	nop			;1a55
	nop			;1a56
	nop			;1a57
	nop			;1a58
	nop			;1a59
	nop			;1a5a
	nop			;1a5b
	nop			;1a5c
	nop			;1a5d
	ld a,h			;1a5e
	ld a,l			;1a5f
	ld b,e			;1a60
	ld hl,(0ffffh)		;1a61
	rst 38h			;1a64
	rst 38h			;1a65
	ld h,h			;1a66
	ld h,l			;1a67
	ld h,h			;1a68
	ld h,l			;1a69
	ld h,h			;1a6a
	ld h,l			;1a6b
	ld h,b			;1a6c
	ld h,c			;1a6d
	nop			;1a6e
	nop			;1a6f
	nop			;1a70
	nop			;1a71
	nop			;1a72
	nop			;1a73
	nop			;1a74
	nop			;1a75
	nop			;1a76
	nop			;1a77
	nop			;1a78
	nop			;1a79
	nop			;1a7a
	nop			;1a7b
	nop			;1a7c
	nop			;1a7d
	nop			;1a7e
	nop			;1a7f
	ld b,e			;1a80
	dec hl			;1a81
	rst 38h			;1a82
	rst 38h			;1a83
	rst 38h			;1a84
	rst 38h			;1a85
	ld h,h			;1a86
	ld h,l			;1a87
	nop			;1a88
	nop			;1a89
	nop			;1a8a
	nop			;1a8b
	nop			;1a8c
	nop			;1a8d
	nop			;1a8e
	nop			;1a8f
	nop			;1a90
	nop			;1a91
	nop			;1a92
	nop			;1a93
	nop			;1a94
	nop			;1a95
	nop			;1a96
	nop			;1a97
	nop			;1a98
	nop			;1a99
	nop			;1a9a
	nop			;1a9b
	nop			;1a9c
	nop			;1a9d
	nop			;1a9e
	nop			;1a9f
	ld b,e			;1aa0
	inc l			;1aa1
	rst 38h			;1aa2
	rst 38h			;1aa3
	rst 38h			;1aa4
	rst 38h			;1aa5
	ld h,h			;1aa6
	ld h,l			;1aa7
	nop			;1aa8
	ld l,b			;1aa9
	nop			;1aaa
	ld l,b			;1aab
	nop			;1aac
	ld l,b			;1aad
	ld l,b			;1aae
	ld l,b			;1aaf
	nop			;1ab0
	ld l,b			;1ab1
	ld h,h			;1ab2
	ld h,l			;1ab3
	nop			;1ab4
	ld h,d			;1ab5
	ld h,e			;1ab6
	nop			;1ab7
	ld l,b			;1ab8
	nop			;1ab9
	ld l,b			;1aba
	nop			;1abb
	ld l,b			;1abc
	nop			;1abd
	nop			;1abe
	ld l,b			;1abf
	ld b,e			;1ac0
	dec l			;1ac1
	rst 38h			;1ac2
	rst 38h			;1ac3
	rst 38h			;1ac4
	rst 38h			;1ac5
	ld h,h			;1ac6
	ld h,l			;1ac7
	nop			;1ac8
	ld l,b			;1ac9
	nop			;1aca
	ld l,b			;1acb
	nop			;1acc
	ld l,b			;1acd
	nop			;1ace
	ld l,b			;1acf
	nop			;1ad0
	ld l,b			;1ad1
	nop			;1ad2
	nop			;1ad3
	nop			;1ad4
	ld l,b			;1ad5
	sbc a,l			;1ad6
	nop			;1ad7
	ld l,b			;1ad8
	nop			;1ad9
	ld l,b			;1ada
	nop			;1adb
	halt			;1adc
	ld (hl),a			;1add
	ld (hl),b			;1ade
	ld (hl),c			;1adf
	ld b,e			;1ae0
	ld l,0ffh		;1ae1
	rst 38h			;1ae3
	rst 38h			;1ae4
	rst 38h			;1ae5
	ld h,h			;1ae6
	ld h,l			;1ae7
	nop			;1ae8
	ld l,b			;1ae9
	ld l,b			;1aea
	ld l,b			;1aeb
	nop			;1aec
	ld l,b			;1aed
	nop			;1aee
	ld l,b			;1aef
	nop			;1af0
	ld l,b			;1af1
	ld h,d			;1af2
	ld h,e			;1af3
	nop			;1af4
	ld l,b			;1af5
	halt			;1af6
	ld (hl),a			;1af7
	ld l,b			;1af8
	nop			;1af9
	ld l,b			;1afa
	nop			;1afb
	nop			;1afc
	ld h,h			;1afd
	ld h,l			;1afe
l1affh:
	nop			;1aff
	ld b,e			;1b00
	cpl			;1b01
	nop			;1b02
	nop			;1b03
	nop			;1b04
	nop			;1b05
	ld h,h			;1b06
	ld h,l			;1b07
	nop			;1b08
	ld l,b			;1b09
	nop			;1b0a
	ld l,b			;1b0b
	nop			;1b0c
	ld l,b			;1b0d
	nop			;1b0e
	ld l,b			;1b0f
	nop			;1b10
	ld l,b			;1b11
	nop			;1b12
	nop			;1b13
	nop			;1b14
	ld l,b			;1b15
	nop			;1b16
	sbc a,l			;1b17
	ld l,b			;1b18
	nop			;1b19
	ld l,b			;1b1a
	nop			;1b1b
	ld (hl),h			;1b1c
	ld (hl),l			;1b1d
	ld (hl),d			;1b1e
	ld (hl),e			;1b1f
	ld b,e			;1b20
	jr nc,$+1		;1b21
	rst 38h			;1b23
	rst 38h			;1b24
	rst 38h			;1b25
	ld h,h			;1b26
	ld h,l			;1b27
	nop			;1b28
	ld l,b			;1b29
	nop			;1b2a
	ld l,b			;1b2b
	nop			;1b2c
	ld l,b			;1b2d
	ld l,b			;1b2e
	ld l,b			;1b2f
	nop			;1b30
	ld l,b			;1b31
	ld h,h			;1b32
	ld h,l			;1b33
	nop			;1b34
	ld l,b			;1b35
	nop			;1b36
	ld h,(hl)			;1b37
	ld h,a			;1b38
	nop			;1b39
	ld l,b			;1b3a
	nop			;1b3b
	ld l,b			;1b3c
	nop			;1b3d
	nop			;1b3e
	ld l,b			;1b3f
l1b40h:
	ld l,h			;1b40
	ld l,l			;1b41
	ld l,(hl)			;1b42
	ld l,a			;1b43
	rst 38h			;1b44
	rst 38h			;1b45
	rst 38h			;1b46
	rst 38h			;1b47
	ld l,h			;1b48
	ld l,l			;1b49
	ld l,(hl)			;1b4a
	ld l,a			;1b4b
	ld h,h			;1b4c
	ld h,l			;1b4d
	ld h,(hl)			;1b4e
	ld h,a			;1b4f
l1b50h:
	ld h,e			;1b50
	rst 38h			;1b51
	ld h,e			;1b52
	ld h,c			;1b53
	ld h,a			;1b54
	rst 38h			;1b55
	ld h,a			;1b56
	ld h,l			;1b57
	ld l,e			;1b58
	rst 38h			;1b59
	ld l,e			;1b5a
	ld l,c			;1b5b
	ld l,a			;1b5c
	rst 38h			;1b5d
	ld l,a			;1b5e
	ld l,l			;1b5f
	add a,b			;1b60
	add a,e			;1b61
	add a,e			;1b62
	add a,l			;1b63
	add a,c			;1b64
	adc a,h			;1b65
	adc a,h			;1b66
	add a,(hl)			;1b67
	add a,c			;1b68
	adc a,h			;1b69
	adc a,h			;1b6a
	add a,(hl)			;1b6b
	add a,d			;1b6c
	add a,h			;1b6d
	add a,h			;1b6e
	add a,a			;1b6f
	nop			;1b70
	adc a,c			;1b71
	adc a,c			;1b72
	nop			;1b73
	adc a,b			;1b74
	adc a,l			;1b75
	adc a,l			;1b76
	adc a,e			;1b77
	adc a,b			;1b78
	adc a,l			;1b79
	adc a,l			;1b7a
	adc a,e			;1b7b
	nop			;1b7c
	adc a,d			;1b7d
	adc a,d			;1b7e
	nop			;1b7f
	nop			;1b80
	nop			;1b81
	nop			;1b82
	nop			;1b83
	nop			;1b84
	add a,b			;1b85
	add a,l			;1b86
	nop			;1b87
	nop			;1b88
	add a,d			;1b89
	add a,a			;1b8a
	nop			;1b8b
	nop			;1b8c
	nop			;1b8d
	nop			;1b8e
	nop			;1b8f
	dec de			;1b90
	add a,b			;1b91
	dec de			;1b92
	ld (hl),b			;1b93
	dec de			;1b94
	ld h,b			;1b95
	dec de			;1b96
	ld (hl),b			;1b97
	rla			;1b98
	ret p			;1b99
	rla			;1b9a
	ret p			;1b9b
	rla			;1b9c
	ret p			;1b9d
	rla			;1b9e
	ret p			;1b9f
l1ba0h:
	ld b,e			;1ba0
	inc l			;1ba1
	nop			;1ba2
	nop			;1ba3
	nop			;1ba4
	nop			;1ba5
	nop			;1ba6
	nop			;1ba7
	nop			;1ba8
	ld hl,l0f00h		;1ba9
	ld (de),a			;1bac
	nop			;1bad
	ld (l0c10h),hl		;1bae
	ld bc,00519h		;1bb1
	ld (de),a			;1bb4
	inc de			;1bb5
	nop			;1bb6
	ld (bc),a			;1bb7
	dec d			;1bb8
	inc d			;1bb9
	inc d			;1bba
	rrca			;1bbb
	ld c,000h		;1bbc
	nop			;1bbe
	nop			;1bbf
	ld b,c			;1bc0
	ld d,h			;1bc1
	halt			;1bc2
	ld a,(hl)			;1bc3
	ld b,d			;1bc4
	ld d,l			;1bc5
	ld (hl),a			;1bc6
	ld a,a			;1bc7
	ld b,c			;1bc8
	ld d,(hl)			;1bc9
	ld (hl),h			;1bca
	ld a,h			;1bcb
	ld b,d			;1bcc
	ld d,a			;1bcd
	ld (hl),l			;1bce
	ld a,l			;1bcf
	ld b,h			;1bd0
	ld d,c			;1bd1
	ld (hl),d			;1bd2
	ld a,d			;1bd3
	ld b,l			;1bd4
	ld d,d			;1bd5
	ld (hl),e			;1bd6
	ld a,e			;1bd7
	ld b,(hl)			;1bd8
	ld d,c			;1bd9
	ld (hl),b			;1bda
	ld a,b			;1bdb
	ld b,a			;1bdc
	ld d,d			;1bdd
	ld (hl),c			;1bde
	ld a,c			;1bdf
	ld b,c			;1be0
	ld d,c			;1be1
	ld (hl),b			;1be2
	ld a,b			;1be3
	ld b,d			;1be4
	ld d,d			;1be5
	ld (hl),c			;1be6
	ld a,c			;1be7
	ld b,c			;1be8
	ld d,c			;1be9
	ld (hl),d			;1bea
	ld a,d			;1beb
	ld b,d			;1bec
	ld d,d			;1bed
	ld (hl),e			;1bee
	ld a,e			;1bef
	ld b,c			;1bf0
	ld d,c			;1bf1
	ld (hl),h			;1bf2
	ld a,h			;1bf3
	ld b,d			;1bf4
	ld d,d			;1bf5
	ld (hl),l			;1bf6
	ld a,l			;1bf7
	ld b,c			;1bf8
	ld d,c			;1bf9
	halt			;1bfa
	ld a,(hl)			;1bfb
	ld b,d			;1bfc
	ld d,d			;1bfd
	ld (hl),a			;1bfe
	ld a,a			;1bff
l1c00h:
	nop			;1c00
	ld bc,l0600h		;1c01
	nop			;1c04
	ld (bc),a			;1c05
	inc bc			;1c06
	inc b			;1c07
	nop			;1c08
	ld bc,l0800h		;1c09
	nop			;1c0c
	ld (bc),a			;1c0d
	inc bc			;1c0e
	inc b			;1c0f
	nop			;1c10
	nop			;1c11
	rlca			;1c12
	nop			;1c13
	ld bc,l0002h		;1c14
	add hl,bc			;1c17
	nop			;1c18
	inc bc			;1c19
	inc b			;1c1a
	nop			;1c1b
	nop			;1c1c
	inc bc			;1c1d
	inc b			;1c1e
	nop			;1c1f
	nop			;1c20
	ld bc,sub_0200h		;1c21
	nop			;1c24
	inc bc			;1c25
	ld a,(bc)			;1c26
	nop			;1c27
	inc b			;1c28
	nop			;1c29
	nop			;1c2a
	ld bc,l0002h		;1c2b
	ld b,000h		;1c2e
	inc bc			;1c30
	inc b			;1c31
	nop			;1c32
	nop			;1c33
	ld bc,sub_0200h		;1c34
	nop			;1c37
	inc bc			;1c38
	nop			;1c39
	inc b			;1c3a
	nop			;1c3b
	inc bc			;1c3c
	dec b			;1c3d
	nop			;1c3e
	nop			;1c3f
	nop			;1c40
	nop			;1c41
	rlca			;1c42
	nop			;1c43
	ld bc,sub_0200h		;1c44
	nop			;1c47
	nop			;1c48
	dec b			;1c49
	nop			;1c4a
	nop			;1c4b
	inc bc			;1c4c
	nop			;1c4d
	inc b			;1c4e
	ld bc,l0002h		;1c4f
	inc bc			;1c52
	nop			;1c53
	ex af,af'			;1c54
	inc b			;1c55
	nop			;1c56
	ld bc,l0602h		;1c57
	nop			;1c5a
	inc bc			;1c5b
	nop			;1c5c
	inc b			;1c5d
	nop			;1c5e
	ld (bc),a			;1c5f
	ld bc,l0300h+2		;1c60
	nop			;1c63
	dec b			;1c64
	nop			;1c65
	nop			;1c66
	inc b			;1c67
	nop			;1c68
	ld bc,l0002h		;1c69
	nop			;1c6c
	inc bc			;1c6d
	inc b			;1c6e
	dec bc			;1c6f
	nop			;1c70
	ld bc,sub_0200h		;1c71
	nop			;1c74
	inc bc			;1c75
	nop			;1c76
	nop			;1c77
	inc b			;1c78
	nop			;1c79
	nop			;1c7a
	add hl,bc			;1c7b
	nop			;1c7c
	nop			;1c7d
	ld (bc),a			;1c7e
	nop			;1c7f
	rlca			;1c80
	nop			;1c81
	nop			;1c82
	ld bc,l0000h		;1c83
	ld (bc),a			;1c86
	nop			;1c87
	nop			;1c88
	inc bc			;1c89
	nop			;1c8a
	ex af,af'			;1c8b
	inc b			;1c8c
	nop			;1c8d
	ld bc,l0000h		;1c8e
	ld b,000h		;1c91
	ld bc,sub_0200h		;1c93
	nop			;1c96
	ld bc,l0403h		;1c97
	ld bc,l0101h+2		;1c9a
	ld (bc),a			;1c9d
	inc bc			;1c9e
	inc b			;1c9f
	nop			;1ca0
	dec b			;1ca1
	nop			;1ca2
	ld bc,l0002h		;1ca3
	add hl,bc			;1ca6
	nop			;1ca7
	inc bc			;1ca8
	inc b			;1ca9
	nop			;1caa
	ld bc,00100h		;1cab
	ld (bc),a			;1cae
	inc bc			;1caf
	inc b			;1cb0
	nop			;1cb1
	ld (bc),a			;1cb2
	nop			;1cb3
	nop			;1cb4
	ld bc,l0002h		;1cb5
	inc bc			;1cb8
	inc b			;1cb9
	nop			;1cba
	ld b,000h		;1cbb
	nop			;1cbd
	ld bc,l0000h		;1cbe
	ld bc,l0002h		;1cc1
	dec b			;1cc4
	nop			;1cc5
	nop			;1cc6
	inc bc			;1cc7
	nop			;1cc8
	inc b			;1cc9
	nop			;1cca
	rlca			;1ccb
	nop			;1ccc
	ld bc,sub_0200h		;1ccd
	nop			;1cd0
	nop			;1cd1
	inc bc			;1cd2
	nop			;1cd3
	inc b			;1cd4
	nop			;1cd5
	inc b			;1cd6
	nop			;1cd7
	ld a,(bc)			;1cd8
	nop			;1cd9
	ld bc,sub_0200h		;1cda
	nop			;1cdd
	inc bc			;1cde
	nop			;1cdf
	ld bc,sub_0700h		;1ce0
	nop			;1ce3
	ld (bc),a			;1ce4
	nop			;1ce5
	inc bc			;1ce6
	inc b			;1ce7
	nop			;1ce8
	dec b			;1ce9
	nop			;1cea
	ld bc,sub_0200h		;1ceb
	nop			;1cee
	nop			;1cef
	ex af,af'			;1cf0
	inc bc			;1cf1
	inc b			;1cf2
	nop			;1cf3
	ld bc,sub_0200h		;1cf4
	nop			;1cf7
	inc bc			;1cf8
	nop			;1cf9
	inc b			;1cfa
	nop			;1cfb
	nop			;1cfc
	ld b,000h		;1cfd
	inc bc			;1cff
	inc c			;1d00
	dec c			;1d01
	inc c			;1d02
	rrca			;1d03
	rlca			;1d04
	rlca			;1d05
	ld bc,l0000h		;1d06
	ld c,h			;1d09
	ld c,l			;1d0a
	ld c,(hl)			;1d0b
	ld c,a			;1d0c
	ld c,a			;1d0d
	ld c,(hl)			;1d0e
	ld c,l			;1d0f
	ld c,h			;1d10
	nop			;1d11
	nop			;1d12
	rra			;1d13
	ld c,006h		;1d14
	dec c			;1d16
	ld bc,l050eh		;1d17
	ex af,af'			;1d1a
	inc c			;1d1b
	ld c,00ch		;1d1c
	ld a,(bc)			;1d1e
	nop			;1d1f
	nop			;1d20
	ld c,l			;1d21
	ld c,a			;1d22
	ld e,(hl)			;1d23
	ld e,(hl)			;1d24
	ld e,(hl)			;1d25
	ld e,(hl)			;1d26
	ld e,(hl)			;1d27
	ld e,(hl)			;1d28
	ld e,(hl)			;1d29
	ld e,(hl)			;1d2a
	ld c,a			;1d2b
	ld c,l			;1d2c
	nop			;1d2d
	nop			;1d2e
	ld b,00bh		;1d2f
	dec c			;1d31
	ex af,af'			;1d32
	ld c,003h		;1d33
	ld (bc),a			;1d35
	nop			;1d36
	ld bc,04c00h		;1d37
	ld c,a			;1d3a
	ld e,(hl)			;1d3b
	ld e,(hl)			;1d3c
	ld e,(hl)			;1d3d
	ld e,(hl)			;1d3e
	ld e,(hl)			;1d3f
	ld e,(hl)			;1d40
	ld e,(hl)			;1d41
	ld e,(hl)			;1d42
	ld e,(hl)			;1d43
	ld e,(hl)			;1d44
	ld e,(hl)			;1d45
	ld e,(hl)			;1d46
	ld c,a			;1d47
	ld c,h			;1d48
	nop			;1d49
	add hl,bc			;1d4a
	rlca			;1d4b
	ld a,(bc)			;1d4c
	inc bc			;1d4d
	inc b			;1d4e
	nop			;1d4f
	ld a,(bc)			;1d50
	nop			;1d51
	ld c,l			;1d52
	ld e,(hl)			;1d53
	ld e,(hl)			;1d54
	ld e,(hl)			;1d55
	ld e,(hl)			;1d56
	ld e,(hl)			;1d57
	ld e,(hl)			;1d58
	ld e,(hl)			;1d59
	ld e,(hl)			;1d5a
	ld e,(hl)			;1d5b
	ld e,(hl)			;1d5c
	ld e,(hl)			;1d5d
	ld e,(hl)			;1d5e
	ld e,(hl)			;1d5f
	ld e,(hl)			;1d60
	ld e,(hl)			;1d61
	ld e,(hl)			;1d62
	ld c,l			;1d63
	nop			;1d64
	nop			;1d65
	ld c,00fh		;1d66
	ex af,af'			;1d68
	ex af,af'			;1d69
	nop			;1d6a
	ld e,h			;1d6b
	ld h,b			;1d6c
	ld l,d			;1d6d
	ld h,b			;1d6e
	ld l,d			;1d6f
	ld h,b			;1d70
	ld l,d			;1d71
	ld h,b			;1d72
	ld l,d			;1d73
	ld h,b			;1d74
	ld l,d			;1d75
	ld h,b			;1d76
	ld l,d			;1d77
	ld h,b			;1d78
	ld l,d			;1d79
	ld h,b			;1d7a
	ld l,d			;1d7b
	ld h,b			;1d7c
	ld l,d			;1d7d
	ld e,l			;1d7e
	nop			;1d7f
	ld bc,l0202h		;1d80
	ld b,001h		;1d83
	nop			;1d85
	nop			;1d86
	nop			;1d87
	ld e,b			;1d88
	ld e,c			;1d89
	ld e,d			;1d8a
	ld e,e			;1d8b
	ld e,e			;1d8c
	ld e,e			;1d8d
	ld a,(hl)			;1d8e
	ld a,a			;1d8f
	ld e,e			;1d90
	ld e,e			;1d91
	ld e,e			;1d92
	ld c,d			;1d93
	ld c,c			;1d94
	ld c,b			;1d95
	nop			;1d96
	nop			;1d97
	nop			;1d98
	inc bc			;1d99
	ld c,00bh		;1d9a
	dec c			;1d9c
	dec b			;1d9d
	inc b			;1d9e
	dec b			;1d9f
	ld a,(bc)			;1da0
	ex af,af'			;1da1
	nop			;1da2
	nop			;1da3
	ld e,b			;1da4
	ld e,c			;1da5
	ld e,d			;1da6
	ld c,e			;1da7
	halt			;1da8
	ld (hl),a			;1da9
	ld c,e			;1daa
	ld c,d			;1dab
	ld c,c			;1dac
	ld c,b			;1dad
	nop			;1dae
	nop			;1daf
	ld bc,l0f03h		;1db0
	ld (bc),a			;1db3
	inc bc			;1db4
	nop			;1db5
	nop			;1db6
	inc bc			;1db7
	inc bc			;1db8
	rlca			;1db9
	ld (bc),a			;1dba
	ld a,(bc)			;1dbb
	inc bc			;1dbc
	rlca			;1dbd
	nop			;1dbe
	nop			;1dbf
	ld e,b			;1dc0
	ld d,b			;1dc1
	ld d,c			;1dc2
	ld d,d			;1dc3
	ld d,e			;1dc4
	ld c,b			;1dc5
	nop			;1dc6
	nop			;1dc7
	dec bc			;1dc8
	ld bc,l0300h+2		;1dc9
	rrca			;1dcc
	ld c,00ch		;1dcd
	ld (bc),a			;1dcf
	dec b			;1dd0
	inc c			;1dd1
	ld b,000h		;1dd2
	inc b			;1dd4
	ld b,007h		;1dd5
	ld c,00fh		;1dd7
	add hl,bc			;1dd9
	nop			;1dda
l1ddbh:
	ld b,b			;1ddb
	ld b,c			;1ddc
	ld b,d			;1ddd
	ld b,e			;1dde
	nop			;1ddf
	rlca			;1de0
	inc bc			;1de1
	ld a,(bc)			;1de2
	ex af,af'			;1de3
	dec c			;1de4
	nop			;1de5
	add hl,bc			;1de6
	dec bc			;1de7
	inc c			;1de8
	ld a,(bc)			;1de9
	rst 38h			;1dea
	rst 38h			;1deb
	rst 38h			;1dec
	rst 38h			;1ded
	rst 38h			;1dee
	rst 38h			;1def
l1df0h:
	ld a,(0431dh)		;1df0
	sub 001h		;1df3
	ret z			;1df5
	ld (0438fh),a		;1df6
	nop			;1df9
	nop			;1dfa
	nop			;1dfb
	nop			;1dfc
	nop			;1dfd
	nop			;1dfe
	nop			;1dff
	jr nz,l1e32h		;1e00
	ld hl,l2230h+1		;1e02
	ld (l3323h),a		;1e05
	inc h			;1e08
	inc (hl)			;1e09
	dec h			;1e0a
	dec (hl)			;1e0b
	ld h,036h		;1e0c
	daa			;1e0e
	scf			;1e0f
	jr z,$+58		;1e10
	add hl,hl			;1e12
	add hl,sp			;1e13
	ld hl,(02b3ah)		;1e14
	dec sp			;1e17
	inc l			;1e18
	inc a			;1e19
	dec l			;1e1a
	dec a			;1e1b
	ld l,03eh		;1e1c
	cpl			;1e1e
	ccf			;1e1f
l1e20h:
	ld c,c			;1e20
	ld c,b			;1e21
	ld c,d			;1e22
	ld c,e			;1e23
	ld c,d			;1e24
	ld c,c			;1e25
	ld c,d			;1e26
	ld c,c			;1e27
	ld c,b			;1e28
	ld c,d			;1e29
	ld c,b			;1e2a
	ld c,c			;1e2b
	ld c,e			;1e2c
	ld c,b			;1e2d
	ld c,d			;1e2e
	ld c,b			;1e2f
	ld c,d			;1e30
	ld c,c			;1e31
l1e32h:
	ld c,e			;1e32
	ld c,c			;1e33
l1e34h:
	ld c,e			;1e34
	ld c,d			;1e35
	ld c,c			;1e36
	ld c,b			;1e37
	ld c,c			;1e38
	ld c,c			;1e39
	ld c,d			;1e3a
	ld c,d			;1e3b
	ld c,b			;1e3c
	ld c,c			;1e3d
	ld c,d			;1e3e
	ld c,b			;1e3f
	and b			;1e40
	ld h,b			;1e41
	ld b,b			;1e42
	nop			;1e43
	ret po			;1e44
	ret nz			;1e45
	ret nz			;1e46
	ld h,b			;1e47
	add a,b			;1e48
	jr nz,l1eabh		;1e49
	ld b,b			;1e4b
	jr nz,l1e8eh		;1e4c
	nop			;1e4e
	add a,b			;1e4f
	ld b,b			;1e50
	nop			;1e51
	jr nz,l1e34h		;1e52
	nop			;1e54
	ld h,b			;1e55
	nop			;1e56
	and b			;1e57
	ret po			;1e58
	jr nz,l1ddbh		;1e59
	nop			;1e5b
	ret nz			;1e5c
	add a,b			;1e5d
	and b			;1e5e
	ret po			;1e5f
l1e60h:
	nop			;1e60
	inc b			;1e61
	ex af,af'			;1e62
	inc c			;1e63
	djnz $+22		;1e64
	jr l1e84h		;1e66
	nop			;1e68
	ex af,af'			;1e69
	djnz l1e84h		;1e6a
	inc b			;1e6c
	inc c			;1e6d
	inc d			;1e6e
	inc e			;1e6f
	nop			;1e70
l1e71h:
	inc c			;1e71
	jr l1e78h		;1e72
	inc b			;1e74
	inc e			;1e75
	ex af,af'			;1e76
	inc d			;1e77
l1e78h:
	nop			;1e78
	djnz l1e7fh		;1e79
	inc d			;1e7b
	ex af,af'			;1e7c
	jr l1e8bh		;1e7d
l1e7fh:
	inc e			;1e7f
l1e80h:
	djnz l1e93h		;1e80
	ld (de),a			;1e82
	inc de			;1e83
l1e84h:
	inc d			;1e84
	dec d			;1e85
	ld d,017h		;1e86
	jr l1ea3h		;1e88
	ld a,(de)			;1e8a
l1e8bh:
	dec de			;1e8b
	inc e			;1e8c
	dec e			;1e8d
l1e8eh:
	ld e,01fh		;1e8e
	djnz l1ea4h		;1e90
	inc d			;1e92
l1e93h:
	ld d,018h		;1e93
	ld a,(de)			;1e95
	inc e			;1e96
	ld e,011h		;1e97
	inc de			;1e99
	dec d			;1e9a
	rla			;1e9b
	add hl,de			;1e9c
	dec de			;1e9d
	dec e			;1e9e
	rra			;1e9f
	ld c,d			;1ea0
	ld c,e			;1ea1
	ld c,c			;1ea2
l1ea3h:
	ld c,d			;1ea3
l1ea4h:
	ld c,b			;1ea4
	ld c,d			;1ea5
	ld c,b			;1ea6
	ld c,c			;1ea7
	ld c,c			;1ea8
	ld c,d			;1ea9
	ld c,c			;1eaa
l1eabh:
	ld c,e			;1eab
	ld c,b			;1eac
	ld c,e			;1ead
	ld c,d			;1eae
	ld c,d			;1eaf
	ld c,b			;1eb0
	ld c,c			;1eb1
	ld c,b			;1eb2
	ld c,d			;1eb3
	ld c,b			;1eb4
	ld c,b			;1eb5
	ld c,c			;1eb6
	ld c,d			;1eb7
	ld c,c			;1eb8
	ld c,c			;1eb9
	ld c,d			;1eba
	ld c,b			;1ebb
	ld c,d			;1ebc
	ld c,c			;1ebd
	ld c,e			;1ebe
	ld c,b			;1ebf
	nop			;1ec0
	jr nz,l1f23h		;1ec1
	ld b,b			;1ec3
	ret po			;1ec4
	add a,b			;1ec5
	jr nz,l1f28h		;1ec6
	ld b,b			;1ec8
	and b			;1ec9
	nop			;1eca
	nop			;1ecb
	ld b,b			;1ecc
	jr nz,$-62		;1ecd
	jr nz,l1e71h		;1ecf
	add a,b			;1ed1
	ret po			;1ed2
	ld b,b			;1ed3
	ld h,b			;1ed4
	ret nz			;1ed5
	jr nz,l1e78h		;1ed6
	ret po			;1ed8
	ld b,b			;1ed9
	ld h,b			;1eda
	ret nz			;1edb
	jr nz,l1f1eh		;1edc
	jr nz,l1e60h		;1ede
l1ee0h:
	ld de,0433dh		;1ee0
	ld bc,l001ah		;1ee3
l1ee6h:
	ld a,(de)			;1ee6
	add a,b			;1ee7
	ld b,a			;1ee8
	call sub_0217h		;1ee9
	dec c			;1eec
	jp nz,l1ee6h		;1eed
	ld a,(de)			;1ef0
	add a,b			;1ef1
	add a,027h		;1ef2
	ld hl,04389h		;1ef4
	add a,(hl)			;1ef7
	ld (hl),a			;1ef8
	nop			;1ef9
	ret			;1efa
	rst 38h			;1efb
	rst 38h			;1efc
	rst 38h			;1efd
	rst 38h			;1efe
	rst 38h			;1eff
	nop			;1f00
	nop			;1f01
	nop			;1f02
	ld bc,l0000h		;1f03
	nop			;1f06
	ld (bc),a			;1f07
	nop			;1f08
	nop			;1f09
	nop			;1f0a
	nop			;1f0b
	inc bc			;1f0c
	nop			;1f0d
	nop			;1f0e
	nop			;1f0f
	nop			;1f10
	inc b			;1f11
	nop			;1f12
	nop			;1f13
	nop			;1f14
	nop			;1f15
	ld bc,l0000h		;1f16
	nop			;1f19
	dec b			;1f1a
	nop			;1f1b
	ld (bc),a			;1f1c
	nop			;1f1d
l1f1eh:
	inc bc			;1f1e
	nop			;1f1f
	nop			;1f20
	nop			;1f21
	inc b			;1f22
l1f23h:
	nop			;1f23
	rlca			;1f24
	nop			;1f25
	nop			;1f26
	nop			;1f27
l1f28h:
	ld b,000h		;1f28
	ld bc,sub_0200h		;1f2a
	inc c			;1f2d
	nop			;1f2e
	inc bc			;1f2f
	inc b			;1f30
	nop			;1f31
	nop			;1f32
	ld bc,l0800h		;1f33
	nop			;1f36
	nop			;1f37
	ld (bc),a			;1f38
	nop			;1f39
	inc c			;1f3a
	inc bc			;1f3b
	inc b			;1f3c
	ld c,000h		;1f3d
	nop			;1f3f
	nop			;1f40
	ld bc,l0002h		;1f41
	dec c			;1f44
	inc bc			;1f45
	inc b			;1f46
	rrca			;1f47
	ld bc,l070ch		;1f48
	ld a,(bc)			;1f4b
	ld (bc),a			;1f4c
	dec c			;1f4d
	inc bc			;1f4e
	ex af,af'			;1f4f
	ld b,00ch		;1f50
	inc b			;1f52
	add hl,bc			;1f53
	dec b			;1f54
	rrca			;1f55
	ld bc,l0d02h		;1f56
	inc bc			;1f59
	inc c			;1f5a
	inc b			;1f5b
	dec c			;1f5c
	dec b			;1f5d
	rrca			;1f5e
	inc c			;1f5f
	ld bc,l0e02h		;1f60
	inc c			;1f63
	inc bc			;1f64
	rrca			;1f65
	dec c			;1f66
	dec b			;1f67
	ld c,00dh		;1f68
	inc c			;1f6a
	rrca			;1f6b
	dec c			;1f6c
	inc b			;1f6d
	inc c			;1f6e
	ld bc,l050eh		;1f6f
	rrca			;1f72
	dec c			;1f73
	rlca			;1f74
	inc c			;1f75
	ld b,00eh		;1f76
	dec c			;1f78
	rrca			;1f79
	add hl,bc			;1f7a
	inc c			;1f7b
	rrca			;1f7c
	dec c			;1f7d
	ld c,00dh		;1f7e
	ld (bc),a			;1f80
	dec c			;1f81
	inc c			;1f82
	rrca			;1f83
	dec b			;1f84
	ld c,00dh		;1f85
	inc c			;1f87
	rrca			;1f88
	ld b,00eh		;1f89
	rrca			;1f8b
	inc c			;1f8c
	dec c			;1f8d
	rrca			;1f8e
	inc c			;1f8f
	ld b,00dh		;1f90
	inc b			;1f92
	dec bc			;1f93
	inc c			;1f94
	rrca			;1f95
	dec b			;1f96
	dec c			;1f97
	dec b			;1f98
	inc bc			;1f99
	ld c,007h		;1f9a
	inc c			;1f9c
	dec c			;1f9d
	inc b			;1f9e
	dec b			;1f9f
	ld bc,l0e02h		;1fa0
	inc bc			;1fa3
	inc c			;1fa4
	inc b			;1fa5
	rrca			;1fa6
	dec b			;1fa7
	ex af,af'			;1fa8
	inc c			;1fa9
	rlca			;1faa
	ld bc,l040dh		;1fab
	ld c,002h		;1fae
	inc c			;1fb0
	ld bc,0030fh		;1fb1
	dec b			;1fb4
	dec c			;1fb5
	nop			;1fb6
	ld c,000h		;1fb7
	add hl,bc			;1fb9
	inc c			;1fba
	ld b,00dh		;1fbb
	nop			;1fbd
	ld bc,l0101h+1		;1fbe
	ld (bc),a			;1fc1
	inc bc			;1fc2
	nop			;1fc3
	nop			;1fc4
	dec c			;1fc5
	nop			;1fc6
	ld a,(bc)			;1fc7
	nop			;1fc8
	nop			;1fc9
	nop			;1fca
	ld c,000h		;1fcb
	dec b			;1fcd
	nop			;1fce
	ex af,af'			;1fcf
	nop			;1fd0
	inc c			;1fd1
	nop			;1fd2
	nop			;1fd3
	inc bc			;1fd4
	nop			;1fd5
	nop			;1fd6
	rlca			;1fd7
	nop			;1fd8
	nop			;1fd9
	nop			;1fda
	inc b			;1fdb
	nop			;1fdc
	nop			;1fdd
	ld b,000h		;1fde
	nop			;1fe0
	nop			;1fe1
	nop			;1fe2
	ld bc,l0000h		;1fe3
	nop			;1fe6
	nop			;1fe7
	ld (bc),a			;1fe8
	nop			;1fe9
	nop			;1fea
	nop			;1feb
	nop			;1fec
	inc bc			;1fed
	nop			;1fee
	nop			;1fef
	nop			;1ff0
	inc b			;1ff1
	nop			;1ff2
	dec b			;1ff3
	nop			;1ff4
	nop			;1ff5
	nop			;1ff6
	nop			;1ff7
	nop			;1ff8
	ld bc,l0000h		;1ff9
	nop			;1ffc
	nop			;1ffd
	ld (bc),a			;1ffe
	nop			;1fff
	call sub_0876h		;2000
	call sub_0df0h		;2003
	call sub_24a0h		;2006
	ld hl,0435fh		;2009
	ld a,(hl)			;200c
	and 003h		;200d
	ld b,a			;200f
	inc (hl)			;2010
	ld a,(043bah)		;2011
	and a			;2014
	jp z,l21bah		;2015
	cp 005h		;2018
	jp nc,l2130h		;201a
	dec l			;201d
	ld a,b			;201e
	and a			;201f
l2020h:
	jp nz,l2025h		;2020
	ld (hl),0ffh		;2023
l2025h:
	ld a,(hl)			;2025
	and a			;2026
	jp z,l2130h		;2027
	jp l2146h		;202a
	rst 38h			;202d
	rst 38h			;202e
	rst 38h			;202f
l2030h:
	and 003h		;2030
	cp 001h		;2032
	ld de,l1b50h		;2034
	jp l23ach		;2037
	rst 38h			;203a
	rst 38h			;203b
	rst 38h			;203c
	rst 38h			;203d
	rst 38h			;203e
	rst 38h			;203f
sub_2040h:
	ld hl,043afh		;2040
	ld a,(043b9h)		;2043
	ld c,a			;2046
l2047h:
	cp (hl)			;2047
	ret nz			;2048
	ld a,(hl)			;2049
	inc l			;204a
	sub (hl)			;204b
	dec l			;204c
	ld (hl),a			;204d
	inc l			;204e
	inc l			;204f
	inc (hl)			;2050
	ld a,(hl)			;2051
	ld hl,l1e80h		;2052
	and 01fh		;2055
	add a,l			;2057
	ld l,a			;2058
	ld b,(hl)			;2059
	add a,020h		;205a
	ld l,a			;205c
	ld d,(hl)			;205d
	add a,020h		;205e
	ld l,a			;2060
	ld e,(hl)			;2061
	ld a,c			;2062
	rrca			;2063
	rrca			;2064
	rrca			;2065
	and 01fh		;2066
	add a,e			;2068
	inc a			;2069
	ld e,a			;206a
	ld a,b			;206b
	ld (de),a			;206c
	ret			;206d
	ret			;206e
	rst 38h			;206f
l2070h:
	ld a,e			;2070
	sub 00ah		;2071
	add a,0c0h		;2073
	ld c,a			;2075
	ld a,d			;2076
	adc a,000h		;2077
	ld b,a			;2079
	ld a,(hl)			;207a
	ld de,l2800h		;207b
	ld hl,l2900h		;207e
	jp l2085h		;2081
	rst 38h			;2084
l2085h:
	sub 020h		;2085
	rlca			;2087
	rlca			;2088
	nop			;2089
	and 0e0h		;208a
	ld l,a			;208c
	ld a,0e0h		;208d
	sub l			;208f
	ld l,a			;2090
l2091h:
	ld a,03fh		;2091
	sub c			;2093
	ld a,043h		;2094
	sbc a,b			;2096
	jp nc,l20b0h		;2097
	inc hl			;209a
	inc hl			;209b
	ld a,e			;209c
	add a,010h		;209d
	ld e,a			;209f
	ld a,c			;20a0
	sub 020h		;20a1
	ld c,a			;20a3
	ld a,b			;20a4
	sbc a,000h		;20a5
	ld b,a			;20a7
	jp l2091h		;20a8
	rst 38h			;20ab
	rst 38h			;20ac
	rst 38h			;20ad
	rst 38h			;20ae
	rst 38h			;20af
l20b0h:
	push bc			;20b0
l20b1h:
	ld a,(hl)			;20b1
	ex (sp),hl			;20b2
	ld b,008h		;20b3
l20b5h:
	ld (hl),000h		;20b5
	rrca			;20b7
	jp nc,l20bfh		;20b8
	ex de,hl			;20bb
	ld c,(hl)			;20bc
	ex de,hl			;20bd
	ld (hl),c			;20be
l20bfh:
	inc hl			;20bf
	inc de			;20c0
	dec b			;20c1
	jp nz,l20b5h		;20c2
	ex (sp),hl			;20c5
	inc hl			;20c6
	ld a,l			;20c7
	rrca			;20c8
	jp c,l20b1h		;20c9
	ld a,l			;20cc
	and 01fh		;20cd
	jp z,l20e1h		;20cf
	ex (sp),hl			;20d2
	ld a,l			;20d3
	sub 030h		;20d4
	ld l,a			;20d6
	ld a,h			;20d7
	sbc a,000h		;20d8
	ld h,a			;20da
	ex (sp),hl			;20db
	cp 03fh		;20dc
	jp nz,l20b1h		;20de
l20e1h:
	pop bc			;20e1
	ret			;20e2
	jr nz,$+1		;20e3
	rst 38h			;20e5
	rst 38h			;20e6
	rst 38h			;20e7
l20e8h:
	ld b,a			;20e8
	ld a,d			;20e9
	add a,008h		;20ea
	ld d,a			;20ec
	call sub_211ch		;20ed
	rrca			;20f0
	rrca			;20f1
	rrca			;20f2
	add a,e			;20f3
	and 01fh		;20f4
	ld c,a			;20f6
	ld a,e			;20f7
	and 0e0h		;20f8
	or c			;20fa
	ld e,a			;20fb
	ld a,b			;20fc
	rrca			;20fd
	rrca			;20fe
	and 00eh		;20ff
	add a,090h		;2101
	ld l,a			;2103
	ld h,01bh		;2104
	ld a,(hl)			;2106
	inc l			;2107
	ld l,(hl)			;2108
	ld h,a			;2109
	ld bc,l0403h+1		;210a
	jp l0ad6h		;210d
	rst 38h			;2110
	rst 38h			;2111
	rst 38h			;2112
	rst 38h			;2113
	rst 38h			;2114
	rst 38h			;2115
	rst 38h			;2116
	rst 38h			;2117
	rst 38h			;2118
	rst 38h			;2119
	rst 38h			;211a
	rst 38h			;211b
sub_211ch:
	ld hl,043b9h		;211c
	ld a,(hl)			;211f
	cp 010h		;2120
	ret c			;2122
	cp 030h		;2123
	ret nc			;2125
	ld a,010h		;2126
	ld (hl),a			;2128
	ld (05800h),a		;2129
	ret			;212c
	rst 38h			;212d
	rst 38h			;212e
	rst 38h			;212f
l2130h:
	ld a,b			;2130
	and a			;2131
	jp z,l2150h		;2132
	cp 001h		;2135
	jp z,l2160h		;2137
	cp 002h		;213a
	jp z,l2170h		;213c
	jp l2180h		;213f
	sub b			;2142
	and l			;2143
	ld d,b			;2144
	ld h,b			;2145
l2146h:
	ld a,b			;2146
	rrca			;2147
	jp nc,l2190h		;2148
	jp l21a5h		;214b
	ret p			;214e
	ld sp,hl			;214f
l2150h:
	call sub_0a50h		;2150
	call sub_3000h		;2153
	jp l0f00h		;2156
	rst 38h			;2159
	rst 38h			;215a
	rst 38h			;215b
	rst 38h			;215c
	rst 38h			;215d
	rst 38h			;215e
	rst 38h			;215f
l2160h:
	call sub_24c4h		;2160
	call sub_0c40h		;2163
	call sub_0d1ch		;2166
	jp l0fc0h		;2169
	rst 38h			;216c
	rst 38h			;216d
	rst 38h			;216e
	rst 38h			;216f
l2170h:
	call sub_0d70h		;2170
	jp l2560h		;2173
	rst 38h			;2176
	rst 38h			;2177
	rst 38h			;2178
	rst 38h			;2179
	rst 38h			;217a
	rst 38h			;217b
	rst 38h			;217c
	rst 38h			;217d
	rst 38h			;217e
	rst 38h			;217f
l2180h:
	call sub_24c4h		;2180
	call sub_0c40h		;2183
	call sub_0a6ch		;2186
	jp l0fc0h		;2189
	rst 38h			;218c
	rst 38h			;218d
	rst 38h			;218e
	rst 38h			;218f
l2190h:
	call sub_0a50h		;2190
	call sub_3000h		;2193
	call l0f00h		;2196
	call l2560h		;2199
	jp sub_0c40h		;219c
	rst 38h			;219f
	rst 38h			;21a0
	rst 38h			;21a1
	rst 38h			;21a2
	rst 38h			;21a3
	rst 38h			;21a4
l21a5h:
	call sub_0d1ch		;21a5
	call sub_0d70h		;21a8
	call sub_0a6ch		;21ab
	call l0fc0h		;21ae
	jp sub_24c4h		;21b1
	rst 38h			;21b4
	rst 38h			;21b5
	rst 38h			;21b6
	rst 38h			;21b7
	rst 38h			;21b8
	rst 38h			;21b9
l21bah:
	ld a,b			;21ba
	rrca			;21bb
	jp nc,l2204h		;21bc
	call sub_0c40h		;21bf
	call l0fc0h		;21c2
	call sub_24c4h		;21c5
	ld a,(043b8h)		;21c8
	and 00fh		;21cb
	cp 00bh		;21cd
	jp c,l2204h		;21cf
	ld a,010h		;21d2
	ld (043bah),a		;21d4
	jp l0526h		;21d7
	rst 38h			;21da
	rst 38h			;21db
l21dch:
	ld a,(hl)			;21dc
	nop			;21dd
	ld b,a			;21de
	ld hl,04b73h		;21df
	and 007h		;21e2
	ld (hl),a			;21e4
	dec l			;21e5
	ld (hl),0efh		;21e6
	dec l			;21e8
	ld (hl),049h		;21e9
	dec l			;21eb
	ld a,b			;21ec
	and 0f8h		;21ed
	rrca			;21ef
	rrca			;21f0
	rrca			;21f1
	add a,03ah		;21f2
	ld e,a			;21f4
	ld d,023h		;21f5
	ld a,(de)			;21f7
	ld (hl),a			;21f8
	call sub_34c0h		;21f9
	jp l1ee0h		;21fc
	rst 38h			;21ff
	rst 38h			;2200
	rst 38h			;2201
	rst 38h			;2202
	rst 38h			;2203
l2204h:
	ld hl,043b6h		;2204
	dec (hl)			;2207
	ld a,(hl)			;2208
	cp 0a0h		;2209
	ret nc			;220b
	ld l,0a4h		;220c
	ld (hl),002h		;220e
	ld l,0a6h		;2210
	ld (hl),000h		;2212
	ld l,0b8h		;2214
	inc (hl)			;2216
	ld a,(hl)			;2217
	and 00eh		;2218
	rrca			;221a
	add a,060h		;221b
	ld e,a			;221d
	ld d,017h		;221e
	inc l			;2220
	inc l			;2221
	ld a,(de)			;2222
	and a			;2223
	jp p,l222ah		;2224
	inc l			;2227
	and 07fh		;2228
l222ah:
	ld (hl),a			;222a
	jp sub_0380h		;222b
	rst 38h			;222e
	rst 38h			;222f
l2230h:
	ld hl,0439ch		;2230
	ld a,(hl)			;2233
	inc (hl)			;2234
	nop			;2235
	rrca			;2236
	and 03fh		;2237
	cp 00dh		;2239
	jp z,l2292h		;223b
	ld b,01fh		;223e
	jp c,l2260h		;2240
	ld b,000h		;2243
	sub 00eh		;2245
	cp 00dh		;2247
	jp nz,l2260h		;2249
l224ch:
	ld hl,043b8h		;224c
	inc (hl)			;224f
	ld l,0a4h		;2250
	ld (hl),002h		;2252
	ret			;2254
	ld e,b			;2255
	ld l,0a4h		;2256
	ld (hl),002h		;2258
	ret			;225a
	rst 38h			;225b
	rst 38h			;225c
	rst 38h			;225d
	rst 38h			;225e
	rst 38h			;225f
l2260h:
	ld c,a			;2260
	rrca			;2261
	rrca			;2262
	rrca			;2263
	ld d,a			;2264
	and 01fh		;2265
	ld e,a			;2267
	ld a,d			;2268
	and 0e0h		;2269
	add a,0b0h		;226b
	ld l,a			;226d
	ld a,e			;226e
	adc a,041h		;226f
	ld h,a			;2271
	ld a,l			;2272
	sub c			;2273
	ld l,a			;2274
	ld a,c			;2275
	inc a			;2276
	ld c,a			;2277
	rlca			;2278
	ld e,a			;2279
l227ah:
	ld d,c			;227a
l227bh:
	ld (hl),b			;227b
	inc hl			;227c
	ld (hl),b			;227d
	inc hl			;227e
	dec d			;227f
	jp nz,l227bh		;2280
	ld a,l			;2283
	sub c			;2284
	sub c			;2285
	sub 020h		;2286
	ld l,a			;2288
	ld a,h			;2289
	sbc a,000h		;228a
	ld h,a			;228c
	dec e			;228d
	jp nz,l227ah		;228e
	ret			;2291
l2292h:
	ld hl,043b8h		;2292
	ld a,(hl)			;2295
	and 008h		;2296
	jp z,l22f0h		;2298
	ld hl,l1c00h		;229b
	ld de,04b3fh		;229e
	ld b,047h		;22a1
l22a3h:
	ld a,(hl)			;22a3
	ld (de),a			;22a4
	inc l			;22a5
	dec de			;22a6
	ld a,(hl)			;22a7
	ld (de),a			;22a8
	inc l			;22a9
	dec de			;22aa
	ld a,b			;22ab
	cp d			;22ac
	jp nz,l22a3h		;22ad
	jp l22e0h		;22b0
	rst 38h			;22b3
	call sub_067ah		;22b4
	ld hl,043b4h		;22b7
	dec (hl)			;22ba
	ld a,(hl)			;22bb
	cp 028h		;22bc
	jp nz,l0848h		;22be
	ld l,067h		;22c1
	ld (hl),0ffh		;22c3
	ret			;22c5
	rst 38h			;22c6
	rst 38h			;22c7
	rst 38h			;22c8
	rst 38h			;22c9
	ld hl,043b4h		;22ca
	ld a,(hl)			;22cd
	cp 0c0h		;22ce
	jp nz,l0834h		;22d0
	ld (hl),030h		;22d3
	ld l,067h		;22d5
	ld (hl),0ffh		;22d7
	ld l,0bch		;22d9
	ld (hl),03fh		;22db
	ret			;22dd
	rst 38h			;22de
	rst 38h			;22df
l22e0h:
	ld a,071h		;22e0
l22e2h:
	ld (043b9h),a		;22e2
	ld (05800h),a		;22e5
	ret			;22e8
	rst 38h			;22e9
	rst 38h			;22ea
	rst 38h			;22eb
	rst 38h			;22ec
	rst 38h			;22ed
	rst 38h			;22ee
	rst 38h			;22ef
l22f0h:
	call sub_03a0h		;22f0
	xor a			;22f3
	jp l22e2h		;22f4
	rst 38h			;22f7
	rst 38h			;22f8
	rst 38h			;22f9
l22fah:
	ld hl,04aaah		;22fa
	ld b,012h		;22fd
	ld a,(0488ah)		;22ff
	ld c,a			;2302
l2303h:
	ld a,c			;2303
	and 003h		;2304
	rlca			;2306
	rlca			;2307
	ld d,a			;2308
	ld c,(hl)			;2309
	ld a,c			;230a
	and 00ch		;230b
	rrca			;230d
	rrca			;230e
	or d			;230f
	or 060h		;2310
	ld (hl),a			;2312
	ld a,l			;2313
	sub 020h		;2314
	ld l,a			;2316
	jp nc,l231bh		;2317
	dec h			;231a
l231bh:
	dec b			;231b
	jp nz,l2303h		;231c
	ret			;231f
	rst 38h			;2320
	rst 38h			;2321
l2322h:
	ld hl,043a7h		;2322
	inc (hl)			;2325
	ld a,(hl)			;2326
	and 007h		;2327
	rlca			;2329
	rlca			;232a
	rlca			;232b
	add a,0c0h		;232c
	ld l,a			;232e
	ld h,01bh		;232f
	ld de,049a6h		;2331
	ld bc,sub_0400h+2		;2334
	jp l0ad6h		;2337
	ld bc,l0300h+2		;233a
	inc b			;233d
	dec b			;233e
	ld b,007h		;233f
	ld a,(bc)			;2341
	rlca			;2342
	ld a,(bc)			;2343
	rlca			;2344
	ld a,(bc)			;2345
	rlca			;2346
	ld a,(bc)			;2347
	rlca			;2348
	ld a,(bc)			;2349
	add hl,bc			;234a
	ex af,af'			;234b
	inc b			;234c
	inc bc			;234d
	ld (bc),a			;234e
	ld bc,l1affh		;234f
	and 008h		;2352
	ret z			;2354
	ld a,(hl)			;2355
	inc l			;2356
	ld l,(hl)			;2357
	add a,008h		;2358
	ld h,a			;235a
	ld a,(043b9h)		;235b
	rrca			;235e
	rrca			;235f
	rrca			;2360
	add a,l			;2361
	and 01fh		;2362
	ld b,a			;2364
	ld a,l			;2365
	and 0e0h		;2366
	or b			;2368
	ld l,a			;2369
	ld a,(hl)			;236a
	ld b,a			;236b
	and 0fch		;236c
	cp 04ch		;236e
	jp z,l237bh		;2370
	and 0f0h		;2373
	cp 060h		;2375
	jp z,l2398h		;2377
	ret			;237a
l237bh:
	ld a,(de)			;237b
	and 0f7h		;237c
	ld (de),a			;237e
	ld a,0ffh		;237f
	ld (04366h),a		;2381
	ld a,b			;2384
	dec a			;2385
	ld (hl),a			;2386
	cp 04bh		;2387
	ret nz			;2389
	ld (hl),000h		;238a
	dec l			;238c
	ld a,(hl)			;238d
	cp 05eh		;238e
	ret nz			;2390
	ld (hl),04fh		;2391
	ret			;2393
	rst 38h			;2394
	rst 38h			;2395
	rst 38h			;2396
	rst 38h			;2397
l2398h:
	ld a,(de)			;2398
	and 0f7h		;2399
	ld (de),a			;239b
	inc e			;239c
	inc e			;239d
	ld a,(de)			;239e
	and 004h		;239f
	ld a,b			;23a1
	jp nz,l2030h		;23a2
	and 00ch		;23a5
	cp 004h		;23a7
	ld de,l1b40h		;23a9
l23ach:
	jp z,l23c0h		;23ac
	ld a,b			;23af
	and 00fh		;23b0
	add a,e			;23b2
	ld e,a			;23b3
	ld a,(de)			;23b4
	ld (hl),a			;23b5
	ld a,0ffh		;23b6
	ld (04366h),a		;23b8
	ret			;23bb
	rst 38h			;23bc
	rst 38h			;23bd
	rst 38h			;23be
	rst 38h			;23bf
l23c0h:
	dec l			;23c0
	ld a,(hl)			;23c1
	and 0f0h		;23c2
	cp 070h		;23c4
	ret nz			;23c6
	ld hl,043a4h		;23c7
	ld (hl),006h		;23ca
	inc l			;23cc
	ld (hl),060h		;23cd
	ld l,063h		;23cf
	ld (hl),0ffh		;23d1
	ret			;23d3
	rst 38h			;23d4
	rst 38h			;23d5
sub_23d6h:
	ld hl,043b8h		;23d6
	ld a,(hl)			;23d9
	and 00fh		;23da
	cp 001h		;23dc
	jp z,l3a98h		;23de
	cp 003h		;23e1
	jp z,l3a98h		;23e3
	cp 005h		;23e6
	jp z,l3ad0h		;23e8
	cp 007h		;23eb
	jp z,l3ad0h		;23ed
	cp 009h		;23f0
	ret c			;23f2
	cp 00bh		;23f3
	jp c,l3b02h		;23f5
	call l3b02h		;23f8
	jp l3a98h		;23fb
	rst 38h			;23fe
	rst 38h			;23ff
	call sub_242ch		;2400
	jp z,02552h		;2403
	cp 020h		;2406
	jp c,l246ah		;2408
	jp z,l2520h		;240b
	ld b,a			;240e
	rrca			;240f
	nop			;2410
	ld a,b			;2411
	jp nc,l20e8h		;2412
	ld a,e			;2415
	sub 005h		;2416
	add a,0c0h		;2418
	ld c,a			;241a
	ld a,d			;241b
	adc a,000h		;241c
	ld b,a			;241e
	ld a,(hl)			;241f
	ld de,l2a00h		;2420
	ld hl,l2b00h		;2423
	jp l2085h		;2426
	rst 38h			;2429
	rst 38h			;242a
	rst 38h			;242b
sub_242ch:
	ld hl,043b9h		;242c
	ld a,(hl)			;242f
	and 0f8h		;2430
	ld (hl),a			;2432
	ld (05800h),a		;2433
	ld de,041c6h		;2436
	rrca			;2439
	rrca			;243a
	rrca			;243b
	ld b,a			;243c
	ld a,e			;243d
	sub b			;243e
	and 01fh		;243f
	ld b,a			;2441
	ld a,e			;2442
	and 0e0h		;2443
	or b			;2445
	ld e,a			;2446
	ld l,0a5h		;2447
	dec (hl)			;2449
l244ah:
	ld a,(hl)			;244a
	ret			;244b
	ld hl,043a5h		;244c
	dec (hl)			;244f
	ld a,(hl)			;2450
	rrca			;2451
	jp c,l06f0h		;2452
	and a			;2455
	ret nz			;2456
	dec l			;2457
	ld (hl),002h		;2458
	ld l,0b8h		;245a
	ld a,(hl)			;245c
	and 0f0h		;245d
	add a,010h		;245f
	ld (hl),a			;2461
	ld l,0bah		;2462
	ld (hl),010h		;2464
	jp sub_0380h		;2466
	rst 38h			;2469
l246ah:
	ld bc,00914h		;246a
	ld de,04ac6h		;246d
	ld hl,l1c00h		;2470
	jp l0ad6h		;2473
l2476h:
	ld a,b			;2476
	add a,c			;2477
	call sub_2495h		;2478
	ld l,0d3h		;247b
	ld (hl),a			;247d
	ld hl,043bbh		;247e
	ld a,008h		;2481
	sub (hl)			;2483
	rlca			;2484
	ld l,09ah		;2485
	add a,(hl)			;2487
	rlca			;2488
	ld b,a			;2489
	ld l,06fh		;248a
	ld a,(hl)			;248c
	and 01eh		;248d
	add a,b			;248f
	ld (04bd1h),a		;2490
	ret			;2493
	rra			;2494
sub_2495h:
	add a,b			;2495
	dec c			;2496
	ret z			;2497
	add a,b			;2498
	dec c			;2499
	ret z			;249a
	add a,b			;249b
	dec c			;249c
	ret z			;249d
	add a,a			;249e
	ret			;249f
sub_24a0h:
	ld a,(043b8h)		;24a0
	and 00fh		;24a3
	cp 008h		;24a5
	ret c			;24a7
	ld de,043c4h		;24a8
	ld hl,043e6h		;24ab
	call 02351h		;24ae
	ld a,(0439bh)		;24b1
	and 003h		;24b4
	cp 003h		;24b6
	ret nz			;24b8
	jp l24f2h		;24b9
	call 02351h		;24bc
	ret			;24bf
	rst 38h			;24c0
	rst 38h			;24c1
	rst 38h			;24c2
	rst 38h			;24c3
sub_24c4h:
	ld a,(043b8h)		;24c4
	and 00fh		;24c7
	cp 008h		;24c9
	jp c,l06f0h		;24cb
	call sub_24e0h		;24ce
	ld hl,043aah		;24d1
	inc (hl)			;24d4
	ld a,(hl)			;24d5
	and 003h		;24d6
	jp z,l22fah		;24d8
	jp l2322h		;24db
	inc h			;24de
	cp a			;24df
sub_24e0h:
	ld a,(043aah)		;24e0
	and 00fh		;24e3
	ret nz			;24e5
	ld a,(043b9h)		;24e6
	cp 0a0h		;24e9
	ret c			;24eb
	jp sub_067ah		;24ec
	jp m,0c322h		;24ef
l24f2h:
	call sub_30aah		;24f2
	add a,060h		;24f5
	nop			;24f7
	ld b,a			;24f8
	ld hl,0439bh		;24f9
	and 00eh		;24fc
	and (hl)			;24fe
	ret nz			;24ff
	ld a,(0439eh)		;2500
	cp b			;2503
	ret nc			;2504
	ld a,(0439fh)		;2505
	cp b			;2508
	ret c			;2509
	ld a,b			;250a
	sub 004h		;250b
	ld b,a			;250d
	ld a,(043b9h)		;250e
	cpl			;2511
	inc a			;2512
	and 0f8h		;2513
	add a,048h		;2515
	ld c,a			;2517
	push hl			;2518
	push hl			;2519
	jp l25b7h		;251a
	rst 38h			;251d
	rst 38h			;251e
	rst 38h			;251f
l2520h:
	push de			;2520
	call sub_0380h		;2521
	pop de			;2524
	ld a,(043b9h)		;2525
	add a,060h		;2528
	rrca			;252a
	ld b,a			;252b
	ld a,(043b8h)		;252c
	and 0f0h		;252f
	add a,b			;2531
	ld b,090h		;2532
	jp c,l253dh		;2534
	cp 090h		;2537
	jp nc,l253dh		;2539
	ld b,a			;253c
l253dh:
	xor a			;253d
	ld a,b			;253e
	daa			;253f
	ld hl,0439dh		;2540
	ld (hl),a			;2543
	inc l			;2544
	ld (hl),000h		;2545
	ld a,e			;2547
	sub 05eh		;2548
	ld e,a			;254a
	ld b,004h		;254b
	jp l00c4h		;254d
	ld (l2e80h),a		;2550
	and h			;2553
	ld (hl),007h		;2554
	inc l			;2556
	ld (hl),040h		;2557
	ld l,06bh		;2559
	ld (hl),0ffh		;255b
	ret			;255d
	rst 38h			;255e
	rst 38h			;255f
l2560h:
	ld hl,04393h		;2560
	ld a,(hl)			;2563
	and 001h		;2564
	rlca			;2566
	rlca			;2567
	rlca			;2568
	rlca			;2569
	rlca			;256a
	add a,070h		;256b
	ld l,a			;256d
	ld h,04bh		;256e
	ld e,008h		;2570
	ld a,(04357h)		;2572
	rlca			;2575
	rlca			;2576
	rlca			;2577
	nop			;2578
	add a,0adh		;2579
	ld d,a			;257b
	ld a,(0439fh)		;257c
	add a,003h		;257f
	ld c,a			;2581
	ld a,(0439eh)		;2582
	sub 00ah		;2585
	ld b,a			;2587
l2588h:
	push hl			;2588
	call sub_2596h		;2589
	pop hl			;258c
	ld a,l			;258d
	add a,004h		;258e
	ld l,a			;2590
	dec e			;2591
	jp nz,l2588h		;2592
	ret			;2595
sub_2596h:
	ld a,(hl)			;2596
	and 008h		;2597
	ret z			;2599
	inc l			;259a
	ld a,(hl)			;259b
	cp 008h		;259c
	ret z			;259e
	cp 088h		;259f
	ret nc			;25a1
	inc l			;25a2
	ld a,(hl)			;25a3
	cp b			;25a4
	ret c			;25a5
	cp c			;25a6
	ret nc			;25a7
	inc l			;25a8
	ld a,(hl)			;25a9
	cp d			;25aa
	ret nc			;25ab
	cp 080h		;25ac
	ret c			;25ae
	nop			;25af
	nop			;25b0
	nop			;25b1
	nop			;25b2
	nop			;25b3
	ld c,a			;25b4
	dec l			;25b5
	ld b,(hl)			;25b6
l25b7h:
	ld a,(043b8h)		;25b7
	ld d,003h		;25ba
	cp 010h		;25bc
	jp c,l25cah		;25be
	ld d,004h		;25c1
	cp 020h		;25c3
	jp c,l25cah		;25c5
	ld d,005h		;25c8
l25cah:
	ld hl,043cch		;25ca
l25cdh:
	ld a,(hl)			;25cd
	and 008h		;25ce
	jp z,l25e0h		;25d0
	ld a,l			;25d3
	add a,004h		;25d4
	ld l,a			;25d6
	dec d			;25d7
	jp nz,l25cdh		;25d8
	pop hl			;25db
	pop hl			;25dc
	ret			;25dd
	rst 38h			;25de
	rst 38h			;25df
l25e0h:
	ld a,b			;25e0
	add a,004h		;25e1
	ld b,a			;25e3
	ld a,c			;25e4
	add a,00ch		;25e5
	ld c,a			;25e7
	ld (hl),008h		;25e8
	inc l			;25ea
	ld a,b			;25eb
	rrca			;25ec
	and 003h		;25ed
	ld d,a			;25ef
	ld a,c			;25f0
	and 004h		;25f1
	add a,d			;25f3
	add a,058h		;25f4
	ld (hl),a			;25f6
	inc l			;25f7
	ld (hl),b			;25f8
	inc l			;25f9
	ld (hl),c			;25fa
	pop hl			;25fb
	pop hl			;25fc
	ret			;25fd
	rst 38h			;25fe
	rst 38h			;25ff
sub_2600h:
	nop			;2600
	nop			;2601
	nop			;2602
	nop			;2603
	nop			;2604
	ld a,(043b9h)		;2605
	cpl			;2608
	rrca			;2609
	rrca			;260a
	rrca			;260b
	and 01fh		;260c
	ld hl,04bd2h		;260e
	ld (hl),a			;2611
	inc l			;2612
	ld a,(04bd1h)		;2613
	cp (hl)			;2616
	jp c,02650h		;2617
	ld a,(04bd5h)		;261a
	ld d,a			;261d
	and 003h		;261e
	ld e,a			;2620
	ld a,(0439bh)		;2621
	rlca			;2624
	rlca			;2625
	and 00ch		;2626
	add a,e			;2628
	add a,0d0h		;2629
	ld l,a			;262b
	ld h,03eh		;262c
	ld a,d			;262e
	rrca			;262f
	rrca			;2630
	and 007h		;2631
	add a,(hl)			;2633
	ld d,a			;2634
	ld a,(043b9h)		;2635
	sub d			;2638
l2639h:
	ld (043b9h),a		;2639
	ld (05800h),a		;263c
	ld a,(0439bh)		;263f
	rrca			;2642
	jp nc,l26d0h		;2643
	call sub_2668h		;2646
	jp l26aah		;2649
	jp nz,l2639h+1		;264c
	ld a,(l3a2ch)		;264f
	sbc a,e			;2652
	ld b,e			;2653
	rlca			;2654
	rlca			;2655
	and 00ch		;2656
	add a,(hl)			;2658
	add a,0d0h		;2659
	ld l,a			;265b
	ld h,03eh		;265c
	ld a,(043b9h)		;265e
	add a,(hl)			;2661
	jp l2639h		;2662
	jp nc,l26aeh		;2665
sub_2668h:
	ld a,(0436eh)		;2668
	nop			;266b
	ld b,a			;266c
	ld a,(0439ah)		;266d
	cp 018h		;2670
	jp c,l2676h		;2672
	inc b			;2675
l2676h:
	cp 010h		;2676
	jp c,l267ch		;2678
	inc b			;267b
l267ch:
	ld a,(043bah)		;267c
	cp 003h		;267f
	jp nc,l2685h		;2681
	inc b			;2684
l2685h:
	ld a,(04bd6h)		;2685
	add a,0e0h		;2688
	ld l,a			;268a
	ld h,03eh		;268b
	ld a,b			;268d
	cp (hl)			;268e
	jp c,l2693h		;268f
	ld a,(hl)			;2692
l2693h:
	ld d,a			;2693
	ld a,(043bbh)		;2694
	cp 004h		;2697
	jp nc,l269dh		;2699
	inc d			;269c
l269dh:
	cp 002h		;269d
	jp nc,l26a3h		;269f
	inc d			;26a2
l26a3h:
	ld a,d			;26a3
	ld (04bd5h),a		;26a4
	ret			;26a7
	nop			;26a8
	ld e,b			;26a9
l26aah:
	ld hl,04bd3h		;26aa
	ld a,(hl)			;26ad
l26aeh:
	dec (hl)			;26ae
	and a			;26af
	ret nz			;26b0
	inc (hl)			;26b1
	ld l,0d6h		;26b2
	ld a,(hl)			;26b4
	cp 016h		;26b5
	ret nc			;26b7
	cp 008h		;26b8
	ret c			;26ba
	inc l			;26bb
	sub (hl)			;26bc
	rlca			;26bd
	ld b,a			;26be
	ld a,(0436fh)		;26bf
	and 003h		;26c2
	ld l,0d4h		;26c4
	ld (hl),a			;26c6
	cpl			;26c7
	and 003h		;26c8
	inc a			;26ca
	ld c,a			;26cb
	jp l2476h		;26cc
	ret			;26cf
l26d0h:
	ld hl,04ba8h		;26d0
	ld bc,l0800h		;26d3
	ld de,08000h		;26d6
l26d9h:
	ld a,(hl)			;26d9
	and a			;26da
	jp z,l26e5h		;26db
	ld a,d			;26de
	rlca			;26df
	jp nc,l26e4h		;26e0
	ld d,c			;26e3
l26e4h:
	ld e,c			;26e4
l26e5h:
	inc c			;26e5
	ld a,l			;26e6
	sub b			;26e7
	ld l,a			;26e8
	cp 068h		;26e9
	jp nz,l26d9h		;26eb
	ld a,(04bd2h)		;26ee
	add a,d			;26f1
	add a,e			;26f2
	and 01fh		;26f3
	ld (04bd6h),a		;26f5
	ld a,e			;26f8
	sub d			;26f9
	ld (04bd7h),a		;26fa
	ret			;26fd
	rst 38h			;26fe
	rst 38h			;26ff
sub_2700h:
	ld hl,043a2h		;2700
	ld a,(hl)			;2703
	and a			;2704
	ret z			;2705
	inc l			;2706
	ld a,(hl)			;2707
	and 001h		;2708
	rlca			;270a
	rlca			;270b
	add a,083h		;270c
	ld l,a			;270e
	ld a,0ffh		;270f
	ld (04397h),a		;2711
	ld de,04370h		;2714
l2717h:
	call sub_2748h		;2717
	inc e			;271a
	inc e			;271b
	inc e			;271c
	ld a,e			;271d
	cp 080h		;271e
	jp nz,l2717h		;2720
	ld e,09dh		;2723
	ld a,(043a4h)		;2725
	cp 006h		;2728
	jp nz,l2739h		;272a
	ld a,(de)			;272d
	ld b,a			;272e
	ld c,000h		;272f
	call sub_0220h		;2731
	xor a			;2734
	ld (de),a			;2735
	ld (04397h),a		;2736
l2739h:
	ld a,(04397h)		;2739
	and a			;273c
	call z,sub_2768h		;273d
	call sub_27a8h		;2740
	jp l3a10h		;2743
	rst 38h			;2746
	rst 38h			;2747
sub_2748h:
	ld a,(de)			;2748
	inc e			;2749
	cp 001h		;274a
	ret nz			;274c
	ld a,(de)			;274d
	and a			;274e
	ret z			;274f
	rrca			;2750
	rrca			;2751
	rrca			;2752
	rrca			;2753
	ld b,a			;2754
	and 0f0h		;2755
	ld c,a			;2757
	ld a,b			;2758
	and 00fh		;2759
	ld b,a			;275b
	call sub_0220h		;275c
	xor a			;275f
	ld (de),a			;2760
	ld (04397h),a		;2761
	ret			;2764
	rst 38h			;2765
	rst 38h			;2766
	rst 38h			;2767
sub_2768h:
	push hl			;2768
	ld de,04261h		;2769
	ld b,006h		;276c
	ld a,(043a3h)		;276e
	and a			;2771
	jp z,l2778h		;2772
	ld de,04021h		;2775
l2778h:
	call l00c4h		;2778
	pop hl			;277b
	ld de,043bdh		;277c
	ex de,hl			;277f
	ld a,(hl)			;2780
	inc l			;2781
	or (hl)			;2782
	ret z			;2783
	inc l			;2784
	ex de,hl			;2785
	call sub_0314h		;2786
	ret nc			;2789
	ld a,(043a3h)		;278a
	add a,090h		;278d
	ld l,a			;278f
	inc (hl)			;2790
	call l0367h		;2791
	ld a,0ffh		;2794
	ld (0436ah),a		;2796
	ld l,0beh		;2799
	ld a,(hl)			;279b
	ld (hl),000h		;279c
	rrca			;279e
	rrca			;279f
	rrca			;27a0
	rrca			;27a1
	dec l			;27a2
	ld (hl),a			;27a3
	ret			;27a4
	rst 38h			;27a5
	rst 38h			;27a6
	rst 38h			;27a7
sub_27a8h:
	ld hl,0438ch		;27a8
	ld a,(hl)			;27ab
	ld (06000h),a		;27ac
	inc l			;27af
	ld a,(hl)			;27b0
	ld (06800h),a		;27b1
	or 00fh		;27b4
	ld (hl),a			;27b6
	dec l			;27b7
	ld (hl),00fh		;27b8
	ret			;27ba
	rst 38h			;27bb
	rst 38h			;27bc
sub_27bdh:
	ld hl,04363h		;27bd
	ld a,(hl)			;27c0
	and a			;27c1
	jp nz,027e2h		;27c2
	ld l,061h		;27c5
	ld a,(hl)			;27c7
	and a			;27c8
	ret z			;27c9
	cp 019h		;27ca
	jp nc,l27d8h		;27cc
	dec (hl)			;27cf
	ld l,08ch		;27d0
	ld a,(hl)			;27d2
	or 040h		;27d3
	ld (hl),a			;27d5
	ret			;27d6
	ld (hl),a			;27d7
l27d8h:
	ld (hl),018h		;27d8
	ld l,08ch		;27da
	ld a,(hl)			;27dc
	and 0bfh		;27dd
	ld (hl),a			;27df
	ret			;27e0
	ld (hl),0feh		;27e1
	ld b,b			;27e3
	jp c,l27e9h		;27e4
	ld (hl),040h		;27e7
l27e9h:
	dec (hl)			;27e9
	ld l,08ch		;27ea
	ld (hl),08fh		;27ec
	ret			;27ee
	rst 38h			;27ef
	rst 38h			;27f0
	rst 38h			;27f1
	rst 38h			;27f2
	rst 38h			;27f3
	rst 38h			;27f4
	rst 38h			;27f5
	rst 38h			;27f6
	rst 38h			;27f7
	rst 38h			;27f8
	rst 38h			;27f9
	rst 38h			;27fa
	rst 38h			;27fb
	rst 38h			;27fc
	rst 38h			;27fd
	rst 38h			;27fe
	rst 38h			;27ff
l2800h:
	nop			;2800
	ld (l0000h),a		;2801
	nop			;2804
	nop			;2805
	nop			;2806
	nop			;2807
	nop			;2808
	nop			;2809
	nop			;280a
	nop			;280b
	nop			;280c
	nop			;280d
	ld b,d			;280e
	ld b,d			;280f
	nop			;2810
	nop			;2811
	nop			;2812
	nop			;2813
	nop			;2814
	nop			;2815
	nop			;2816
	nop			;2817
	nop			;2818
	nop			;2819
	pop hl			;281a
	nop			;281b
	nop			;281c
	jp po,l0000h		;281d
	ld (l0000h),a		;2820
	nop			;2823
	nop			;2824
	nop			;2825
	nop			;2826
	nop			;2827
	nop			;2828
l2829h:
	ret po			;2829
l282ah:
	nop			;282a
	nop			;282b
	ld b,b			;282c
	nop			;282d
	nop			;282e
	jp l0000h		;282f
	nop			;2832
	nop			;2833
	nop			;2834
	nop			;2835
	rst 18h			;2836
	nop			;2837
	nop			;2838
	jp po,l0000h		;2839
	ret po			;283c
	nop			;283d
	pop hl			;283e
	nop			;283f
	nop			;2840
	jr nc,l2843h		;2841
l2843h:
	nop			;2843
	nop			;2844
	nop			;2845
	sbc a,000h		;2846
	nop			;2848
	nop			;2849
	jp nz,04000h		;284a
	nop			;284d
	ret po			;284e
	nop			;284f
	nop			;2850
	nop			;2851
	nop			;2852
	jr nc,l2855h		;2853
l2855h:
	jr nc,l2857h		;2855
l2857h:
	ld e,d			;2857
	nop			;2858
	nop			;2859
	pop hl			;285a
	nop			;285b
	ld b,b			;285c
	nop			;285d
	jp po,l0000h		;285e
	nop			;2861
	nop			;2862
	nop			;2863
	nop			;2864
	nop			;2865
	nop			;2866
	jr nc,l282ah		;2867
	ld a,000h		;2869
	ret po			;286b
	nop			;286c
	ld b,b			;286d
	jp nz,l0000h		;286e
	nop			;2871
	nop			;2872
	nop			;2873
	nop			;2874
	nop			;2875
	nop			;2876
	nop			;2877
	nop			;2878
	ld e,d			;2879
	pop bc			;287a
	ld a,0c8h		;287b
	ret c			;287d
	nop			;287e
	nop			;287f
	ret po			;2880
	pop hl			;2881
	jp nz,0e0e2h		;2882
	nop			;2885
	pop hl			;2886
	nop			;2887
	jp nz,0e200h		;2888
	adc a,0cah		;288b
	jp c,l0000h		;288d
	nop			;2890
	nop			;2891
	nop			;2892
	nop			;2893
	nop			;2894
	nop			;2895
	nop			;2896
	nop			;2897
	rst 8			;2898
	rst 8			;2899
	jp 0c23fh		;289a
	ld b,c			;289d
	ret po			;289e
	nop			;289f
	nop			;28a0
	nop			;28a1
	nop			;28a2
	nop			;28a3
	nop			;28a4
	nop			;28a5
	nop			;28a6
	sbc a,000h		;28a7
	ccf			;28a9
	nop			;28aa
	jp nz,l0040h+1		;28ab
	pop hl			;28ae
	nop			;28af
	nop			;28b0
	nop			;28b1
	nop			;28b2
	nop			;28b3
	nop			;28b4
	dec a			;28b5
	rst 18h			;28b6
	dec a			;28b7
	nop			;28b8
	nop			;28b9
	pop hl			;28ba
	nop			;28bb
	ld b,c			;28bc
	nop			;28bd
	nop			;28be
	jp nz,l0000h		;28bf
	nop			;28c2
	dec a			;28c3
	nop			;28c4
	nop			;28c5
	nop			;28c6
	nop			;28c7
	nop			;28c8
	ret po			;28c9
	nop			;28ca
	nop			;28cb
	ld b,c			;28cc
	nop			;28cd
	nop			;28ce
	jp po,l0000h		;28cf
	dec a			;28d2
	nop			;28d3
	nop			;28d4
	nop			;28d5
	nop			;28d6
	nop			;28d7
	jp po,l0000h		;28d8
	nop			;28db
	nop			;28dc
	ld c,a			;28dd
	nop			;28de
	ret po			;28df
	nop			;28e0
	dec sp			;28e1
	nop			;28e2
	nop			;28e3
	nop			;28e4
	nop			;28e5
	nop			;28e6
	nop			;28e7
	nop			;28e8
	jp nz,l0000h		;28e9
	nop			;28ec
	ld c,a			;28ed
	nop			;28ee
	nop			;28ef
	nop			;28f0
	nop			;28f1
	dec sp			;28f2
	nop			;28f3
	nop			;28f4
	nop			;28f5
	nop			;28f6
	nop			;28f7
	nop			;28f8
	nop			;28f9
	nop			;28fa
	nop			;28fb
	nop			;28fc
	nop			;28fd
	ld c,l			;28fe
	ld c,l			;28ff
l2900h:
	nop			;2900
	nop			;2901
	nop			;2902
	nop			;2903
	nop			;2904
	nop			;2905
	nop			;2906
	nop			;2907
	nop			;2908
	nop			;2909
	nop			;290a
	nop			;290b
	nop			;290c
	jr nz,l290fh		;290d
l290fh:
	jr c,l2911h		;290f
l2911h:
	inc (hl)			;2911
	nop			;2912
	jr z,l2915h		;2913
l2915h:
	nop			;2915
	nop			;2916
	nop			;2917
	nop			;2918
	nop			;2919
	nop			;291a
	nop			;291b
	nop			;291c
	nop			;291d
	nop			;291e
	nop			;291f
	nop			;2920
	nop			;2921
	nop			;2922
	nop			;2923
	nop			;2924
	nop			;2925
	nop			;2926
	nop			;2927
	nop			;2928
	nop			;2929
	nop			;292a
	djnz l292dh		;292b
l292dh:
	ld (bc),a			;292d
	nop			;292e
	nop			;292f
	nop			;2930
	ld bc,l0000h		;2931
	ld (de),a			;2934
	nop			;2935
	nop			;2936
	nop			;2937
	nop			;2938
	nop			;2939
	nop			;293a
	nop			;293b
	nop			;293c
	nop			;293d
	nop			;293e
	nop			;293f
	nop			;2940
	nop			;2941
	nop			;2942
	nop			;2943
	nop			;2944
	nop			;2945
	nop			;2946
	nop			;2947
	nop			;2948
	djnz l294bh		;2949
l294bh:
	nop			;294b
	add a,b			;294c
	ld c,b			;294d
	nop			;294e
	inc b			;294f
	ld b,b			;2950
	ex af,af'			;2951
	nop			;2952
	ld d,b			;2953
	nop			;2954
	nop			;2955
	add a,b			;2956
	djnz l2959h		;2957
l2959h:
	nop			;2959
	nop			;295a
	nop			;295b
	nop			;295c
	nop			;295d
	nop			;295e
	nop			;295f
	nop			;2960
	nop			;2961
	nop			;2962
	nop			;2963
	nop			;2964
	nop			;2965
	nop			;2966
	djnz l2969h		;2967
l2969h:
	nop			;2969
	jr nz,l29b0h		;296a
	nop			;296c
	nop			;296d
	nop			;296e
	ld (bc),a			;296f
	djnz l2972h		;2970
l2972h:
	nop			;2972
	inc b			;2973
	nop			;2974
	ld c,b			;2975
	jr nz,l2978h		;2976
l2978h:
	nop			;2978
	djnz l297bh		;2979
l297bh:
	nop			;297b
	nop			;297c
	nop			;297d
	nop			;297e
	nop			;297f
	nop			;2980
	nop			;2981
	nop			;2982
	nop			;2983
	nop			;2984
	djnz l2987h		;2985
l2987h:
	nop			;2987
	nop			;2988
	ld b,h			;2989
	ex af,af'			;298a
	nop			;298b
	nop			;298c
	ld bc,l0000h		;298d
	ex af,af'			;2990
	nop			;2991
	nop			;2992
	ld (bc),a			;2993
	nop			;2994
	nop			;2995
	nop			;2996
	add a,h			;2997
	ex af,af'			;2998
	nop			;2999
	nop			;299a
	jr nz,l299dh		;299b
l299dh:
	nop			;299d
	nop			;299e
	nop			;299f
	nop			;29a0
	nop			;29a1
	nop			;29a2
	jr nz,l29a5h		;29a3
l29a5h:
	nop			;29a5
	nop			;29a6
	ld b,d			;29a7
	ld (bc),a			;29a8
	nop			;29a9
	add a,b			;29aa
	nop			;29ab
	nop			;29ac
	nop			;29ad
	nop			;29ae
	nop			;29af
l29b0h:
	inc b			;29b0
	nop			;29b1
	nop			;29b2
	ld bc,l0000h		;29b3
	nop			;29b6
	nop			;29b7
	nop			;29b8
	add a,d			;29b9
	inc b			;29ba
	nop			;29bb
	nop			;29bc
	jr nz,l29bfh		;29bd
l29bfh:
	nop			;29bf
	nop			;29c0
	ld b,b			;29c1
	nop			;29c2
	nop			;29c3
	ld bc,l0082h		;29c4
	nop			;29c7
	ld b,b			;29c8
	nop			;29c9
	nop			;29ca
	nop			;29cb
	nop			;29cc
	nop			;29cd
	nop			;29ce
	nop			;29cf
	ld (bc),a			;29d0
	nop			;29d1
	nop			;29d2
	nop			;29d3
	add a,b			;29d4
	nop			;29d5
	nop			;29d6
	nop			;29d7
	nop			;29d8
	nop			;29d9
	nop			;29da
	add a,c			;29db
	ld (bc),a			;29dc
	nop			;29dd
	nop			;29de
	ld b,b			;29df
	ld (bc),a			;29e0
	add a,b			;29e1
	nop			;29e2
	inc b			;29e3
	nop			;29e4
	nop			;29e5
	ld b,b			;29e6
	nop			;29e7
	nop			;29e8
	nop			;29e9
	nop			;29ea
	nop			;29eb
	nop			;29ec
	nop			;29ed
	nop			;29ee
	nop			;29ef
	ld bc,l0000h		;29f0
	nop			;29f3
	nop			;29f4
	nop			;29f5
	ld b,b			;29f6
	nop			;29f7
	nop			;29f8
	nop			;29f9
	nop			;29fa
	nop			;29fb
	nop			;29fc
	ld (bc),a			;29fd
	inc b			;29fe
	ex af,af'			;29ff
l2a00h:
	nop			;2a00
	nop			;2a01
	nop			;2a02
	nop			;2a03
	nop			;2a04
	nop			;2a05
	nop			;2a06
	jp nc,l0000h		;2a07
	nop			;2a0a
	nop			;2a0b
	nop			;2a0c
	nop			;2a0d
	nop			;2a0e
	nop			;2a0f
	nop			;2a10
	nop			;2a11
	nop			;2a12
l2a13h:
	nop			;2a13
	nop			;2a14
	sbc a,000h		;2a15
	ld e,(hl)			;2a17
	ret po			;2a18
	nop			;2a19
l2a1ah:
	nop			;2a1a
	pop hl			;2a1b
	nop			;2a1c
	nop			;2a1d
	nop			;2a1e
	nop			;2a1f
	nop			;2a20
	nop			;2a21
	pop bc			;2a22
	nop			;2a23
	nop			;2a24
	rst 8			;2a25
	ld d,e			;2a26
	jp po,0d200h		;2a27
	ret po			;2a2a
	nop			;2a2b
	nop			;2a2c
	ret nc			;2a2d
	nop			;2a2e
	nop			;2a2f
	nop			;2a30
	nop			;2a31
	nop			;2a32
	sbc a,000h		;2a33
	adc a,053h		;2a35
	pop hl			;2a37
	pop de			;2a38
	ex (sp),hl			;2a39
	nop			;2a3a
	pop hl			;2a3b
	out (000h),a		;2a3c
	nop			;2a3e
	nop			;2a3f
	nop			;2a40
	nop			;2a41
	rst 8			;2a42
	ret nz			;2a43
	sbc a,0dfh		;2a44
	ld d,e			;2a46
	out (0e2h),a		;2a47
	nop			;2a49
	jp po,l00d2h		;2a4a
	ld e,(hl)			;2a4d
	jp po,l0000h		;2a4e
	nop			;2a51
	nop			;2a52
	adc a,0c1h		;2a53
	jp nz,0d2deh		;2a55
	pop hl			;2a58
	ex (sp),hl			;2a59
	pop de			;2a5a
	nop			;2a5b
	jp nc,l0000h		;2a5c
	nop			;2a5f
	nop			;2a60
	nop			;2a61
	nop			;2a62
	nop			;2a63
	rst 18h			;2a64
	sbc a,0c2h		;2a65
	rst 8			;2a67
	ret po			;2a68
	ret nc			;2a69
	jp po,0c2e1h		;2a6a
	jp l0000h		;2a6d
	rst 18h			;2a70
	sbc a,0cfh		;2a71
	adc a,0dfh		;2a73
	sbc a,0cfh		;2a75
	ret z			;2a77
	ret c			;2a78
	ld e,(hl)			;2a79
	adc a,000h		;2a7a
	rst 8			;2a7c
	sbc a,0dfh		;2a7d
	adc a,0e0h		;2a7f
	ex (sp),hl			;2a81
	jp po,l00e1h		;2a82
	ret po			;2a85
	pop de			;2a86
	jp z,0d1dah		;2a87
	jp nc,0d0d3h		;2a8a
	pop de			;2a8d
	jp nc,l00d3h		;2a8e
	nop			;2a91
	nop			;2a92
	nop			;2a93
	ex (sp),hl			;2a94
	jp nc,0d2ceh		;2a95
	jp po,0d3e0h		;2a98
	pop de			;2a9b
	out (000h),a		;2a9c
	nop			;2a9e
	nop			;2a9f
	nop			;2aa0
	nop			;2aa1
	nop			;2aa2
	jp po,0cfd3h		;2aa3
	rst 18h			;2aa6
	pop hl			;2aa7
	ret nc			;2aa8
	ex (sp),hl			;2aa9
	pop hl			;2aaa
	jp nc,l0000h		;2aab
	nop			;2aae
	nop			;2aaf
	nop			;2ab0
	nop			;2ab1
	pop hl			;2ab2
	ret nc			;2ab3
	sbc a,000h		;2ab4
	sbc a,0e2h		;2ab6
	nop			;2ab8
	out (053h),a		;2ab9
	jp po,0c15eh		;2abb
	ret nz			;2abe
	nop			;2abf
	nop			;2ac0
	nop			;2ac1
	nop			;2ac2
	rst 18h			;2ac3
	nop			;2ac4
	nop			;2ac5
	rst 8			;2ac6
	ld e,(hl)			;2ac7
	pop de			;2ac8
	jp nc,05300h		;2ac9
	ex (sp),hl			;2acc
	nop			;2acd
	nop			;2ace
	nop			;2acf
	nop			;2ad0
	nop			;2ad1
	adc a,000h		;2ad2
	rst 8			;2ad4
	nop			;2ad5
	adc a,0d2h		;2ad6
	jp nc,05300h		;2ad8
	nop			;2adb
	ld e,(hl)			;2adc
	ret po			;2add
	nop			;2ade
	nop			;2adf
	nop			;2ae0
	nop			;2ae1
	nop			;2ae2
	nop			;2ae3
	nop			;2ae4
	sbc a,000h		;2ae5
	pop hl			;2ae7
	out (000h),a		;2ae8
	jp po,l0000h		;2aea
	nop			;2aed
	nop			;2aee
	nop			;2aef
	nop			;2af0
	nop			;2af1
	nop			;2af2
	nop			;2af3
	nop			;2af4
	nop			;2af5
	nop			;2af6
	ld e,(hl)			;2af7
	ret nc			;2af8
	nop			;2af9
	nop			;2afa
	nop			;2afb
	nop			;2afc
	nop			;2afd
	nop			;2afe
	nop			;2aff
l2b00h:
	nop			;2b00
	nop			;2b01
	nop			;2b02
	nop			;2b03
	nop			;2b04
	nop			;2b05
	nop			;2b06
	nop			;2b07
	nop			;2b08
	nop			;2b09
	add a,b			;2b0a
	ld bc,l0240h		;2b0b
	add a,b			;2b0e
	dec b			;2b0f
	and b			;2b10
	ld bc,l0240h		;2b11
	nop			;2b14
	ld bc,l0000h		;2b15
	nop			;2b18
	nop			;2b19
	nop			;2b1a
	nop			;2b1b
	nop			;2b1c
	nop			;2b1d
	nop			;2b1e
	nop			;2b1f
	nop			;2b20
	nop			;2b21
	nop			;2b22
	nop			;2b23
	nop			;2b24
	nop			;2b25
	add a,b			;2b26
	nop			;2b27
	nop			;2b28
	ld bc,sub_041eh+2		;2b29
	nop			;2b2c
	ld bc,l1240h		;2b2d
	ld c,b			;2b30
	ld (bc),a			;2b31
	add a,b			;2b32
	ld bc,sub_041eh+2		;2b33
	nop			;2b36
	nop			;2b37
	nop			;2b38
	ld bc,l0000h		;2b39
	nop			;2b3c
	nop			;2b3d
	nop			;2b3e
	nop			;2b3f
	nop			;2b40
	nop			;2b41
	nop			;2b42
	nop			;2b43
	add a,b			;2b44
	nop			;2b45
	nop			;2b46
	ld (bc),a			;2b47
	djnz l2b52h		;2b48
	nop			;2b4a
	ld bc,00480h		;2b4b
	and b			;2b4e
	ld hl,00584h		;2b4f
l2b52h:
	jr nz,$+4		;2b52
	add a,b			;2b54
	ld bc,l0810h		;2b55
	nop			;2b58
	nop			;2b59
	nop			;2b5a
	ld bc,l0000h		;2b5b
	nop			;2b5e
	nop			;2b5f
	nop			;2b60
	nop			;2b61
	add a,b			;2b62
	nop			;2b63
	nop			;2b64
	inc b			;2b65
	ex af,af'			;2b66
	djnz l2b69h		;2b67
l2b69h:
	ld bc,l0040h		;2b69
	ld b,b			;2b6c
	ld a,(bc)			;2b6d
	djnz l2bb0h		;2b6e
	ld (bc),a			;2b70
	ex af,af'			;2b71
	ld b,b			;2b72
	nop			;2b73
	djnz $+6		;2b74
	add a,b			;2b76
	ld (bc),a			;2b77
	ex af,af'			;2b78
	djnz l2b7bh		;2b79
l2b7bh:
	nop			;2b7b
	nop			;2b7c
	ld bc,l0000h		;2b7d
	add a,b			;2b80
	nop			;2b81
	nop			;2b82
	ex af,af'			;2b83
	inc b			;2b84
	jr nz,l2b87h		;2b85
l2b87h:
	ld (bc),a			;2b87
	jr nz,l2b8ah		;2b88
l2b8ah:
	jr nz,$+22		;2b8a
	nop			;2b8c
	ld bc,08008h		;2b8d
	ld bc,08010h		;2b90
	ld (bc),a			;2b93
	jr nz,l2b96h		;2b94
l2b96h:
	ex af,af'			;2b96
	inc b			;2b97
	add a,b			;2b98
	ld (bc),a			;2b99
	inc b			;2b9a
	jr nz,l2b9dh		;2b9b
l2b9dh:
	nop			;2b9d
	nop			;2b9e
	ld bc,l0101h		;2b9f
	ld bc,l0101h		;2ba2
	inc b			;2ba5
	jr nz,l2ba8h		;2ba6
l2ba8h:
	djnz l2bd2h		;2ba8
	add a,b			;2baa
	ld (bc),a			;2bab
	inc b			;2bac
	nop			;2bad
	nop			;2bae
	inc b			;2baf
l2bb0h:
	jr nz,l2bd2h		;2bb0
	nop			;2bb2
	inc b			;2bb3
	ld b,b			;2bb4
	ld bc,00010h		;2bb5
	inc b			;2bb8
	ex af,af'			;2bb9
	add a,b			;2bba
	inc b			;2bbb
	nop			;2bbc
	nop			;2bbd
	nop			;2bbe
	nop			;2bbf
	nop			;2bc0
	nop			;2bc1
	nop			;2bc2
	ex af,af'			;2bc3
	jr nz,l2bc6h		;2bc4
l2bc6h:
	adc a,b			;2bc6
	djnz l2bc9h		;2bc7
l2bc9h:
	ld b,h			;2bc9
	nop			;2bca
	nop			;2bcb
	nop			;2bcc
	djnz l2bd1h		;2bcd
	nop			;2bcf
	ex af,af'			;2bd0
l2bd1h:
	ld b,b			;2bd1
l2bd2h:
	nop			;2bd2
	nop			;2bd3
	nop			;2bd4
	ex af,af'			;2bd5
	ld b,b			;2bd6
	nop			;2bd7
	ex af,af'			;2bd8
	ld bc,l1000h		;2bd9
	add a,b			;2bdc
	inc b			;2bdd
	nop			;2bde
	nop			;2bdf
	nop			;2be0
	nop			;2be1
	jr nz,l2be4h		;2be2
l2be4h:
	add a,h			;2be4
	jr nz,l2be7h		;2be5
l2be7h:
	ex af,af'			;2be7
	nop			;2be8
	nop			;2be9
	nop			;2bea
	nop			;2beb
	nop			;2bec
	jr nz,l2bf0h		;2bed
	nop			;2bef
l2bf0h:
	inc b			;2bf0
	add a,b			;2bf1
	nop			;2bf2
	nop			;2bf3
	nop			;2bf4
	nop			;2bf5
	nop			;2bf6
	djnz l2c39h		;2bf7
	nop			;2bf9
	inc b			;2bfa
	ld bc,l0000h		;2bfb
	add a,b			;2bfe
	nop			;2bff
l2c00h:
	dec bc			;2c00
	inc c			;2c01
	dec c			;2c02
	ld c,00bh		;2c03
	inc c			;2c05
	ld a,(bc)			;2c06
	ld a,(bc)			;2c07
	ld a,(bc)			;2c08
	ld a,(bc)			;2c09
	ld a,(bc)			;2c0a
	ld a,(bc)			;2c0b
	ld a,(bc)			;2c0c
	ld b,006h		;2c0d
	ld e,003h		;2c0f
	inc bc			;2c11
	rra			;2c12
	dec b			;2c13
	dec b			;2c14
	inc e			;2c15
	inc b			;2c16
	inc b			;2c17
	inc b			;2c18
	dec e			;2c19
	ld b,006h		;2c1a
	ld a,(de)			;2c1c
	inc b			;2c1d
	inc b			;2c1e
	inc b			;2c1f
	dec de			;2c20
	dec b			;2c21
	dec b			;2c22
	dec b			;2c23
	dec b			;2c24
	jr l2c46h		;2c25
	rlca			;2c27
	rlca			;2c28
	rlca			;2c29
	rlca			;2c2a
	rlca			;2c2b
	rlca			;2c2c
	rlca			;2c2d
	rlca			;2c2e
	rlca			;2c2f
l2c30h:
	nop			;2c30
	rst 38h			;2c31
	rst 38h			;2c32
	rst 38h			;2c33
	dec b			;2c34
	dec b			;2c35
	inc e			;2c36
	inc b			;2c37
	dec e			;2c38
l2c39h:
	ld a,(bc)			;2c39
	ld a,(bc)			;2c3a
	ld a,(bc)			;2c3b
	ld a,(bc)			;2c3c
l2c3dh:
	ld a,(bc)			;2c3d
	ld a,(bc)			;2c3e
	ld b,006h		;2c3f
	ld e,003h		;2c41
	inc bc			;2c43
	rra			;2c44
	dec b			;2c45
l2c46h:
	inc e			;2c46
	inc b			;2c47
	inc b			;2c48
l2c49h:
	dec e			;2c49
	ld a,(bc)			;2c4a
	ld b,006h		;2c4b
	ld e,003h		;2c4d
	inc bc			;2c4f
l2c50h:
	rra			;2c50
	dec b			;2c51
	inc e			;2c52
	inc b			;2c53
	inc b			;2c54
	dec e			;2c55
	ld a,(bc)			;2c56
	ld b,006h		;2c57
	ld e,003h		;2c59
	inc bc			;2c5b
	rra			;2c5c
	dec b			;2c5d
	inc e			;2c5e
	inc b			;2c5f
	inc b			;2c60
	dec e			;2c61
	ld a,(bc)			;2c62
	ld b,01eh		;2c63
	inc bc			;2c65
	rra			;2c66
	dec b			;2c67
	inc e			;2c68
	inc b			;2c69
	dec e			;2c6a
	ld b,01eh		;2c6b
	inc bc			;2c6d
	inc bc			;2c6e
	inc bc			;2c6f
	inc bc			;2c70
	dec d			;2c71
	ld d,017h		;2c72
	ld bc,l0501h		;2c74
	dec b			;2c77
	ld bc,l0501h		;2c78
	dec b			;2c7b
	ld bc,l0501h		;2c7c
	dec b			;2c7f
	ld bc,l0501h		;2c80
	dec b			;2c83
	ld (bc),a			;2c84
	ld (bc),a			;2c85
	jr l2c8fh		;2c86
	rlca			;2c88
	rlca			;2c89
	nop			;2c8a
	rst 38h			;2c8b
	rst 38h			;2c8c
	rst 38h			;2c8d
	rst 38h			;2c8e
l2c8fh:
	rst 38h			;2c8f
	inc e			;2c90
	inc b			;2c91
	inc b			;2c92
	inc b			;2c93
	inc b			;2c94
	inc b			;2c95
	inc b			;2c96
	inc b			;2c97
	inc b			;2c98
	inc b			;2c99
	inc b			;2c9a
	inc b			;2c9b
	inc b			;2c9c
	inc b			;2c9d
	inc b			;2c9e
	dec e			;2c9f
	ld b,006h		;2ca0
	ld b,006h		;2ca2
l2ca4h:
	ld b,006h		;2ca4
	ld b,01eh		;2ca6
	inc bc			;2ca8
	inc bc			;2ca9
	inc bc			;2caa
	inc bc			;2cab
	inc bc			;2cac
	inc bc			;2cad
	rra			;2cae
	dec b			;2caf
	dec b			;2cb0
	dec b			;2cb1
	dec b			;2cb2
	inc e			;2cb3
	inc b			;2cb4
	inc b			;2cb5
	dec e			;2cb6
	ld b,009h		;2cb7
	add hl,bc			;2cb9
	add hl,bc			;2cba
	ld e,003h		;2cbb
	rlca			;2cbd
	rlca			;2cbe
	ex af,af'			;2cbf
	ex af,af'			;2cc0
	rlca			;2cc1
	rlca			;2cc2
	ex af,af'			;2cc3
	rlca			;2cc4
	nop			;2cc5
	rst 38h			;2cc6
	rst 38h			;2cc7
	dec b			;2cc8
	dec b			;2cc9
	dec b			;2cca
	dec b			;2ccb
	inc e			;2ccc
	inc b			;2ccd
	inc b			;2cce
	inc b			;2ccf
	inc b			;2cd0
	inc b			;2cd1
	inc b			;2cd2
	inc b			;2cd3
	inc b			;2cd4
	inc b			;2cd5
	inc b			;2cd6
	inc b			;2cd7
	inc b			;2cd8
	inc b			;2cd9
	inc b			;2cda
	dec e			;2cdb
	add hl,bc			;2cdc
	add hl,bc			;2cdd
	add hl,bc			;2cde
	add hl,bc			;2cdf
	ld a,(bc)			;2ce0
	ld a,(bc)			;2ce1
	ld a,(bc)			;2ce2
	add hl,bc			;2ce3
	ld a,(bc)			;2ce4
	ld a,(bc)			;2ce5
	ld b,01eh		;2ce6
	inc bc			;2ce8
	inc bc			;2ce9
	inc bc			;2cea
	rra			;2ceb
	dec b			;2cec
	dec b			;2ced
	jr l2cf3h		;2cee
	add hl,de			;2cf0
	ld b,006h		;2cf1
l2cf3h:
	ld e,003h		;2cf3
	inc bc			;2cf5
	rra			;2cf6
	dec b			;2cf7
	dec b			;2cf8
	dec b			;2cf9
	dec b			;2cfa
	dec b			;2cfb
	dec b			;2cfc
	dec b			;2cfd
	nop			;2cfe
	rst 38h			;2cff
	dec bc			;2d00
	inc c			;2d01
	dec c			;2d02
	ld c,00bh		;2d03
	inc c			;2d05
	ld b,01eh		;2d06
	inc bc			;2d08
	inc bc			;2d09
	inc bc			;2d0a
	inc bc			;2d0b
	inc bc			;2d0c
	inc bc			;2d0d
	inc bc			;2d0e
	inc bc			;2d0f
	inc bc			;2d10
	inc bc			;2d11
	inc bc			;2d12
	inc bc			;2d13
	inc bc			;2d14
	inc bc			;2d15
	rra			;2d16
	dec b			;2d17
	dec b			;2d18
	inc e			;2d19
	inc b			;2d1a
	inc b			;2d1b
	inc b			;2d1c
	inc b			;2d1d
	inc b			;2d1e
	inc b			;2d1f
	inc b			;2d20
	inc b			;2d21
	inc b			;2d22
	inc b			;2d23
	dec e			;2d24
	ld b,006h		;2d25
	ld e,003h		;2d27
	inc bc			;2d29
	inc bc			;2d2a
	inc bc			;2d2b
	inc bc			;2d2c
	inc bc			;2d2d
	rra			;2d2e
	dec b			;2d2f
	dec b			;2d30
	dec b			;2d31
	dec b			;2d32
	dec b			;2d33
	inc e			;2d34
	inc b			;2d35
	inc b			;2d36
	inc b			;2d37
	inc b			;2d38
	inc b			;2d39
	inc b			;2d3a
	inc b			;2d3b
	inc b			;2d3c
	inc b			;2d3d
	inc b			;2d3e
	dec de			;2d3f
	nop			;2d40
	rst 38h			;2d41
	rst 38h			;2d42
	rst 38h			;2d43
	dec b			;2d44
	dec b			;2d45
	dec b			;2d46
	jr l2d4ch		;2d47
	inc bc			;2d49
	inc bc			;2d4a
	inc bc			;2d4b
l2d4ch:
	inc bc			;2d4c
	inc bc			;2d4d
	inc bc			;2d4e
	inc bc			;2d4f
	inc bc			;2d50
	add hl,de			;2d51
	ld b,006h		;2d52
	ld a,(de)			;2d54
	inc b			;2d55
	inc b			;2d56
	dec de			;2d57
	dec b			;2d58
	dec b			;2d59
	jr l2d5fh		;2d5a
	inc bc			;2d5c
	inc bc			;2d5d
	inc bc			;2d5e
l2d5fh:
	inc bc			;2d5f
	inc bc			;2d60
	inc bc			;2d61
	add hl,de			;2d62
	ld b,006h		;2d63
	ld b,006h		;2d65
	ld b,006h		;2d67
	ld b,006h		;2d69
	ld b,006h		;2d6b
	ld a,(de)			;2d6d
	inc b			;2d6e
	inc b			;2d6f
	dec de			;2d70
	dec b			;2d71
	dec b			;2d72
	inc e			;2d73
	inc b			;2d74
	inc b			;2d75
	dec e			;2d76
	ld b,006h		;2d77
	ld a,(de)			;2d79
	inc b			;2d7a
	inc b			;2d7b
	dec de			;2d7c
	dec b			;2d7d
	dec b			;2d7e
	dec b			;2d7f
	dec b			;2d80
	dec b			;2d81
	dec b			;2d82
	dec b			;2d83
	nop			;2d84
	rst 38h			;2d85
	rst 38h			;2d86
	rst 38h			;2d87
	inc e			;2d88
	inc b			;2d89
	inc b			;2d8a
	dec e			;2d8b
	ld b,006h		;2d8c
	add hl,bc			;2d8e
	ld a,(bc)			;2d8f
	ld a,(bc)			;2d90
	add hl,bc			;2d91
	add hl,bc			;2d92
	add hl,bc			;2d93
	ld d,017h		;2d94
	inc d			;2d96
	inc bc			;2d97
	inc bc			;2d98
	inc bc			;2d99
	rra			;2d9a
	dec b			;2d9b
	dec b			;2d9c
	inc e			;2d9d
	inc b			;2d9e
	inc b			;2d9f
	dec e			;2da0
	ld b,006h		;2da1
	ld e,003h		;2da3
	inc bc			;2da5
	inc bc			;2da6
	inc bc			;2da7
	rlca			;2da8
	rlca			;2da9
	ex af,af'			;2daa
	ex af,af'			;2dab
	rlca			;2dac
	rlca			;2dad
	dec b			;2dae
	dec b			;2daf
	inc e			;2db0
	inc b			;2db1
	inc b			;2db2
	inc b			;2db3
	inc b			;2db4
	inc b			;2db5
	inc b			;2db6
	inc b			;2db7
	dec e			;2db8
	ld a,(de)			;2db9
	inc b			;2dba
	dec de			;2dbb
	nop			;2dbc
	rst 38h			;2dbd
	rst 38h			;2dbe
	rst 38h			;2dbf
	inc d			;2dc0
	inc bc			;2dc1
	inc bc			;2dc2
	add hl,de			;2dc3
	ld b,00ah		;2dc4
	ld a,(bc)			;2dc6
	add hl,bc			;2dc7
	add hl,bc			;2dc8
	add hl,bc			;2dc9
	ld a,(bc)			;2dca
	ld (de),a			;2dcb
	inc de			;2dcc
	djnz $+19		;2dcd
	ld (de),a			;2dcf
	inc de			;2dd0
	djnz l2de4h		;2dd1
	ld (de),a			;2dd3
	inc de			;2dd4
	djnz l2ddbh		;2dd5
	inc b			;2dd7
	inc b			;2dd8
	inc b			;2dd9
	dec de			;2dda
l2ddbh:
	dec b			;2ddb
	jr l2de1h		;2ddc
	add hl,de			;2dde
	ld b,01ah		;2ddf
l2de1h:
	inc b			;2de1
	dec de			;2de2
	dec b			;2de3
l2de4h:
	jr l2dedh		;2de4
	rlca			;2de6
	rlca			;2de7
	ex af,af'			;2de8
	ex af,af'			;2de9
	rlca			;2dea
	rlca			;2deb
	rlca			;2dec
l2dedh:
	inc bc			;2ded
	inc bc			;2dee
	add hl,de			;2def
	dec c			;2df0
	ld c,000h		;2df1
	rst 38h			;2df3
	rst 38h			;2df4
	rst 38h			;2df5
	rst 38h			;2df6
	rst 38h			;2df7
	rst 38h			;2df8
	rst 38h			;2df9
	rst 38h			;2dfa
	rst 38h			;2dfb
	rst 38h			;2dfc
	rst 38h			;2dfd
	rst 38h			;2dfe
	rst 38h			;2dff
	dec bc			;2e00
	inc c			;2e01
	dec c			;2e02
	ld c,002h		;2e03
	ld (bc),a			;2e05
	ld (bc),a			;2e06
	ld (bc),a			;2e07
	dec bc			;2e08
	inc c			;2e09
	dec c			;2e0a
	ld c,001h		;2e0b
	ld bc,l1514h		;2e0d
	ld d,017h		;2e10
	ld bc,l0501h		;2e12
	dec b			;2e15
	dec b			;2e16
	dec b			;2e17
	ld (bc),a			;2e18
	ld (bc),a			;2e19
	ld (bc),a			;2e1a
	ld (bc),a			;2e1b
	nop			;2e1c
	rst 38h			;2e1d
	rst 38h			;2e1e
	rst 38h			;2e1f
	dec bc			;2e20
	inc c			;2e21
	dec c			;2e22
	ld c,00bh		;2e23
	inc c			;2e25
	dec c			;2e26
	ld c,002h		;2e27
	ld (bc),a			;2e29
	ld (bc),a			;2e2a
	ld (bc),a			;2e2b
l2e2ch:
	ld (bc),a			;2e2c
	ld (bc),a			;2e2d
	ld (bc),a			;2e2e
	ld (bc),a			;2e2f
	dec b			;2e30
	dec b			;2e31
	ld bc,l0505h		;2e32
	ld bc,l0505h		;2e35
	ld bc,l0505h		;2e38
	ld bc,0ff00h		;2e3b
	rst 38h			;2e3e
	rst 38h			;2e3f
	dec bc			;2e40
	inc c			;2e41
	dec c			;2e42
	ld c,001h		;2e43
	ld bc,l1801h		;2e45
	inc bc			;2e48
	add hl,de			;2e49
	ld b,006h		;2e4a
	ld a,(de)			;2e4c
	inc b			;2e4d
	dec de			;2e4e
	dec b			;2e4f
	jr l2e55h		;2e50
	add hl,de			;2e52
	ld b,006h		;2e53
l2e55h:
	ld a,(de)			;2e55
	inc b			;2e56
	inc b			;2e57
	inc b			;2e58
	inc b			;2e59
	inc b			;2e5a
	inc b			;2e5b
	inc b			;2e5c
	inc b			;2e5d
	inc b			;2e5e
	dec de			;2e5f
	dec b			;2e60
	dec b			;2e61
	dec b			;2e62
	ld bc,l0101h		;2e63
	ld bc,l0001h		;2e66
	rst 38h			;2e69
	rst 38h			;2e6a
	rst 38h			;2e6b
	dec bc			;2e6c
	inc c			;2e6d
	dec c			;2e6e
	ld c,001h		;2e6f
	ld bc,l0c0bh		;2e71
	dec c			;2e74
	ld c,001h		;2e75
	ld bc,l0505h		;2e77
	dec b			;2e7a
	dec b			;2e7b
	ld bc,l0b01h		;2e7c
	inc c			;2e7f
l2e80h:
	dec c			;2e80
	ld c,001h		;2e81
	ld bc,l0807h		;2e83
	ex af,af'			;2e86
	rlca			;2e87
	ex af,af'			;2e88
	ex af,af'			;2e89
	ex af,af'			;2e8a
	rlca			;2e8b
	nop			;2e8c
	rst 38h			;2e8d
	rst 38h			;2e8e
	rst 38h			;2e8f
	inc d			;2e90
	dec d			;2e91
	ld d,017h		;2e92
	inc d			;2e94
	dec d			;2e95
	ld d,017h		;2e96
	inc d			;2e98
	inc bc			;2e99
	inc bc			;2e9a
	inc bc			;2e9b
	inc bc			;2e9c
	inc bc			;2e9d
	inc bc			;2e9e
	inc bc			;2e9f
	inc bc			;2ea0
	inc bc			;2ea1
	inc bc			;2ea2
	inc bc			;2ea3
	inc bc			;2ea4
	add hl,de			;2ea5
	add hl,bc			;2ea6
	ld a,(bc)			;2ea7
	ld a,(bc)			;2ea8
	add hl,bc			;2ea9
	add hl,bc			;2eaa
	ld a,(bc)			;2eab
	ld a,(bc)			;2eac
	ld (de),a			;2ead
	inc de			;2eae
	ex af,af'			;2eaf
	ex af,af'			;2eb0
	rlca			;2eb1
	rlca			;2eb2
	ex af,af'			;2eb3
	ex af,af'			;2eb4
	ex af,af'			;2eb5
	ex af,af'			;2eb6
	inc b			;2eb7
	inc b			;2eb8
	inc b			;2eb9
	ld de,l1312h		;2eba
	djnz l2ed0h		;2ebd
	ld (de),a			;2ebf
	inc de			;2ec0
	nop			;2ec1
	rst 38h			;2ec2
	rst 38h			;2ec3
	djnz l2ed7h		;2ec4
	ld (de),a			;2ec6
	inc de			;2ec7
	djnz l2edbh		;2ec8
	ld (de),a			;2eca
	inc de			;2ecb
	djnz l2ed2h		;2ecc
	inc b			;2ece
	inc b			;2ecf
l2ed0h:
	inc b			;2ed0
	inc b			;2ed1
l2ed2h:
	inc b			;2ed2
	inc b			;2ed3
	inc b			;2ed4
	inc b			;2ed5
	ld a,(bc)			;2ed6
l2ed7h:
	ld a,(bc)			;2ed7
	ld a,(bc)			;2ed8
	add hl,bc			;2ed9
	ld a,(bc)			;2eda
l2edbh:
	add hl,bc			;2edb
	ld a,(bc)			;2edc
	add hl,bc			;2edd
	ld d,017h		;2ede
	inc d			;2ee0
	inc bc			;2ee1
	inc bc			;2ee2
	inc bc			;2ee3
	rlca			;2ee4
	rlca			;2ee5
	rlca			;2ee6
	rlca			;2ee7
	inc bc			;2ee8
	add hl,de			;2ee9
	ld b,01ah		;2eea
	inc b			;2eec
	dec de			;2eed
	dec b			;2eee
	jr l2ef8h		;2eef
	rlca			;2ef1
	rlca			;2ef2
	rlca			;2ef3
	nop			;2ef4
	rst 38h			;2ef5
	rst 38h			;2ef6
	rst 38h			;2ef7
l2ef8h:
	rst 38h			;2ef8
	rst 38h			;2ef9
	rst 38h			;2efa
	rst 38h			;2efb
	rst 38h			;2efc
	rst 38h			;2efd
	rst 38h			;2efe
	rst 38h			;2eff
	dec b			;2f00
	inc e			;2f01
	inc b			;2f02
	dec e			;2f03
	ld b,006h		;2f04
	ld b,006h		;2f06
	ld b,009h		;2f08
	add hl,bc			;2f0a
	add hl,bc			;2f0b
	ld a,(bc)			;2f0c
	ld a,(bc)			;2f0d
	ld a,(bc)			;2f0e
	add hl,bc			;2f0f
	add hl,bc			;2f10
	ld d,017h		;2f11
	inc d			;2f13
	rra			;2f14
	dec b			;2f15
	jr l2f1bh		;2f16
	add hl,de			;2f18
	ld b,01eh		;2f19
l2f1bh:
	inc bc			;2f1b
	rra			;2f1c
	dec b			;2f1d
	jr l2f23h		;2f1e
	add hl,de			;2f20
	ld b,01eh		;2f21
l2f23h:
	inc bc			;2f23
	rra			;2f24
	dec b			;2f25
	dec b			;2f26
	inc e			;2f27
	ex af,af'			;2f28
	ex af,af'			;2f29
	ex af,af'			;2f2a
	ex af,af'			;2f2b
	ex af,af'			;2f2c
	ex af,af'			;2f2d
	ex af,af'			;2f2e
	ex af,af'			;2f2f
	nop			;2f30
	rst 38h			;2f31
	rst 38h			;2f32
	rst 38h			;2f33
	dec b			;2f34
	jr l2f3ah		;2f35
	add hl,de			;2f37
	ld b,006h		;2f38
l2f3ah:
	ld b,006h		;2f3a
	ld a,(bc)			;2f3c
	ld a,(bc)			;2f3d
	add hl,bc			;2f3e
	add hl,bc			;2f3f
	ld a,(bc)			;2f40
	ld a,(bc)			;2f41
	add hl,bc			;2f42
	ld a,(bc)			;2f43
	ld a,(bc)			;2f44
	ld (de),a			;2f45
	inc de			;2f46
	djnz l2f64h		;2f47
	dec b			;2f49
	inc e			;2f4a
	inc b			;2f4b
	dec e			;2f4c
	ld e,01fh		;2f4d
	inc e			;2f4f
	inc b			;2f50
	dec e			;2f51
	ld b,01ah		;2f52
	inc b			;2f54
	inc b			;2f55
	dec de			;2f56
	dec b			;2f57
	jr l2f61h		;2f58
	rlca			;2f5a
	rlca			;2f5b
	rlca			;2f5c
	ex af,af'			;2f5d
	rlca			;2f5e
	rlca			;2f5f
	rlca			;2f60
l2f61h:
	rlca			;2f61
	nop			;2f62
	rst 38h			;2f63
l2f64h:
	dec bc			;2f64
	inc c			;2f65
	dec c			;2f66
	ld c,00bh		;2f67
	inc c			;2f69
	ld e,003h		;2f6a
	add hl,de			;2f6c
	ld b,01eh		;2f6d
	inc bc			;2f6f
	add hl,de			;2f70
	ld b,01eh		;2f71
	inc bc			;2f73
	add hl,de			;2f74
	ld b,01eh		;2f75
	rra			;2f77
	inc e			;2f78
	dec e			;2f79
	ld e,003h		;2f7a
	inc bc			;2f7c
	inc bc			;2f7d
	rra			;2f7e
	dec b			;2f7f
	jr l2f85h		;2f80
	add hl,de			;2f82
	ld b,01eh		;2f83
l2f85h:
	inc bc			;2f85
	rra			;2f86
	dec b			;2f87
	ex af,af'			;2f88
	ex af,af'			;2f89
	ex af,af'			;2f8a
	ex af,af'			;2f8b
	ex af,af'			;2f8c
	ex af,af'			;2f8d
	ex af,af'			;2f8e
	rlca			;2f8f
	rlca			;2f90
	ex af,af'			;2f91
	ex af,af'			;2f92
	ex af,af'			;2f93
	ex af,af'			;2f94
	ex af,af'			;2f95
	nop			;2f96
	rst 38h			;2f97
	rst 38h			;2f98
	rst 38h			;2f99
	rst 38h			;2f9a
	rst 38h			;2f9b
	rst 38h			;2f9c
	rst 38h			;2f9d
	rst 38h			;2f9e
	rst 38h			;2f9f
	dec b			;2fa0
	dec b			;2fa1
	jr l2fa7h		;2fa2
	inc bc			;2fa4
	inc bc			;2fa5
	inc bc			;2fa6
l2fa7h:
	inc bc			;2fa7
	inc bc			;2fa8
	inc bc			;2fa9
	inc bc			;2faa
	add hl,de			;2fab
	ld b,006h		;2fac
	ld b,006h		;2fae
	ld b,006h		;2fb0
	ld b,01ah		;2fb2
	inc b			;2fb4
	dec de			;2fb5
	dec b			;2fb6
	jr l2fbch		;2fb7
	inc bc			;2fb9
	inc bc			;2fba
	inc bc			;2fbb
l2fbch:
	add hl,de			;2fbc
	ld b,006h		;2fbd
	ld b,01ah		;2fbf
	inc b			;2fc1
	dec de			;2fc2
	dec b			;2fc3
	jr l2fc9h		;2fc4
	inc bc			;2fc6
	inc bc			;2fc7
	inc bc			;2fc8
l2fc9h:
	add hl,de			;2fc9
	ld b,006h		;2fca
	ld b,01ah		;2fcc
	inc b			;2fce
	dec de			;2fcf
	dec b			;2fd0
	jr l2fd6h		;2fd1
	inc bc			;2fd3
	inc bc			;2fd4
	inc bc			;2fd5
l2fd6h:
	add hl,de			;2fd6
	ld b,006h		;2fd7
	ld b,01ah		;2fd9
	inc b			;2fdb
	dec de			;2fdc
	dec b			;2fdd
	jr $+5		;2fde
	inc bc			;2fe0
	add hl,de			;2fe1
	ld b,006h		;2fe2
	ld a,(de)			;2fe4
	ld de,l1312h		;2fe5
	ld (bc),a			;2fe8
	ld (bc),a			;2fe9
	ld (bc),a			;2fea
	dec b			;2feb
	dec b			;2fec
	ld (bc),a			;2fed
	ld (bc),a			;2fee
	ld (bc),a			;2fef
	dec b			;2ff0
	dec b			;2ff1
	ld (bc),a			;2ff2
	ld (bc),a			;2ff3
	ld (bc),a			;2ff4
	dec b			;2ff5
	inc e			;2ff6
	ex af,af'			;2ff7
	ex af,af'			;2ff8
	rlca			;2ff9
	rlca			;2ffa
	ex af,af'			;2ffb
	ex af,af'			;2ffc
	ex af,af'			;2ffd
	nop			;2ffe
	rst 38h			;2fff
sub_3000h:
	ld hl,04393h		;3000
	ld a,(hl)			;3003
	inc (hl)			;3004
	and 007h		;3005
	ld hl,l3018h		;3007
	rlca			;300a
	add a,l			;300b
	ld l,a			;300c
	ld a,(hl)			;300d
	inc hl			;300e
	ld l,(hl)			;300f
	ld h,a			;3010
	jp (hl)			;3011
	ret			;3012
	rst 38h			;3013
	rst 38h			;3014
	rst 38h			;3015
	rst 38h			;3016
	rst 38h			;3017
l3018h:
	ld (l3064h),a		;3018
	jr z,l304dh		;301b
	cp d			;301d
	ld sp,l3124h		;301e
	ld e,d			;3021
	ld sp,032b4h		;3022
	inc l			;3025
	jr nc,$+20		;3026
	ld hl,04357h		;3028
	ld a,(hl)			;302b
	cp 003h		;302c
	ret nc			;302e
	ld l,050h		;302f
	ld a,(hl)			;3031
	cp 004h		;3032
	ret nc			;3034
	ld l,058h		;3035
	ld a,(hl)			;3037
	and a			;3038
	jp z,l305ch		;3039
	dec (hl)			;303c
	ret nz			;303d
	dec l			;303e
	inc (hl)			;303f
	ld l,050h		;3040
	ld (hl),004h		;3042
	ld l,053h		;3044
	ld (hl),010h		;3046
	inc l			;3048
	ld (hl),050h		;3049
	ld l,051h		;304b
l304dh:
	ld (hl),02eh		;304d
	inc l			;304f
	ld (hl),000h		;3050
	ld a,(043c2h)		;3052
	rrca			;3055
	ret c			;3056
	ld (hl),040h		;3057
	ret			;3059
	rst 38h			;305a
	rst 38h			;305b
l305ch:
	call sub_3074h		;305c
	ld hl,04357h		;305f
	ld a,(hl)			;3062
	rlca			;3063
l3064h:
	rlca			;3064
	nop			;3065
	nop			;3066
	add a,c			;3067
	add a,007h		;3068
	ld l,058h		;306a
	ld (hl),a			;306c
	ret			;306d
	rst 38h			;306e
	rst 38h			;306f
	rst 38h			;3070
	rst 38h			;3071
	rst 38h			;3072
	rst 38h			;3073
sub_3074h:
	ld hl,043b8h		;3074
	ld a,(hl)			;3077
	rrca			;3078
	nop			;3079
	and 007h		;307a
	ld b,a			;307c
	ld a,007h		;307d
	sub b			;307f
	ld c,a			;3080
	ld a,(hl)			;3081
	cp 080h		;3082
	jp c,l3089h		;3084
	ld a,070h		;3087
l3089h:
	rrca			;3089
	rrca			;308a
	rrca			;308b
	rrca			;308c
	and 007h		;308d
	ld b,a			;308f
	ld a,007h		;3090
	sub b			;3092
	add a,c			;3093
	ld c,a			;3094
	ld a,(043bah)		;3095
	sub 005h		;3098
	jp nc,l309fh		;309a
	ld a,010h		;309d
l309fh:
	add a,c			;309f
	ld c,a			;30a0
	call sub_30aah		;30a1
	and 007h		;30a4
	add a,c			;30a6
	ld c,a			;30a7
	ret			;30a8
	rst 38h			;30a9
sub_30aah:
	ld hl,0439bh		;30aa
	ld a,(hl)			;30ad
	rlca			;30ae
	rlca			;30af
	rlca			;30b0
	and 007h		;30b1
	ld l,0c2h		;30b3
	add a,(hl)			;30b5
	and 00fh		;30b6
	ret			;30b8
	ret nz			;30b9
	ld hl,04358h		;30ba
	call 030dah		;30bd
	call 030dah		;30c0
	call 030dah		;30c3
	ld l,050h		;30c6
	ld a,(hl)			;30c8
	and a			;30c9
	ret nz			;30ca
	ld l,055h		;30cb
	ld a,(hl)			;30cd
	and a			;30ce
	jp z,l30e4h		;30cf
	dec (hl)			;30d2
	ret nz			;30d3
	ld l,050h		;30d4
	ld (hl),001h		;30d6
	ret			;30d8
	cp 02ch		;30d9
	ld a,(hl)			;30db
	and a			;30dc
	ret z			;30dd
	dec (hl)			;30de
	ret			;30df
	ld a,(hl)			;30e0
	cp 001h		;30e1
	ret nc			;30e3
l30e4h:
	call sub_3074h		;30e4
	ld hl,0439ah		;30e7
	ld a,(hl)			;30ea
	cp 010h		;30eb
sub_30edh:
	jp c,l30f2h		;30ed
	ld a,00fh		;30f0
l30f2h:
	ld b,a			;30f2
	ld a,00fh		;30f3
	sub b			;30f5
	add a,c			;30f6
	ld c,a			;30f7
	ld b,001h		;30f8
	ld l,058h		;30fa
	call 03112h		;30fc
	call 03112h		;30ff
	call 03112h		;3102
	ld a,c			;3105
	rrca			;3106
	rrca			;3107
	and 03fh		;3108
	add a,001h		;310a
	ld l,055h		;310c
	ld (hl),a			;310e
	ret			;310f
	ld hl,l2c50h		;3110
	ld a,(hl)			;3113
	and a			;3114
	ret nz			;3115
	ld a,c			;3116
	rrca			;3117
	and 07fh		;3118
	ld c,a			;311a
	ld a,b			;311b
	and a			;311c
	ret z			;311d
	dec b			;311e
	ld (hl),00ch		;311f
	ret			;3121
	add a,(hl)			;3122
	ld b,a			;3123
l3124h:
	ld hl,04350h		;3124
	ld a,(hl)			;3127
	cp 001h		;3128
	ret nz			;312a
	ld (hl),002h		;312b
	ld l,0b8h		;312d
	ld a,(hl)			;312f
	rrca			;3130
	rrca			;3131
	and 00fh		;3132
	add a,005h		;3134
	cp 011h		;3136
	jp c,l313dh		;3138
	ld a,005h		;313b
l313dh:
	ld l,057h		;313d
	sub (hl)			;313f
	ld b,a			;3140
	call sub_30aah		;3141
	inc a			;3144
	cp b			;3145
	jp c,l314bh		;3146
	ld a,001h		;3149
l314bh:
	ld l,053h		;314b
	ld (hl),a			;314d
	ret			;314e
	ld a,(bc)			;314f
	inc c			;3150
	dec bc			;3151
	inc c			;3152
	dec bc			;3153
	ld c,00fh		;3154
	ld c,00fh		;3156
	rst 38h			;3158
	rst 38h			;3159
	ld hl,04350h		;315a
	ld a,(hl)			;315d
	cp 002h		;315e
	ret nz			;3160
	call sub_30aah		;3161
	nop			;3164
	ld b,a			;3165
	rlca			;3166
	add a,050h		;3167
	ld l,a			;3169
	ld h,04bh		;316a
	ld a,b			;316c
	rlca			;316d
	rlca			;316e
	add a,070h		;316f
	ld e,a			;3171
	ld d,04bh		;3172
	ld c,010h		;3174
	ld a,c			;3176
	sub b			;3177
	ld b,a			;3178
l3179h:
	call sub_3192h		;3179
	inc de			;317c
	inc de			;317d
	inc de			;317e
	inc de			;317f
	inc hl			;3180
	inc hl			;3181
	dec b			;3182
	jp nz,l318ah		;3183
	ld e,070h		;3186
	ld l,050h		;3188
l318ah:
	dec c			;318a
	jp nz,l3179h		;318b
	ret			;318e
	rst 38h			;318f
	rst 38h			;3190
	rst 38h			;3191
sub_3192h:
	ld a,(de)			;3192
	and 008h		;3193
	ret z			;3195
	ld a,(04394h)		;3196
	cp (hl)			;3199
	ret nz			;319a
	ld a,(04356h)		;319b
	inc l			;319e
	ld b,(hl)			;319f
	dec l			;31a0
	cp b			;31a1
	ret nz			;31a2
	ld a,l			;31a3
	ld (04354h),a		;31a4
	ld a,003h		;31a7
	ld (04350h),a		;31a9
	pop hl			;31ac
	ret			;31ad
	rst 38h			;31ae
	rst 38h			;31af
	rst 38h			;31b0
	rst 38h			;31b1
	rst 38h			;31b2
	rst 38h			;31b3
	ld a,(04350h)		;31b4
	cp 003h		;31b7
	ret nz			;31b9
	ld a,(04354h)		;31ba
	sub 050h		;31bd
	rlca			;31bf
	add a,072h		;31c0
	ld l,a			;31c2
	ld h,04bh		;31c3
	ld b,(hl)			;31c5
	inc l			;31c6
	ld d,(hl)			;31c7
	ld a,(043c2h)		;31c8
	ld c,004h		;31cb
	cp b			;31cd
	jp nc,l31d6h		;31ce
	ld c,a			;31d1
	ld a,b			;31d2
	ld b,c			;31d3
	ld c,000h		;31d4
l31d6h:
	sub b			;31d6
	rlca			;31d7
	rlca			;31d8
	rlca			;31d9
	and 007h		;31da
	add a,000h		;31dc
	ld l,a			;31de
	ld h,033h		;31df
	ld a,(hl)			;31e1
	add a,c			;31e2
	rlca			;31e3
	rlca			;31e4
	ld c,a			;31e5
	nop			;31e6
	nop			;31e7
	nop			;31e8
	ld a,(04357h)		;31e9
	ld b,a			;31ec
	call sub_3210h		;31ed
	ld a,c			;31f0
	add a,b			;31f1
	add a,010h		;31f2
	ld l,a			;31f4
	ld h,033h		;31f5
	ld c,(hl)			;31f7
	call sub_30aah		;31f8
	and 006h		;31fb
	add a,c			;31fd
	ld l,a			;31fe
	ld h,033h		;31ff
	ld a,(hl)			;3201
	inc l			;3202
	ld b,(hl)			;3203
	ld hl,04350h		;3204
	ld (hl),005h		;3207
	inc l			;3209
	ld (hl),a			;320a
	inc l			;320b
	ld (hl),b			;320c
	ret			;320d
	add a,c			;320e
	ld l,a			;320f
sub_3210h:
	ld a,(04353h)		;3210
	cp 001h		;3213
	ret nz			;3215
	ld a,d			;3216
	ld b,000h		;3217
	cp 058h		;3219
	ret c			;321b
	ld b,001h		;321c
	cp 078h		;321e
	ret c			;3220
	ld b,002h		;3221
	cp 098h		;3223
	ret c			;3225
	ld b,003h		;3226
	ret			;3228
	ret nz			;3229
	ld hl,l3a50h		;322a
	ld d,b			;322d
	ld b,e			;322e
	cp 004h		;322f
	ret nz			;3231
	ld hl,04b50h		;3232
	ld de,04b70h		;3235
	ld a,(04356h)		;3238
	ld c,a			;323b
	ld a,(04394h)		;323c
	ld b,a			;323f
l3240h:
	ld a,(de)			;3240
l3241h:
	and 008h		;3241
	jp z,l324eh		;3243
	ld a,(hl)			;3246
	cp b			;3247
	ret nz			;3248
	inc l			;3249
	ld a,(hl)			;324a
	dec l			;324b
	cp c			;324c
	ret nz			;324d
l324eh:
	inc l			;324e
	inc l			;324f
	ld a,e			;3250
	add a,004h		;3251
	ld e,a			;3253
	cp 0b0h		;3254
	jp nz,l3240h		;3256
	ld a,006h		;3259
	ld (04350h),a		;325b
	ret			;325e
	inc a			;325f
	and 00fh		;3260
	ld (hl),a			;3262
	ld l,021h		;3263
	sub l			;3265
	ld b,e			;3266
	ld a,(hl)			;3267
	ld (04356h),a		;3268
	inc a			;326b
	and 00fh		;326c
	ld (hl),a			;326e
	ld l,050h		;326f
	ld a,(hl)			;3271
	cp 005h		;3272
	ret c			;3274
	ld (hl),000h		;3275
	ld l,053h		;3277
	ld c,(hl)			;3279
	inc l			;327a
	ld l,(hl)			;327b
	ld h,04bh		;327c
	ld a,(04356h)		;327e
	ld d,a			;3281
	ld a,(04394h)		;3282
	ld e,a			;3285
	ld a,l			;3286
	sub 050h		;3287
	rrca			;3289
	ld b,a			;328a
	ld a,010h		;328b
	sub b			;328d
	ld b,a			;328e
l328fh:
	ld a,(hl)			;328f
	inc l			;3290
	cp e			;3291
	jp nz,l32a4h		;3292
	ld a,(hl)			;3295
	cp d			;3296
	jp nz,l32a4h		;3297
	dec l			;329a
	ld a,(04351h)		;329b
	ld (hl),a			;329e
	inc l			;329f
	ld a,(04352h)		;32a0
	ld (hl),a			;32a3
l32a4h:
	inc l			;32a4
	dec b			;32a5
	jp nz,l32abh		;32a6
	ld l,050h		;32a9
l32abh:
	dec c			;32ab
	jp nz,l328fh		;32ac
	ret			;32af
l32b0h:
	ld hl,04350h		;32b0
	ld b,030h		;32b3
	call sub_05d8h		;32b5
	ld l,09ah		;32b8
	ld b,004h		;32ba
	call sub_05d8h		;32bc
	ld a,(043bbh)		;32bf
	and a			;32c2
	ret z			;32c3
	rlca			;32c4
	rlca			;32c5
	rlca			;32c6
	ld c,a			;32c7
	ld hl,04b70h		;32c8
	ld b,040h		;32cb
	call sub_05d8h		;32cd
	ld d,04bh		;32d0
	ld h,03fh		;32d2
	ld a,040h		;32d4
	sub c			;32d6
	add a,070h		;32d7
	ld e,a			;32d9
	add a,010h		;32da
	ld l,a			;32dc
	ld b,c			;32dd
	ld a,(043b8h)		;32de
	rrca			;32e1
	rrca			;32e2
	jp nc,sub_05e0h		;32e3
	ld a,l			;32e6
	add a,040h		;32e7
	ld l,a			;32e9
	jp sub_05e0h		;32ea
	call sub_05e0h		;32ed
	jp sub_03a0h		;32f0
	rst 38h			;32f3
	rst 38h			;32f4
	rst 38h			;32f5
	rst 38h			;32f6
	rst 38h			;32f7
	rst 38h			;32f8
	rst 38h			;32f9
	rst 38h			;32fa
	rst 38h			;32fb
	rst 38h			;32fc
	rst 38h			;32fd
	rst 38h			;32fe
	rst 38h			;32ff
	nop			;3300
	ld bc,l0202h		;3301
	inc bc			;3304
	inc bc			;3305
	inc bc			;3306
	inc bc			;3307
	rst 38h			;3308
	rst 38h			;3309
	rst 38h			;330a
	rst 38h			;330b
	rst 38h			;330c
	rst 38h			;330d
	rst 38h			;330e
	rst 38h			;330f
	adc a,b			;3310
	sub b			;3311
	sbc a,b			;3312
	and b			;3313
	ld l,b			;3314
	ld (hl),b			;3315
	ld a,b			;3316
	add a,b			;3317
	ld c,b			;3318
	ld d,b			;3319
	ld e,b			;331a
	ld h,b			;331b
	ld c,b			;331c
	jr nc,l3357h		;331d
	ld b,b			;331f
	adc a,b			;3320
	sub b			;3321
	sbc a,b			;3322
l3323h:
	and b			;3323
	xor b			;3324
	or b			;3325
	cp b			;3326
	ret nz			;3327
	ret z			;3328
	ret nc			;3329
	ret c			;332a
	ret po			;332b
	ret z			;332c
	ret pe			;332d
	ret p			;332e
	ret m			;332f
	ld de,l2c30h		;3330
	nop			;3333
	cpl			;3334
	and b			;3335
	inc l			;3336
	nop			;3337
	ld l,0c4h		;3338
	cpl			;333a
	and b			;333b
	cpl			;333c
	inc (hl)			;333d
	cpl			;333e
	and b			;333f
	inc l			;3340
	ret z			;3341
	ld l,0c4h		;3342
	ld l,020h		;3344
	ld l,0c4h		;3346
	ld de,l1330h		;3348
	sbc a,h			;334b
	inc de			;334c
	ret nc			;334d
l334eh:
	inc l			;334e
	nop			;334f
	ld de,l1330h		;3350
	jr z,l3381h		;3353
	nop			;3355
	cpl			;3356
l3357h:
	inc (hl)			;3357
	ld de,l2ca4h		;3358
	sub b			;335b
	cpl			;335c
	inc (hl)			;335d
	cpl			;335e
	and b			;335f
	inc l			;3360
	sub b			;3361
	inc l			;3362
	ret z			;3363
	ld l,020h		;3364
	ld l,0c4h		;3366
	ld de,l1360h		;3368
	ld d,h			;336b
	inc de			;336c
	sbc a,h			;336d
	inc de			;336e
	ret nc			;336f
	djnz l3392h		;3370
	djnz l33d8h		;3372
	ld de,013a4h		;3374
	jr z,$+18		;3377
	jr nz,l338ch		;3379
	and h			;337b
	ld (de),a			;337c
	nop			;337d
	cpl			;337e
	inc (hl)			;337f
	inc l			;3380
l3381h:
	sub b			;3381
	inc l			;3382
	ret z			;3383
	dec l			;3384
	ret nz			;3385
	ld l,020h		;3386
	ld de,l1260h		;3388
	ld b,h			;338b
l338ch:
	ld (de),a			;338c
	adc a,b			;338d
	inc de			;338e
	ld d,h			;338f
l3390h:
	djnz l33b2h		;3390
l3392h:
	djnz l33f8h		;3392
	ld (de),a			;3394
	nop			;3395
	ld (de),a			;3396
	ld b,h			;3397
	djnz l33bah		;3398
	ld (de),a			;339a
	nop			;339b
	djnz l33beh		;339c
	ld (de),a			;339e
	nop			;339f
	djnz $-86		;33a0
	dec l			;33a2
	adc a,b			;33a3
	djnz l334eh		;33a4
	dec l			;33a6
	ret nz			;33a7
	ld de,l12cfh+1		;33a8
	jp z,l0012h+1		;33ab
l33aeh:
	inc de			;33ae
	ld d,h			;33af
	djnz $+34		;33b0
l33b2h:
	djnz l3418h		;33b2
	djnz $-42		;33b4
	inc de			;33b6
	nop			;33b7
	djnz l33dah		;33b8
l33bah:
	djnz l3390h		;33ba
	ld (de),a			;33bc
	nop			;33bd
l33beh:
	cpl			;33be
	nop			;33bf
	dec l			;33c0
	nop			;33c1
	dec l			;33c2
	ld b,h			;33c3
	dec l			;33c4
	adc a,b			;33c5
	ld l,06ch		;33c6
	ld de,l1100h		;33c8
	ret nc			;33cb
	ld (de),a			;33cc
	jp z,0642fh		;33cd
	ld de,l1300h		;33d0
	nop			;33d3
	cpl			;33d4
	ld h,h			;33d5
	cpl			;33d6
	nop			;33d7
l33d8h:
	djnz l33aeh		;33d8
l33dah:
	dec l			;33da
	nop			;33db
	cpl			;33dc
	nop			;33dd
	inc l			;33de
	inc (hl)			;33df
	dec l			;33e0
	nop			;33e1
	dec l			;33e2
	ld b,h			;33e3
	ld l,06ch		;33e4
	ld l,090h		;33e6
	ld de,l2c00h		;33e8
	inc (hl)			;33eb
	cpl			;33ec
	ld h,h			;33ed
	cpl			;33ee
	ld h,h			;33ef
	ld l,090h		;33f0
	cpl			;33f2
	nop			;33f3
	inc l			;33f4
	inc (hl)			;33f5
	inc l			;33f6
	inc (hl)			;33f7
l33f8h:
	dec l			;33f8
	ld b,h			;33f9
	ld l,06ch		;33fa
	ld l,090h		;33fc
	ld l,090h		;33fe
	call sub_0876h		;3400
	call sub_3800h		;3403
	call sub_2600h		;3406
	call sub_3800h		;3409
	call sub_3980h		;340c
	ld a,(043bbh)		;340f
	and a			;3412
	jp z,l3462h		;3413
	cp 004h		;3416
l3418h:
	jp nc,l3438h		;3418
	call sub_3474h		;341b
	call sub_3486h		;341e
	call sub_3560h		;3421
	call sub_3498h		;3424
	call sub_34aah		;3427
	ld a,(0439bh)		;342a
	rrca			;342d
	jp c,l0fc0h		;342e
	call sub_3930h		;3431
	jp sub_0c40h		;3434
	rst 38h			;3437
l3438h:
	ld a,(0439bh)		;3438
	rrca			;343b
	jp c,l3452h		;343c
	call sub_3474h		;343f
	call sub_3560h		;3442
	call sub_3498h		;3445
	call sub_3930h		;3448
	jp sub_0c40h		;344b
	rst 38h			;344e
	rst 38h			;344f
	rst 38h			;3450
	rst 38h			;3451
l3452h:
	call sub_3486h		;3452
	call sub_3560h		;3455
	call sub_34aah		;3458
	jp l0fc0h		;345b
	rst 38h			;345e
	rst 38h			;345f
	rst 38h			;3460
	rst 38h			;3461
l3462h:
	ld a,(0439bh)		;3462
	rrca			;3465
	ret c			;3466
	call sub_0c40h		;3467
	call l0fc0h		;346a
	jp l2204h		;346d
	rst 38h			;3470
	rst 38h			;3471
	rst 38h			;3472
	rst 38h			;3473
sub_3474h:
	ld hl,04b70h		;3474
l3477h:
	push hl			;3477
	call sub_34c0h		;3478
	pop hl			;347b
	ld a,l			;347c
	add a,008h		;347d
	ld l,a			;347f
	cp 090h		;3480
	jp nz,l3477h		;3482
	ret			;3485
sub_3486h:
	ld hl,04b90h		;3486
l3489h:
	push hl			;3489
	call sub_34c0h		;348a
	pop hl			;348d
	ld a,l			;348e
	add a,008h		;348f
	ld l,a			;3491
	cp 0b0h		;3492
	jp nz,l3489h		;3494
	ret			;3497
sub_3498h:
	ld hl,04b70h		;3498
l349bh:
	push hl			;349b
	call sub_35b0h		;349c
	pop hl			;349f
	ld a,l			;34a0
	add a,008h		;34a1
	ld l,a			;34a3
	cp 090h		;34a4
	jp nz,l349bh		;34a6
	ret			;34a9
sub_34aah:
	ld hl,04b90h		;34aa
l34adh:
	push hl			;34ad
	call sub_35b0h		;34ae
	pop hl			;34b1
	ld a,l			;34b2
	add a,008h		;34b3
	ld l,a			;34b5
	cp 0b0h		;34b6
	jp nz,l34adh		;34b8
	ret			;34bb
	rst 38h			;34bc
	rst 38h			;34bd
	rst 38h			;34be
	rst 38h			;34bf
sub_34c0h:
	ld a,(hl)			;34c0
	and a			;34c1
	ret z			;34c2
	ld b,a			;34c3
	add a,0c0h		;34c4
	ld e,a			;34c6
	ld d,03eh		;34c7
	ld a,(de)			;34c9
	ld c,a			;34ca
	inc l			;34cb
	ld d,(hl)			;34cc
	inc l			;34cd
	ld e,(hl)			;34ce
	inc l			;34cf
	ld a,b			;34d0
	rlca			;34d1
	rlca			;34d2
	rlca			;34d3
	add a,(hl)			;34d4
	and 07eh		;34d5
	ld l,a			;34d7
	ld h,03eh		;34d8
	ld a,(hl)			;34da
	inc l			;34db
	ld l,(hl)			;34dc
	ld h,a			;34dd
sub_34deh:
	ld a,d			;34de
	cp 04bh		;34df
	jp nz,l350ch		;34e1
	ld a,e			;34e4
	cp 050h		;34e5
	jp c,l350ch		;34e7
	ld b,008h		;34ea
	inc l			;34ec
	inc l			;34ed
	sub 020h		;34ee
	ld e,a			;34f0
	cp 050h		;34f1
	jp c,l3509h		;34f3
	ld b,010h		;34f6
	inc l			;34f8
	inc l			;34f9
	sub 020h		;34fa
	ld e,a			;34fc
	cp 050h		;34fd
	jp c,l3509h		;34ff
	ld b,018h		;3502
	inc l			;3504
	inc l			;3505
	sub 020h		;3506
	ld e,a			;3508
l3509h:
	ld a,c			;3509
	add a,b			;350a
	ld c,a			;350b
l350ch:
	ld b,035h		;350c
	push bc			;350e
	ld bc,0ffdfh		;350f
	ex de,hl			;3512
	ld (hl),000h		;3513
	inc hl			;3515
	ld (hl),000h		;3516
	add hl,bc			;3518
	ret			;3519
	rst 38h			;351a
	rst 38h			;351b
	rst 38h			;351c
	rst 38h			;351d
	rst 38h			;351e
	rst 38h			;351f
	ld a,(de)			;3520
	ld (hl),a			;3521
	inc de			;3522
	inc hl			;3523
	ld a,(de)			;3524
	ld (hl),a			;3525
	inc de			;3526
	add hl,bc			;3527
sub_3528h:
	ld a,(de)			;3528
	ld (hl),a			;3529
	inc de			;352a
	inc hl			;352b
	ld a,(de)			;352c
	ld (hl),a			;352d
	inc de			;352e
	add hl,bc			;352f
	ld a,(de)			;3530
	ld (hl),a			;3531
	inc de			;3532
	inc hl			;3533
	ld a,(de)			;3534
	ld (hl),a			;3535
	inc de			;3536
	add hl,bc			;3537
sub_3538h:
	ld a,(de)			;3538
	ld (hl),a			;3539
	inc de			;353a
	inc hl			;353b
	ld a,(de)			;353c
	ld (hl),a			;353d
	inc de			;353e
	add hl,bc			;353f
l3540h:
	ld a,(de)			;3540
	ld (hl),a			;3541
	inc de			;3542
	inc hl			;3543
	ld a,(de)			;3544
	ld (hl),a			;3545
	inc de			;3546
	add hl,bc			;3547
sub_3548h:
	ld a,(de)			;3548
	ld (hl),a			;3549
	inc de			;354a
	inc hl			;354b
	ld a,(de)			;354c
	ld (hl),a			;354d
	inc de			;354e
	add hl,bc			;354f
	ld a,(de)			;3550
	ld (hl),a			;3551
	inc de			;3552
	inc hl			;3553
	ld a,(de)			;3554
	ld (hl),a			;3555
	inc de			;3556
	add hl,bc			;3557
	ld (hl),000h		;3558
	inc hl			;355a
	ld (hl),000h		;355b
	ret			;355d
	rst 38h			;355e
	rst 38h			;355f
sub_3560h:
	call sub_30aah		;3560
	ld b,a			;3563
	rlca			;3564
	rlca			;3565
	ld c,a			;3566
	rlca			;3567
	rlca			;3568
	or b			;3569
	ld (0436fh),a		;356a
	ld a,(043b8h)		;356d
	cp 040h		;3570
	jp c,l3577h		;3572
	ld a,030h		;3575
l3577h:
	and 030h		;3577
	rrca			;3579
	ld b,a			;357a
	ld a,(043bbh)		;357b
	dec a			;357e
	cp 004h		;357f
	jp c,l3586h		;3581
	ld a,003h		;3584
l3586h:
	rlca			;3586
	or b			;3587
	ld b,a			;3588
	ld a,(0439ah)		;3589
	rlca			;358c
	rlca			;358d
	and 020h		;358e
	or b			;3590
	add a,080h		;3591
	ld l,a			;3593
	ld h,03eh		;3594
	ld a,(hl)			;3596
	ld (0436eh),a		;3597
	inc l			;359a
	ld a,(hl)			;359b
	add a,c			;359c
	and 0f8h		;359d
	ld (0436dh),a		;359f
	ret			;35a2
	rst 38h			;35a3
	rst 38h			;35a4
	rst 38h			;35a5
	rst 38h			;35a6
	rst 38h			;35a7
	rst 38h			;35a8
	rst 38h			;35a9
	rst 38h			;35aa
	rst 38h			;35ab
	rst 38h			;35ac
	rst 38h			;35ad
	rst 38h			;35ae
	rst 38h			;35af
sub_35b0h:
	ld a,(hl)			;35b0
	and a			;35b1
	ret z			;35b2
	ld b,a			;35b3
	inc l			;35b4
	inc l			;35b5
	inc l			;35b6
	inc l			;35b7
	ld a,(hl)			;35b8
	and a			;35b9
	jp z,l35beh		;35ba
	dec (hl)			;35bd
l35beh:
	ex de,hl			;35be
	push de			;35bf
	ld a,b			;35c0
	rlca			;35c1
	rlca			;35c2
	rlca			;35c3
	ld l,a			;35c4
	ld h,03fh		;35c5
	ld b,(hl)			;35c7
	inc hl			;35c8
	ld c,(hl)			;35c9
	push bc			;35ca
	inc hl			;35cb
	ld b,(hl)			;35cc
	inc hl			;35cd
	ld c,(hl)			;35ce
	push bc			;35cf
	inc hl			;35d0
	ld b,(hl)			;35d1
	inc hl			;35d2
	ld c,(hl)			;35d3
	push bc			;35d4
	inc hl			;35d5
	ld b,(hl)			;35d6
	inc hl			;35d7
	ld c,(hl)			;35d8
	push bc			;35d9
	ex de,hl			;35da
	ret			;35db
	rst 38h			;35dc
	rst 38h			;35dd
	rst 38h			;35de
	rst 38h			;35df
	inc l			;35e0
	inc l			;35e1
	ld a,(hl)			;35e2
	cp 010h		;35e3
	jp nc,l3628h		;35e5
	ld b,a			;35e8
	dec l			;35e9
	add a,(hl)			;35ea
	ld (hl),a			;35eb
	dec l			;35ec
	dec l			;35ed
	ld a,b			;35ee
	add a,(hl)			;35ef
	ld (hl),a			;35f0
	cp 008h		;35f1
	jp c,l366ah		;35f3
	and 007h		;35f6
	ld (hl),a			;35f8
	dec l			;35f9
	ld a,(hl)			;35fa
	sub 020h		;35fb
	ld (hl),a			;35fd
	jp nc,l3604h		;35fe
	dec l			;3601
	dec (hl)			;3602
	inc l			;3603
l3604h:
	inc l			;3604
	inc l			;3605
	inc l			;3606
	ld c,(hl)			;3607
	inc l			;3608
	inc l			;3609
	ld a,(hl)			;360a
	dec l			;360b
	ld (hl),010h		;360c
	sub c			;360e
	jp z,l3672h		;360f
	dec a			;3612
	rrca			;3613
	rrca			;3614
	rrca			;3615
	and 01fh		;3616
	cp b			;3618
	inc a			;3619
	ld (hl),a			;361a
	ret c			;361b
	ld a,(0436eh)		;361c
	ld (hl),a			;361f
	cp b			;3620
	ret z			;3621
	inc b			;3622
	ld (hl),b			;3623
	ret			;3624
	rst 38h			;3625
	rst 38h			;3626
	rst 38h			;3627
l3628h:
	and 00fh		;3628
	jp z,l3744h		;362a
	ld b,a			;362d
	dec l			;362e
	ld a,(hl)			;362f
	sub b			;3630
	ld (hl),a			;3631
	dec l			;3632
	dec l			;3633
	ld a,(hl)			;3634
	sub b			;3635
	ld (hl),a			;3636
	jp nc,03695h		;3637
	and 007h		;363a
	ld (hl),a			;363c
	dec l			;363d
	ld a,(hl)			;363e
	add a,020h		;363f
	ld (hl),a			;3641
	jp nc,l3648h		;3642
	dec l			;3645
	inc (hl)			;3646
	inc l			;3647
l3648h:
	inc l			;3648
	inc l			;3649
	inc l			;364a
	ld a,(hl)			;364b
	inc l			;364c
	inc l			;364d
	sub (hl)			;364e
	rrca			;364f
	rrca			;3650
	rrca			;3651
	and 01fh		;3652
	cp b			;3654
	inc a			;3655
	dec l			;3656
	jp c,l3663h		;3657
	ld a,(0436eh)		;365a
	cp b			;365d
	jp z,l3663h		;365e
	ld a,b			;3661
	inc a			;3662
l3663h:
	or 010h		;3663
	ld (hl),a			;3665
	ret			;3666
	ld (hl),a			;3667
	ret			;3668
	rst 38h			;3669
l366ah:
	ld a,b			;366a
	and a			;366b
	ret nz			;366c
	inc l			;366d
	inc l			;366e
	inc l			;366f
	inc (hl)			;3670
	ret			;3671
l3672h:
	dec l			;3672
	ld b,(hl)			;3673
	inc l			;3674
	inc l			;3675
	ld a,(043c2h)		;3676
	and 0f8h		;3679
	cp b			;367b
	jp nc,l3680h		;367c
	ld b,a			;367f
l3680h:
	ld a,(0436dh)		;3680
	ld c,a			;3683
	add a,008h		;3684
	ld (0436dh),a		;3686
	ld a,b			;3689
	sub c			;368a
	ld (hl),008h		;368b
	ret c			;368d
	cp 008h		;368e
	ret c			;3690
	ld (hl),a			;3691
	ret			;3692
	ret c			;3693
	cp 02ch		;3694
	inc l			;3696
	ld b,(hl)			;3697
	inc l			;3698
	inc l			;3699
	ld a,(hl)			;369a
	cp b			;369b
	ret nz			;369c
	dec l			;369d
	ld (hl),000h		;369e
	inc l			;36a0
	ld a,(043c2h)		;36a1
	and 0f8h		;36a4
	cp b			;36a6
	jp c,l36abh		;36a7
	ld b,a			;36aa
l36abh:
	ld a,(0436dh)		;36ab
	add a,008h		;36ae
	ld (0436dh),a		;36b0
	add a,b			;36b3
	ld (hl),0c8h		;36b4
	ret c			;36b6
	cp 0c8h		;36b7
	ret nc			;36b9
	ld (hl),a			;36ba
	ret			;36bb
	ld (hl),a			;36bc
	ret			;36bd
	rst 38h			;36be
	rst 38h			;36bf
	ld a,(hl)			;36c0
	rrca			;36c1
	ret c			;36c2
	dec l			;36c3
	ld a,(hl)			;36c4
	inc a			;36c5
	and 007h		;36c6
	ld (hl),a			;36c8
	ret			;36c9
	rst 38h			;36ca
	rst 38h			;36cb
	pop de			;36cc
	pop bc			;36cd
	pop hl			;36ce
	ret			;36cf
	rst 38h			;36d0
	rst 38h			;36d1
	pop de			;36d2
	pop bc			;36d3
	pop hl			;36d4
	ld a,(hl)			;36d5
	and a			;36d6
	ret nz			;36d7
	ld (hl),b			;36d8
	dec l			;36d9
	dec l			;36da
	dec l			;36db
	dec l			;36dc
	ld (hl),d			;36dd
	ld a,(04368h)		;36de
	or 001h		;36e1
	ld (04368h),a		;36e3
	ret			;36e6
	rst 38h			;36e7
	rst 38h			;36e8
	rst 38h			;36e9
	pop de			;36ea
	pop bc			;36eb
	pop hl			;36ec
	ld a,(hl)			;36ed
	and a			;36ee
	ret nz			;36ef
	inc l			;36f0
	inc l			;36f1
	ld a,(hl)			;36f2
	and 00fh		;36f3
	ret nz			;36f5
	dec l			;36f6
	dec l			;36f7
	ld (hl),b			;36f8
	dec l			;36f9
	dec l			;36fa
	dec l			;36fb
	dec l			;36fc
	ld (hl),d			;36fd
	ld a,(04368h)		;36fe
	or 002h		;3701
	ld (04368h),a		;3703
	ret			;3706
	rst 38h			;3707
	rst 38h			;3708
	rst 38h			;3709
	pop de			;370a
	pop bc			;370b
	pop hl			;370c
	ld a,(hl)			;370d
	and a			;370e
	ret nz			;370f
	inc l			;3710
	inc l			;3711
	ld a,(hl)			;3712
	and 00fh		;3713
	ret nz			;3715
	dec l			;3716
	dec l			;3717
	ld (hl),b			;3718
	dec l			;3719
	dec l			;371a
	dec l			;371b
	dec l			;371c
	ld (hl),d			;371d
	ld a,(04368h)		;371e
	or 004h		;3721
	ld (04368h),a		;3723
	ld a,(0436fh)		;3726
	and e			;3729
	and 0f0h		;372a
	ret nz			;372c
	ld a,e			;372d
	and 00fh		;372e
	ld (hl),a			;3730
	inc l			;3731
	inc l			;3732
	inc l			;3733
	inc l			;3734
	ld (hl),c			;3735
	ld a,(04368h)		;3736
	or 008h		;3739
	ld (04368h),a		;373b
	ret			;373e
	rst 38h			;373f
	rst 38h			;3740
	rst 38h			;3741
	rst 38h			;3742
	rst 38h			;3743
l3744h:
	ld (hl),011h		;3744
	dec l			;3746
	dec (hl)			;3747
	dec l			;3748
	dec l			;3749
	ld (hl),007h		;374a
	dec l			;374c
	ld a,(hl)			;374d
	add a,020h		;374e
	ld (hl),a			;3750
	ret nc			;3751
	dec l			;3752
	inc (hl)			;3753
	ret			;3754
	rst 38h			;3755
	rst 38h			;3756
	rst 38h			;3757
sub_3758h:
	ld a,(hl)			;3758
	and a			;3759
	ret z			;375a
	dec (hl)			;375b
	jp z,l37cch		;375c
	ld a,(hl)			;375f
	rrca			;3760
	jp nc,l37b0h		;3761
	ld a,00fh		;3764
	sub (hl)			;3766
	and 00eh		;3767
	rlca			;3769
	rlca			;376a
	rlca			;376b
	rlca			;376c
	inc l			;376d
	inc l			;376e
	ld d,(hl)			;376f
	inc l			;3770
	ld e,(hl)			;3771
	push af			;3772
	push de			;3773
	ld bc,0ffdfh		;3774
	call sub_3796h		;3777
	pop de			;377a
	pop af			;377b
	cpl			;377c
	ld l,a			;377d
	ld h,0ffh		;377e
	inc hl			;3780
	add hl,de			;3781
	ex de,hl			;3782
	ld hl,0bfa0h		;3783
	add hl,de			;3786
	ret nc			;3787
	ex de,hl			;3788
	ld de,017d6h		;3789
	ld (hl),000h		;378c
	inc hl			;378e
	ld (hl),000h		;378f
	add hl,bc			;3791
	jp l3540h		;3792
	rst 38h			;3795
sub_3796h:
	add a,060h		;3796
	ld l,a			;3798
	ld h,000h		;3799
	jp nc,l379fh		;379b
	inc h			;379e
l379fh:
	add hl,de			;379f
	ex de,hl			;37a0
	ld hl,0bcc0h		;37a1
	add hl,de			;37a4
	ret c			;37a5
	ex de,hl			;37a6
	ld de,l17d0h		;37a7
	jp l3540h		;37aa
	rst 38h			;37ad
	rst 38h			;37ae
	rst 38h			;37af
l37b0h:
	inc l			;37b0
	ld a,(hl)			;37b1
	daa			;37b2
	ld (hl),a			;37b3
	inc l			;37b4
	ld d,(hl)			;37b5
	inc l			;37b6
	ld e,(hl)			;37b7
	dec l			;37b8
	dec l			;37b9
	nop			;37ba
	call sub_0217h		;37bb
	ld a,020h		;37be
	ld (de),a			;37c0
	call sub_0210h		;37c1
	ld b,002h		;37c4
	jp l00c4h		;37c6
	rst 38h			;37c9
	rst 38h			;37ca
	rst 38h			;37cb
l37cch:
	inc l			;37cc
	inc l			;37cd
	inc l			;37ce
	ld a,(hl)			;37cf
	and 01fh		;37d0
	add a,020h		;37d2
	ld l,a			;37d4
	ld h,043h		;37d5
	ld bc,0ffdfh		;37d7
	ld de,l001ah		;37da
l37ddh:
	ld (hl),d			;37dd
	inc hl			;37de
	ld (hl),d			;37df
	add hl,bc			;37e0
	dec e			;37e1
	jp nz,l37ddh		;37e2
	ret			;37e5
	rst 38h			;37e6
	rst 38h			;37e7
	rst 38h			;37e8
	rst 38h			;37e9
	rst 38h			;37ea
	rst 38h			;37eb
	rst 38h			;37ec
	rst 38h			;37ed
	rst 38h			;37ee
	rst 38h			;37ef
	rst 38h			;37f0
	rst 38h			;37f1
	rst 38h			;37f2
	rst 38h			;37f3
	rst 38h			;37f4
	rst 38h			;37f5
	rst 38h			;37f6
	rst 38h			;37f7
	rst 38h			;37f8
	rst 38h			;37f9
	rst 38h			;37fa
	rst 38h			;37fb
	rst 38h			;37fc
	rst 38h			;37fd
	rst 38h			;37fe
	rst 38h			;37ff
sub_3800h:
	ld a,(043c4h)		;3800
	and 008h		;3803
	ret z			;3805
	ld a,(043e6h)		;3806
	add a,008h		;3809
	ld d,a			;380b
	ld a,(04bd2h)		;380c
	ld e,a			;380f
	ld a,(043e7h)		;3810
	and 0e0h		;3813
	ld b,a			;3815
	ld a,(043e7h)		;3816
	sub e			;3819
	nop			;381a
	and 01fh		;381b
	or b			;381d
	ld e,a			;381e
	ld a,(de)			;381f
	sub 090h		;3820
	ret c			;3822
	ld b,a			;3823
	ld a,(043c6h)		;3824
	and 007h		;3827
	add a,000h		;3829
	ld l,a			;382b
	ld h,03eh		;382c
	ld c,(hl)			;382e
	ld a,e			;382f
	and 00eh		;3830
	rlca			;3832
	rlca			;3833
	ld e,a			;3834
	ld a,0a8h		;3835
	sub e			;3837
	ld e,a			;3838
	ld d,04bh		;3839
	ld a,b			;383b
l383ch:
	cp 050h		;383c
	call c,sub_3844h		;383e
	jp l391ch		;3841
sub_3844h:
	add a,060h		;3844
	ld l,a			;3846
	ld h,03bh		;3847
	ld a,(hl)			;3849
	and c			;384a
	ret z			;384b
	call sub_38a1h		;384c
	ex de,hl			;384f
	ld a,(hl)			;3850
	ld (hl),000h		;3851
	inc l			;3853
	inc l			;3854
	inc l			;3855
	inc l			;3856
	ld d,(hl)			;3857
	pop hl			;3858
	ld hl,043bbh		;3859
	dec (hl)			;385c
	cp 00bh		;385d
	jp c,l3894h		;385f
	ld e,a			;3862
	ld a,0ffh		;3863
	ld (04369h),a		;3865
	ld hl,04378h		;3868
	ld bc,01010h		;386b
	ld a,e			;386e
	cp 00fh		;386f
	jp z,l38fbh		;3871
	ld a,d			;3874
	rrca			;3875
	and 07ch		;3876
	add a,030h		;3878
	ld c,a			;387a
	ld a,e			;387b
	cp 00eh		;387c
	jp z,l38fbh		;387e
	ld a,c			;3881
	rrca			;3882
	ld c,a			;3883
	ld a,e			;3884
	cp 00ch		;3885
	jp nc,l38fbh		;3887
	ld a,c			;388a
	rrca			;388b
	ld c,a			;388c
	jp l38fbh		;388d
	rst 38h			;3890
	rst 38h			;3891
	rst 38h			;3892
	rst 38h			;3893
l3894h:
	ld bc,l0d05h		;3894
	ld a,0ffh		;3897
	ld (04364h),a		;3899
	jp l38f8h		;389c
	rst 38h			;389f
	rst 38h			;38a0
sub_38a1h:
	push de			;38a1
	ld c,020h		;38a2
	ex de,hl			;38a4
	inc hl			;38a5
	ld d,(hl)			;38a6
	inc hl			;38a7
	ld e,(hl)			;38a8
	ld a,(0198ch)		;38a9
	add a,0deh		;38ac
	ld l,a			;38ae
	ld h,017h		;38af
	call sub_34deh		;38b1
	pop de			;38b4
	ret			;38b5
	dec (hl)			;38b6
	pop de			;38b7
	ret			;38b8
	rst 38h			;38b9
	rst 38h			;38ba
	rst 38h			;38bb
l38bch:
	add a,0b0h		;38bc
	ld l,a			;38be
	ld h,03bh		;38bf
	ld a,(hl)			;38c1
	and c			;38c2
	ret z			;38c3
	call sub_38a1h		;38c4
	ld a,(de)			;38c7
	sub 00bh		;38c8
	jp c,l38e9h		;38ca
	cp 003h		;38cd
	jp nc,l38e9h		;38cf
	ld b,a			;38d2
	ld h,d			;38d3
	ld a,e			;38d4
	add a,005h		;38d5
	ld l,a			;38d7
	ld a,(043c6h)		;38d8
	cp (hl)			;38db
	rla			;38dc
	rlca			;38dd
	rlca			;38de
	and 004h		;38df
	or b			;38e1
	add a,0b8h		;38e2
	ld l,a			;38e4
	ld h,03dh		;38e5
	ld a,(hl)			;38e7
	ld (de),a			;38e8
l38e9h:
	ld a,0ffh		;38e9
	ld (04366h),a		;38eb
	ld bc,sub_0700h+2		;38ee
	jp l38f8h		;38f1
	rst 38h			;38f4
	rst 38h			;38f5
	rst 38h			;38f6
	rst 38h			;38f7
l38f8h:
	ld hl,04370h		;38f8
l38fbh:
	xor a			;38fb
	cp (hl)			;38fc
	jp z,l3906h		;38fd
	inc l			;3900
	inc l			;3901
	inc l			;3902
	inc l			;3903
	cp (hl)			;3904
	ret nz			;3905
l3906h:
	ld (hl),b			;3906
	inc l			;3907
	ld (hl),c			;3908
	inc l			;3909
	ld a,(043e6h)		;390a
	ld (hl),a			;390d
	inc l			;390e
	ld a,(043e7h)		;390f
	ld (hl),a			;3912
	ld a,(043c4h)		;3913
	and 0f7h		;3916
	ld (043c4h),a		;3918
	ret			;391b
l391ch:
	ld a,b			;391c
	cp 020h		;391d
	jp nc,l38bch		;391f
	ret			;3922
l3923h:
	ret z			;3923
	dec (hl)			;3924
	ld l,08dh		;3925
	ld a,(hl)			;3927
	and 03fh		;3928
	or 080h		;392a
	ld (hl),a			;392c
	ret			;392d
	ret			;392e
	rst 38h			;392f
sub_3930h:
	ld a,(04bd2h)		;3930
	and 01eh		;3933
	add a,0c0h		;3935
	ld l,a			;3937
	ld h,03dh		;3938
	ld e,(hl)			;393a
	inc l			;393b
	ld l,(hl)			;393c
	ld h,04bh		;393d
	call sub_3a00h		;393f
	ld a,(0439fh)		;3942
	add a,d			;3945
	ld c,a			;3946
	ld a,(0439eh)		;3947
	sub d			;394a
	ld b,a			;394b
l394ch:
	push hl			;394c
	call sub_395ch		;394d
	pop hl			;3950
	ld a,l			;3951
	add a,008h		;3952
	ld l,a			;3954
	dec e			;3955
	jp nz,l394ch		;3956
	ret			;3959
	rst 38h			;395a
	rst 38h			;395b
sub_395ch:
	ld a,(hl)			;395c
	cp 005h		;395d
	ret c			;395f
	ld a,l			;3960
	add a,005h		;3961
	ld l,a			;3963
	ld a,(hl)			;3964
	cp b			;3965
	ret c			;3966
	cp c			;3967
	ret nc			;3968
	sub 004h		;3969
	ld b,a			;396b
	dec l			;396c
	dec l			;396d
	dec l			;396e
	ld a,(04bd2h)		;396f
	add a,(hl)			;3972
	and 01fh		;3973
	rlca			;3975
	rlca			;3976
	rlca			;3977
	add a,008h		;3978
	ld c,a			;397a
	jp l25b7h		;397b
	rst 38h			;397e
	rst 38h			;397f
sub_3980h:
	ld a,(04bd2h)		;3980
	sub 00ch		;3983
	ret c			;3985
	cp 010h		;3986
	ret nc			;3988
	ld hl,043c4h		;3989
	ld de,04bc0h		;398c
	ld b,004h		;398f
	call sub_05e0h		;3991
	ld l,0e6h		;3994
	ld b,002h		;3996
	call sub_05e0h		;3998
	ld l,0e2h		;399b
	ld de,043e6h		;399d
	ld b,002h		;39a0
	call sub_05e0h		;39a2
	ld l,0c4h		;39a5
	ld (hl),008h		;39a7
	ld de,0439eh		;39a9
	ld a,(0439bh)		;39ac
	rrca			;39af
	jp c,l39bfh		;39b0
	inc e			;39b3
	ld l,0e7h		;39b4
	ld a,(hl)			;39b6
	sub 020h		;39b7
	ld (hl),a			;39b9
	dec l			;39ba
	ld a,(hl)			;39bb
	sbc a,000h		;39bc
	ld (hl),a			;39be
l39bfh:
	ld a,(de)			;39bf
	ld (043c6h),a		;39c0
l39c3h:
	call sub_3800h		;39c3
	ld hl,043c4h		;39c6
	ld a,(hl)			;39c9
	and 008h		;39ca
	jp z,l39f0h		;39cc
	ld hl,043e7h		;39cf
	inc (hl)			;39d2
	ld a,(hl)			;39d3
	and 01fh		;39d4
	cp 01dh		;39d6
	jp c,l39c3h		;39d8
l39dbh:
	ld hl,04bc0h		;39db
	ld de,043c4h		;39de
	ld b,004h		;39e1
	call sub_05e0h		;39e3
	ld e,0e6h		;39e6
	ld b,002h		;39e8
	jp sub_05e0h		;39ea
	rst 38h			;39ed
	rst 38h			;39ee
	rst 38h			;39ef
l39f0h:
	ld l,0a6h		;39f0
	ld a,(hl)			;39f2
	cp 0c0h		;39f3
	jp c,sub_0cc4h		;39f5
	sub 001h		;39f8
	ld (hl),a			;39fa
	jp l39dbh		;39fb
	rst 38h			;39fe
	rst 38h			;39ff
sub_3a00h:
	ld a,(043bbh)		;3a00
	sub 00ch		;3a03
	cpl			;3a05
	inc a			;3a06
	ld d,a			;3a07
	ld a,(0439bh)		;3a08
	rrca			;3a0b
	rrca			;3a0c
	ret c			;3a0d
	pop hl			;3a0e
	ret			;3a0f
l3a10h:
	ld hl,043b8h		;3a10
	ld a,(hl)			;3a13
	and a			;3a14
	jp nz,l3b43h		;3a15
	ld l,08dh		;3a18
	ld (hl),0cfh		;3a1a
	ret			;3a1c
sub_3a1dh:
	ld hl,04369h		;3a1d
	ld a,(hl)			;3a20
	and a			;3a21
	jp z,l3a40h		;3a22
	cp 020h		;3a25
	jp c,l3a2ch		;3a27
	ld (hl),020h		;3a2a
l3a2ch:
	dec (hl)			;3a2c
	ld a,(hl)			;3a2d
	rlca			;3a2e
	rlca			;3a2f
	nop			;3a30
	cpl			;3a31
	and 00eh		;3a32
	ld l,08dh		;3a34
	ld (hl),a			;3a36
	ld l,068h		;3a37
	ld (hl),000h		;3a39
	ld l,066h		;3a3b
	ld (hl),000h		;3a3d
	ret			;3a3f
l3a40h:
	ld l,064h		;3a40
	ld a,(hl)			;3a42
	and a			;3a43
	jp z,l3a62h		;3a44
	cp 010h		;3a47
	jp c,l3a4eh		;3a49
	ld (hl),010h		;3a4c
l3a4eh:
	dec (hl)			;3a4e
	ld a,(hl)			;3a4f
l3a50h:
	rrca			;3a50
	nop			;3a51
	nop			;3a52
	cpl			;3a53
	and 007h		;3a54
	or 010h		;3a56
	ld l,08ch		;3a58
	ld (hl),a			;3a5a
	ld l,066h		;3a5b
	ld (hl),000h		;3a5d
	ret			;3a5f
	rrca			;3a60
	nop			;3a61
l3a62h:
	ld l,066h		;3a62
	ld a,(hl)			;3a64
	and a			;3a65
	ret z			;3a66
	cp 010h		;3a67
	jp c,l3a78h		;3a69
	ld (hl),010h		;3a6c
	ld a,(043b8h)		;3a6e
	and 008h		;3a71
	jp z,l3a78h		;3a73
	ld (hl),005h		;3a76
l3a78h:
	dec (hl)			;3a78
	ld l,08ch		;3a79
	ld a,(hl)			;3a7b
	and 008h		;3a7c
	or 004h		;3a7e
	ld (hl),a			;3a80
	ret			;3a81
sub_3a82h:
	ld hl,0439ah		;3a82
	ld a,(hl)			;3a85
	cp 003h		;3a86
	ret c			;3a88
	ld l,08dh		;3a89
	ld a,(hl)			;3a8b
	and 03fh		;3a8c
	ld (hl),a			;3a8e
	ret			;3a8f
l3a90h:
	ld hl,0436bh		;3a90
	ld a,(hl)			;3a93
	and a			;3a94
	jp l3923h		;3a95
l3a98h:
	ld hl,04b70h		;3a98
	ld bc,l0800h		;3a9b
	ld de,l03b0h		;3a9e
l3aa1h:
	ld a,(hl)			;3aa1
	inc l			;3aa2
	and b			;3aa3
	jp z,l3aaeh		;3aa4
	ld a,(hl)			;3aa7
	cp 028h		;3aa8
	jp c,l3aaeh		;3aaa
	inc c			;3aad
l3aaeh:
	ld a,l			;3aae
	add a,d			;3aaf
	ld l,a			;3ab0
	cp e			;3ab1
	jp nz,l3aa1h		;3ab2
	ld a,c			;3ab5
	and a			;3ab6
	ret z			;3ab7
	cp 008h		;3ab8
	jp c,l3abfh		;3aba
	ld a,008h		;3abd
l3abfh:
	add a,025h		;3abf
	ld c,a			;3ac1
	ld hl,0438ch		;3ac2
	ld a,(hl)			;3ac5
	and 0c0h		;3ac6
	or c			;3ac8
	ld (hl),a			;3ac9
	ret			;3aca
	rst 38h			;3acb
	rst 38h			;3acc
	rst 38h			;3acd
	rst 38h			;3ace
	rst 38h			;3acf
l3ad0h:
	ld hl,0438eh		;3ad0
	ld a,(hl)			;3ad3
	and 001h		;3ad4
	rlca			;3ad6
	rlca			;3ad7
	or 020h		;3ad8
	ld b,a			;3ada
	dec l			;3adb
	ld a,(hl)			;3adc
	and 0c0h		;3add
	or b			;3adf
	ld (hl),a			;3ae0
	ld l,096h		;3ae1
	ld a,(hl)			;3ae3
	inc (hl)			;3ae4
	and a			;3ae5
	jp z,l3af8h		;3ae6
	ld a,(04bd6h)		;3ae9
	add a,0e0h		;3aec
	ld e,a			;3aee
	ld d,03dh		;3aef
	ld a,(de)			;3af1
	cp (hl)			;3af2
	ret nc			;3af3
	ld (hl),000h		;3af4
	ret			;3af6
	ld e,a			;3af7
l3af8h:
	ld l,08eh		;3af8
	inc (hl)			;3afa
	dec l			;3afb
	ld a,(hl)			;3afc
	or 010h		;3afd
	ld (hl),a			;3aff
	ret			;3b00
	adc a,(hl)			;3b01
l3b02h:
	ld hl,0439ah		;3b02
	ld a,(hl)			;3b05
	cp 002h		;3b06
	ret nc			;3b08
	inc l			;3b09
	ld a,(hl)			;3b0a
	ld b,a			;3b0b
	and 060h		;3b0c
	ld l,08dh		;3b0e
	ld (hl),00ah		;3b10
	ret nz			;3b12
	ld a,b			;3b13
	and 002h		;3b14
	add a,01ch		;3b16
	ld (hl),a			;3b18
	ret			;3b19
	ld a,b			;3b1a
sub_3b1bh:
	ld hl,04362h		;3b1b
	ld a,(hl)			;3b1e
	and a			;3b1f
	ret z			;3b20
	cp 040h		;3b21
	jp c,l3b28h		;3b23
	ld (hl),040h		;3b26
l3b28h:
	dec (hl)			;3b28
	ld a,(hl)			;3b29
	and 006h		;3b2a
	rlca			;3b2c
	nop			;3b2d
	ld l,08dh		;3b2e
	ld (hl),a			;3b30
	ret			;3b31
	rst 38h			;3b32
sub_3b33h:
	ld hl,0436ah		;3b33
	ld a,(hl)			;3b36
	and a			;3b37
	ret z			;3b38
	dec (hl)			;3b39
	and 008h		;3b3a
	or 007h		;3b3c
	ld l,08dh		;3b3e
	ld (hl),a			;3b40
	ret			;3b41
	adc a,l			;3b42
l3b43h:
	ld hl,043a4h		;3b43
	ld a,(hl)			;3b46
	cp 003h		;3b47
	call z,sub_23d6h		;3b49
	call sub_3b33h		;3b4c
	call sub_3b1bh		;3b4f
	call sub_3a1dh		;3b52
	call sub_27bdh		;3b55
	call sub_3a82h		;3b58
	jp l3a90h		;3b5b
	rst 38h			;3b5e
	rst 38h			;3b5f
	rra			;3b60
	ld a,h			;3b61
	ret p			;3b62
	ld bc,l07c0h		;3b63
	ld a,a			;3b66
	call m,l07f0h		;3b67
	ret nz			;3b6a
	rra			;3b6b
	rst 38h			;3b6c
	call m,0f003h		;3b6d
	rrca			;3b70
	ret nz			;3b71
	ccf			;3b72
	call m,0f01fh		;3b73
	rlca			;3b76
	cp 03fh		;3b77
	ret m			;3b79
	rrca			;3b7a
	rst 38h			;3b7b
	rst 38h			;3b7c
	call m,0ff1fh		;3b7d
	call m,0fc1fh		;3b80
	rra			;3b83
	ret p			;3b84
	ld a,a			;3b85
	ret p			;3b86
	ld a,a			;3b87
	ret nz			;3b88
	rst 38h			;3b89
	ld bc,0ffc0h		;3b8a
	ld bc,0ff00h		;3b8d
	rlca			;3b90
	nop			;3b91
	rst 38h			;3b92
	rlca			;3b93
	call m,0fc1fh		;3b94
	rra			;3b97
	ret p			;3b98
	ld a,a			;3b99
	ret p			;3b9a
	ld a,a			;3b9b
	ret nz			;3b9c
	rst 38h			;3b9d
	ld bc,0ffc0h		;3b9e
	ld bc,0ff00h		;3ba1
	rlca			;3ba4
	rst 38h			;3ba5
	rlca			;3ba6
	call m,0f81fh		;3ba7
	rrca			;3baa
	ret p			;3bab
	ret nz			;3bac
	inc bc			;3bad
	rst 38h			;3bae
	rst 38h			;3baf
	inc bc			;3bb0
	ret po			;3bb1
	inc bc			;3bb2
	ret po			;3bb3
	rrca			;3bb4
	add a,b			;3bb5
	rrca			;3bb6
	nop			;3bb7
	inc a			;3bb8
	nop			;3bb9
	ld e,03fh		;3bba
	nop			;3bbc
	call m,000f0h		;3bbd
	ld a,a			;3bc0
	cp 000h		;3bc1
	ret p			;3bc3
	inc bc			;3bc4
	ret po			;3bc5
	nop			;3bc6
	nop			;3bc7
	rrca			;3bc8
	add a,b			;3bc9
	nop			;3bca
	nop			;3bcb
	ccf			;3bcc
	nop			;3bcd
	cp 030h		;3bce
	nop			;3bd0
	ld b,0ffh		;3bd1
	nop			;3bd3
	ret m			;3bd4
	nop			;3bd5
	nop			;3bd6
	inc bc			;3bd7
	ret po			;3bd8
	nop			;3bd9
	ret po			;3bda
	ex af,af'			;3bdb
	jr nz,l3be2h		;3bdc
	ret nz			;3bde
	ld bc,l03e0h		;3bdf
l3be2h:
	ret m			;3be2
	rrca			;3be3
	rlca			;3be4
	ret po			;3be5
	ccf			;3be6
	inc bc			;3be7
	rst 38h			;3be8
	rst 38h			;3be9
	rst 38h			;3bea
	ccf			;3beb
	call m,0f8ffh		;3bec
	rst 38h			;3bef
	rst 38h			;3bf0
	rlca			;3bf1
	ret po			;3bf2
	rra			;3bf3
	ret p			;3bf4
	rst 38h			;3bf5
	call m,sub_07ffh		;3bf6
	ld e,0fch		;3bf9
	rra			;3bfb
	rra			;3bfc
	ld a,a			;3bfd
	rst 38h			;3bfe
	rst 38h			;3bff
l3c00h:
	ret pe			;3c00
	nop			;3c01
l3c02h:
	jp (hl)			;3c02
	nop			;3c03
	call nz,0c5c6h		;3c04
	rst 0			;3c07
	jp pe,0eb00h		;3c08
	nop			;3c0b
	nop			;3c0c
	nop			;3c0d
	call pe,0e900h		;3c0e
	nop			;3c11
	ret z			;3c12
	jp z,0cbc9h		;3c13
	jp pe,0ed00h		;3c16
	nop			;3c19
	nop			;3c1a
	nop			;3c1b
	xor 000h		;3c1c
	rst 28h			;3c1e
	nop			;3c1f
	call z,0cdcfh		;3c20
	ret nc			;3c23
	adc a,0d1h		;3c24
	ret p			;3c26
	nop			;3c27
	pop af			;3c28
	nop			;3c29
	jp p,0ef00h		;3c2a
	nop			;3c2d
	jp nc,0d300h		;3c2e
	push de			;3c31
	call nc,0f0d6h		;3c32
	nop			;3c35
	di			;3c36
	nop			;3c37
	ret pe			;3c38
	nop			;3c39
	jp (hl)			;3c3a
	nop			;3c3b
	call nz,0c5c6h		;3c3c
	rst 0			;3c3f
	nop			;3c40
	nop			;3c41
	call pe,0e900h		;3c42
	nop			;3c45
	ret z			;3c46
	jp z,0cbc9h		;3c47
	nop			;3c4a
	nop			;3c4b
	xor 000h		;3c4c
	rst 28h			;3c4e
	nop			;3c4f
	call z,0cdcfh		;3c50
	ret nc			;3c53
	defb 0ddh,0d1h,0f2h	;illegal sequence		;3c54
	nop			;3c57
	rst 28h			;3c58
	nop			;3c59
	jp nc,0d300h		;3c5a
	push de			;3c5d
	defb 0ddh,0d6h,000h	;illegal sequence		;3c5e
	nop			;3c61
	nop			;3c62
	nop			;3c63
	call nz,0c5c6h		;3c64
	rst 0			;3c67
	jp pe,0eb00h		;3c68
	nop			;3c6b
	nop			;3c6c
	nop			;3c6d
	nop			;3c6e
	nop			;3c6f
	nop			;3c70
	nop			;3c71
	in a,(0cah)		;3c72
	ret			;3c74
	set 5,d		;3c75
	nop			;3c77
	defb 0edh;next byte illegal after ed		;3c78
	nop			;3c79
	nop			;3c7a
	nop			;3c7b
	nop			;3c7c
	nop			;3c7d
	nop			;3c7e
	nop			;3c7f
	call c,0cdcfh		;3c80
	ret nc			;3c83
	adc a,0d1h		;3c84
	ret p			;3c86
	nop			;3c87
	pop af			;3c88
	nop			;3c89
	nop			;3c8a
	nop			;3c8b
	nop			;3c8c
	nop			;3c8d
	nop			;3c8e
	nop			;3c8f
	out (0d5h),a		;3c90
	call nc,0f0d6h		;3c92
	nop			;3c95
	di			;3c96
	nop			;3c97
	nop			;3c98
	nop			;3c99
	nop			;3c9a
	nop			;3c9b
	call nz,0c5c6h		;3c9c
	rst 0			;3c9f
	nop			;3ca0
	nop			;3ca1
	nop			;3ca2
	nop			;3ca3
	nop			;3ca4
	nop			;3ca5
	in a,(0cah)		;3ca6
	ret			;3ca8
	rlc b		;3ca9
	nop			;3cab
	nop			;3cac
	nop			;3cad
	nop			;3cae
	nop			;3caf
	call c,0cdcfh		;3cb0
	ret nc			;3cb3
	defb 0ddh,0d1h,000h	;illegal sequence		;3cb4
	nop			;3cb7
	nop			;3cb8
	nop			;3cb9
	nop			;3cba
	nop			;3cbb
	out (0d5h),a		;3cbc
	defb 0ddh,0d6h,000h	;illegal sequence		;3cbe
	nop			;3cc1
	sbc a,0e2h		;3cc2
	xor e			;3cc4
	or d			;3cc5
	xor h			;3cc6
	or e			;3cc7
	rst 18h			;3cc8
	ex (sp),hl			;3cc9
	nop			;3cca
	nop			;3ccb
	nop			;3ccc
	nop			;3ccd
	nop			;3cce
	push hl			;3ccf
	or h			;3cd0
	or (hl)			;3cd1
	or l			;3cd2
	or a			;3cd3
	call po,sub_00e6h		;3cd4
	nop			;3cd7
	nop			;3cd8
	nop			;3cd9
	nop			;3cda
	nop			;3cdb
	cp b			;3cdc
	cp e			;3cdd
	cp c			;3cde
	cp h			;3cdf
	cp d			;3ce0
	cp l			;3ce1
	nop			;3ce2
	nop			;3ce3
	nop			;3ce4
	nop			;3ce5
	nop			;3ce6
	nop			;3ce7
	cp (hl)			;3ce8
	pop bc			;3ce9
	cp a			;3cea
	jp nz,0c3c0h		;3ceb
	nop			;3cee
	rst 20h			;3cef
	rst 38h			;3cf0
	rst 38h			;3cf1
	rst 38h			;3cf2
	rst 38h			;3cf3
	rst 38h			;3cf4
	rst 38h			;3cf5
	rst 38h			;3cf6
	rst 38h			;3cf7
	rst 38h			;3cf8
	rst 38h			;3cf9
	rst 38h			;3cfa
	rst 38h			;3cfb
	rst 38h			;3cfc
	rst 38h			;3cfd
	rst 38h			;3cfe
	rst 38h			;3cff
	nop			;3d00
	nop			;3d01
	jp m,0d7fch		;3d02
	exx			;3d05
	ret c			;3d06
	jp c,0fdfbh		;3d07
	nop			;3d0a
	nop			;3d0b
	call p,0f5f6h		;3d0c
	nop			;3d0f
	call nz,0c5c6h		;3d10
	rst 0			;3d13
	rst 30h			;3d14
	nop			;3d15
	ret m			;3d16
	ld sp,hl			;3d17
	nop			;3d18
	nop			;3d19
	nop			;3d1a
	nop			;3d1b
	and a			;3d1c
	xor c			;3d1d
	xor b			;3d1e
	xor d			;3d1f
	nop			;3d20
	nop			;3d21
	nop			;3d22
	nop			;3d23
	nop			;3d24
	nop			;3d25
	xor e			;3d26
	xor l			;3d27
	xor h			;3d28
	xor (hl)			;3d29
	nop			;3d2a
	nop			;3d2b
	nop			;3d2c
	nop			;3d2d
	sbc a,000h		;3d2e
	xor e			;3d30
	or b			;3d31
	xor h			;3d32
	or c			;3d33
	rst 18h			;3d34
	nop			;3d35
	nop			;3d36
	nop			;3d37
	sbc a,0e0h		;3d38
	xor e			;3d3a
	or d			;3d3b
	xor h			;3d3c
	or e			;3d3d
	rst 18h			;3d3e
	pop hl			;3d3f
	nop			;3d40
	nop			;3d41
	sbc a,l			;3d42
	nop			;3d43
	sbc a,(hl)			;3d44
	nop			;3d45
	nop			;3d46
	nop			;3d47
	nop			;3d48
	nop			;3d49
	sbc a,a			;3d4a
	nop			;3d4b
	and b			;3d4c
	nop			;3d4d
	nop			;3d4e
	nop			;3d4f
	nop			;3d50
	nop			;3d51
	nop			;3d52
	nop			;3d53
	sbc a,h			;3d54
	nop			;3d55
	nop			;3d56
	nop			;3d57
	nop			;3d58
	nop			;3d59
	nop			;3d5a
	nop			;3d5b
	and e			;3d5c
	and l			;3d5d
	and h			;3d5e
	and (hl)			;3d5f
	nop			;3d60
	nop			;3d61
	sbc a,h			;3d62
	nop			;3d63
	nop			;3d64
	nop			;3d65
	nop			;3d66
	nop			;3d67
	sbc a,l			;3d68
	nop			;3d69
	sbc a,(hl)			;3d6a
	nop			;3d6b
	nop			;3d6c
	nop			;3d6d
	sbc a,a			;3d6e
	nop			;3d6f
	and b			;3d70
	nop			;3d71
	nop			;3d72
	nop			;3d73
	and c			;3d74
	nop			;3d75
	and d			;3d76
	nop			;3d77
	nop			;3d78
	nop			;3d79
	sub (hl)			;3d7a
	nop			;3d7b
	nop			;3d7c
	nop			;3d7d
	nop			;3d7e
	nop			;3d7f
	sub a			;3d80
	nop			;3d81
	sub e			;3d82
	nop			;3d83
	nop			;3d84
	nop			;3d85
	sbc a,b			;3d86
	nop			;3d87
	sbc a,c			;3d88
	nop			;3d89
	nop			;3d8a
	nop			;3d8b
	sbc a,d			;3d8c
	nop			;3d8d
	sbc a,e			;3d8e
	nop			;3d8f
	nop			;3d90
	nop			;3d91
	sub b			;3d92
	nop			;3d93
	nop			;3d94
	nop			;3d95
	nop			;3d96
	nop			;3d97
	sub c			;3d98
	nop			;3d99
	nop			;3d9a
	nop			;3d9b
	nop			;3d9c
	nop			;3d9d
	sub d			;3d9e
	nop			;3d9f
	sub e			;3da0
	nop			;3da1
	nop			;3da2
	nop			;3da3
	sub h			;3da4
	nop			;3da5
	sub l			;3da6
	nop			;3da7
	nop			;3da8
	nop			;3da9
	ld bc,l0000h		;3daa
	nop			;3dad
	ex af,af'			;3dae
	nop			;3daf
	nop			;3db0
	nop			;3db1
	ld a,(bc)			;3db2
	nop			;3db3
	nop			;3db4
	nop			;3db5
	dec bc			;3db6
	nop			;3db7
	inc c			;3db8
	inc c			;3db9
	ld c,0ffh		;3dba
	dec c			;3dbc
	ld c,00dh		;3dbd
	rst 38h			;3dbf
	ld b,070h		;3dc0
	rlca			;3dc2
	ld (hl),b			;3dc3
	ex af,af'			;3dc4
	ld (hl),b			;3dc5
	ex af,af'			;3dc6
	ld (hl),b			;3dc7
	ex af,af'			;3dc8
	ld (hl),b			;3dc9
	rlca			;3dca
	ld a,b			;3dcb
	ld b,080h		;3dcc
	dec b			;3dce
	adc a,b			;3dcf
	inc b			;3dd0
	sub b			;3dd1
	inc bc			;3dd2
	sbc a,b			;3dd3
	ld (bc),a			;3dd4
	and b			;3dd5
	ld bc,l02a7h+1		;3dd6
	ld (hl),b			;3dd9
	inc bc			;3dda
	ld (hl),b			;3ddb
	inc b			;3ddc
	ld (hl),b			;3ddd
	dec b			;3dde
	ld (hl),b			;3ddf
	ld b,b			;3de0
	ld b,b			;3de1
	ld b,b			;3de2
	ld b,b			;3de3
	ld b,b			;3de4
	ld b,b			;3de5
	ld b,b			;3de6
	inc (hl)			;3de7
	inc l			;3de8
	ld h,020h		;3de9
	inc e			;3deb
	jr $+22		;3dec
	ld (de),a			;3dee
	rrca			;3def
	dec c			;3df0
	dec bc			;3df1
	add hl,bc			;3df2
	ex af,af'			;3df3
	rlca			;3df4
	ld b,005h		;3df5
	inc b			;3df7
	inc bc			;3df8
	ld (bc),a			;3df9
	ld (bc),a			;3dfa
	ld (bc),a			;3dfb
	ld (bc),a			;3dfc
	ld (bc),a			;3dfd
	ld (bc),a			;3dfe
	ld (bc),a			;3dff
	ld bc,sub_0400h+2		;3e00
	ex af,af'			;3e03
	djnz l3e26h		;3e04
	ld b,b			;3e06
	add a,b			;3e07
	dec a			;3e08
	xor b			;3e09
	dec a			;3e0a
	xor h			;3e0b
	dec a			;3e0c
	or b			;3e0d
	dec a			;3e0e
	or h			;3e0f
	dec a			;3e10
	sub b			;3e11
	dec a			;3e12
	sub (hl)			;3e13
	dec a			;3e14
	sbc a,h			;3e15
	dec a			;3e16
	and d			;3e17
	dec a			;3e18
	ld a,b			;3e19
	dec a			;3e1a
	ld a,(hl)			;3e1b
	dec a			;3e1c
	add a,h			;3e1d
	dec a			;3e1e
	adc a,d			;3e1f
	dec a			;3e20
	ld h,b			;3e21
	dec a			;3e22
	ld h,(hl)			;3e23
	dec a			;3e24
	ld l,h			;3e25
l3e26h:
	dec a			;3e26
	ld (hl),d			;3e27
	dec a			;3e28
	ld b,b			;3e29
	dec a			;3e2a
	ld c,b			;3e2b
	dec a			;3e2c
	ld d,b			;3e2d
	dec a			;3e2e
	ld e,b			;3e2f
	dec a			;3e30
	jr l3e70h		;3e31
	ld (l2c3dh),hl		;3e33
	dec a			;3e36
	ld (hl),03ch		;3e37
	ret nz			;3e39
	dec a			;3e3a
	nop			;3e3b
l3e3ch:
	dec a			;3e3c
	inc c			;3e3d
	inc a			;3e3e
	nop			;3e3f
	dec a			;3e40
	ld e,b			;3e41
	dec a			;3e42
	ld d,b			;3e43
	dec a			;3e44
	ld c,b			;3e45
	dec a			;3e46
	ld b,b			;3e47
	dec a			;3e48
	ld (hl),03dh		;3e49
	inc l			;3e4b
	dec a			;3e4c
	ld (l183dh),hl		;3e4d
	inc a			;3e50
	nop			;3e51
	dec a			;3e52
	inc c			;3e53
	dec a			;3e54
	nop			;3e55
	inc a			;3e56
	ret nz			;3e57
	inc a			;3e58
	nop			;3e59
	inc a			;3e5a
	ld c,03ch		;3e5b
	inc e			;3e5d
	inc a			;3e5e
	ld hl,(l383ch)		;3e5f
	inc a			;3e62
	ld b,d			;3e63
	inc a			;3e64
	ld c,h			;3e65
	inc a			;3e66
	ld d,(hl)			;3e67
	inc a			;3e68
	ld h,b			;3e69
	inc a			;3e6a
	ld l,(hl)			;3e6b
	inc a			;3e6c
	ld a,h			;3e6d
	inc a			;3e6e
	adc a,d			;3e6f
l3e70h:
	inc a			;3e70
	sbc a,b			;3e71
	inc a			;3e72
	and d			;3e73
	inc a			;3e74
	xor h			;3e75
	inc a			;3e76
	or (hl)			;3e77
	inc a			;3e78
	ret nz			;3e79
	inc a			;3e7a
	call z,0d83ch		;3e7b
	inc a			;3e7e
	call po,04005h		;3e7f
	dec b			;3e82
	jr nz,l3e89h		;3e83
	jr nc,$+6		;3e85
	djnz l3e8fh		;3e87
l3e89h:
	ld c,b			;3e89
	ld b,028h		;3e8a
	dec b			;3e8c
	jr c,$+7		;3e8d
l3e8fh:
	jr l3e98h		;3e8f
	ld d,b			;3e91
	rlca			;3e92
	jr nc,l3e9bh		;3e93
	ld b,b			;3e95
	ld b,020h		;3e96
l3e98h:
	ex af,af'			;3e98
	ld e,b			;3e99
	ex af,af'			;3e9a
l3e9bh:
	jr c,$+9		;3e9b
	ld c,b			;3e9d
	rlca			;3e9e
	jr z,l3ea7h		;3e9f
	djnz l3ea8h		;3ea1
	jr nz,$+7		;3ea3
	jr nc,$+7		;3ea5
l3ea7h:
	ld b,b			;3ea7
l3ea8h:
	ex af,af'			;3ea8
	jr $+9		;3ea9
	jr z,$+9		;3eab
	jr c,l3eb5h		;3ead
	ld c,b			;3eaf
	ex af,af'			;3eb0
	jr nz,$+9		;3eb1
	jr nc,l3ebch		;3eb3
l3eb5h:
	ld b,b			;3eb5
	rlca			;3eb6
	ld d,b			;3eb7
	ex af,af'			;3eb8
	jr nc,l3ec3h		;3eb9
	ld b,b			;3ebb
l3ebch:
	ex af,af'			;3ebc
	ld d,b			;3ebd
	ex af,af'			;3ebe
	ld h,b			;3ebf
	rst 38h			;3ec0
	ld c,b			;3ec1
	ld b,b			;3ec2
l3ec3h:
	ld b,b			;3ec3
	ld b,b			;3ec4
	jr c,l3ef7h		;3ec5
	jr z,l3f01h		;3ec7
	jr nc,l3ef3h		;3ec9
	jr nz,l3efdh		;3ecb
	jr nz,l3effh		;3ecd
	jr z,$+3		;3ecf
	ld bc,l0101h		;3ed1
	nop			;3ed4
	nop			;3ed5
	ld bc,l0001h		;3ed6
	ld bc,l0101h		;3ed9
	nop			;3edc
	nop			;3edd
	nop			;3ede
	ld bc,l0403h+2		;3edf
	inc bc			;3ee2
	ld (bc),a			;3ee3
	ld bc,l0000h		;3ee4
	nop			;3ee7
	nop			;3ee8
	nop			;3ee9
	ld bc,l0101h		;3eea
	ld bc,l0202h		;3eed
	ld (bc),a			;3ef0
	ld (bc),a			;3ef1
	inc bc			;3ef2
l3ef3h:
	inc bc			;3ef3
	inc bc			;3ef4
	inc b			;3ef5
	inc b			;3ef6
l3ef7h:
	inc b			;3ef7
	dec b			;3ef8
	dec b			;3ef9
	ld b,006h		;3efa
	rlca			;3efc
l3efdh:
	ex af,af'			;3efd
	rlca			;3efe
l3effh:
	ld b,0ffh		;3eff
l3f01h:
	rst 38h			;3f01
	rst 38h			;3f02
	rst 38h			;3f03
	rst 38h			;3f04
	rst 38h			;3f05
	rst 38h			;3f06
	rst 38h			;3f07
	jr nz,$+1		;3f08
	ld (bc),a			;3f0a
	rst 38h			;3f0b
	ld (hl),0d2h		;3f0c
	ld (hl),0c0h		;3f0e
	jr nz,$+1		;3f10
	inc bc			;3f12
	rst 38h			;3f13
	ld (hl),0d2h		;3f14
	dec (hl)			;3f16
	ret po			;3f17
	jr nc,$+1		;3f18
	inc b			;3f1a
	rst 38h			;3f1b
	ld (hl),0d2h		;3f1c
l3f1eh:
	dec (hl)			;3f1e
	ret po			;3f1f
	djnz $+1		;3f20
	dec b			;3f22
	rst 38h			;3f23
	ld (hl),0eah		;3f24
l3f26h:
	dec (hl)			;3f26
	ret po			;3f27
	djnz $+1		;3f28
	ld b,0ffh		;3f2a
	ld (hl),0eah		;3f2c
l3f2eh:
	ld (hl),0c0h		;3f2e
	djnz $+98		;3f30
	rlca			;3f32
	rra			;3f33
	scf			;3f34
	ld a,(bc)			;3f35
l3f36h:
	ld (hl),0c0h		;3f36
	ret p			;3f38
	djnz l3f46h		;3f39
	ld a,(de)			;3f3b
	scf			;3f3c
	ld a,(bc)			;3f3d
	ld (hl),0c0h		;3f3e
	ld b,b			;3f40
	rst 38h			;3f41
	inc b			;3f42
	rst 38h			;3f43
	ld (hl),0eah		;3f44
l3f46h:
	ld (hl),0c0h		;3f46
	djnz $+1		;3f48
	ex af,af'			;3f4a
	rst 38h			;3f4b
	ld (hl),0eah		;3f4c
	ld (hl),0c0h		;3f4e
	ld b,b			;3f50
	djnz l3f62h		;3f51
	rla			;3f53
	scf			;3f54
	ld a,(bc)			;3f55
	ld (hl),0c0h		;3f56
	djnz $+1		;3f58
	ld a,(bc)			;3f5a
	rst 38h			;3f5b
	ld (hl),0eah		;3f5c
	dec (hl)			;3f5e
	ret po			;3f5f
	rst 38h			;3f60
	rst 38h			;3f61
l3f62h:
	rst 38h			;3f62
	rst 38h			;3f63
	ld (hl),0cch		;3f64
	dec (hl)			;3f66
	ret po			;3f67
	rst 38h			;3f68
	rst 38h			;3f69
	rst 38h			;3f6a
	rst 38h			;3f6b
	ld (hl),0cch		;3f6c
	dec (hl)			;3f6e
	ret po			;3f6f
	djnz $+1		;3f70
	ld b,0ffh		;3f72
	ld (hl),0eah		;3f74
	dec (hl)			;3f76
	ret po			;3f77
	djnz $+18		;3f78
	rlca			;3f7a
	ld a,c			;3f7b
	scf			;3f7c
	ld a,(bc)			;3f7d
	dec (hl)			;3f7e
	ret po			;3f7f
	ld bc,0ee48h		;3f80
	nop			;3f83
	djnz l3f36h		;3f84
l3f86h:
	djnz l3fa8h		;3f86
	ld bc,l2c49h		;3f88
	nop			;3f8b
	djnz l3f2eh		;3f8c
	nop			;3f8e
	or b			;3f8f
	ld bc,06a49h		;3f90
	nop			;3f93
	djnz l3f26h		;3f94
l3f96h:
	nop			;3f96
	cp b			;3f97
	ld bc,0a849h		;3f98
	nop			;3f9b
	djnz l3f1eh		;3f9c
	nop			;3f9e
	ret nz			;3f9f
	ld bc,0e649h		;3fa0
	nop			;3fa3
	djnz $+114		;3fa4
l3fa6h:
	nop			;3fa6
	ret z			;3fa7
l3fa8h:
	ld bc,l244ah		;3fa8
	nop			;3fab
	djnz $+98		;3fac
	nop			;3fae
	ret z			;3faf
	ld bc,0624ah		;3fb0
	nop			;3fb3
	djnz $+82		;3fb4
l3fb6h:
	nop			;3fb6
	ret z			;3fb7
	ld bc,0a04ah		;3fb8
	nop			;3fbb
	djnz l3ffeh		;3fbc
	nop			;3fbe
	ret z			;3fbf
	ld bc,0ce4ah		;3fc0
	nop			;3fc3
	djnz l3ffeh		;3fc4
	nop			;3fc6
	or b			;3fc7
	ld bc,0cc48h		;3fc8
	nop			;3fcb
	djnz l3f86h		;3fcc
	djnz l3ff0h		;3fce
	ld bc,0ca4ah		;3fd0
	nop			;3fd3
	djnz $+58		;3fd4
	nop			;3fd6
	cp b			;3fd7
	ld bc,0c848h		;3fd8
	nop			;3fdb
	djnz l3f96h		;3fdc
	djnz l3ff8h		;3fde
	ld bc,0c64ah		;3fe0
	nop			;3fe3
	djnz $+58		;3fe4
	nop			;3fe6
	ret nz			;3fe7
	ld bc,0c448h		;3fe8
	nop			;3feb
	djnz l3fa6h		;3fec
	djnz $+18		;3fee
l3ff0h:
	ld bc,0c24ah		;3ff0
	nop			;3ff3
	djnz $+58		;3ff4
	nop			;3ff6
	ret z			;3ff7
l3ff8h:
	ld bc,0c048h		;3ff8
	nop			;3ffb
	djnz l3fb6h		;3ffc
l3ffeh:
	djnz $+10		;3ffe
