from pathlib import Path
import re,json,math,itertools
R=Path(__file__).resolve().parents[1]
g=(R/'reference/graphics.rom').read_bytes()
pal=json.loads((R/'reference/palette-rgb.json').read_text())
(R/'build').mkdir(exist_ok=True);(R/'assets').mkdir(exist_ok=True)
# Rotated exactly as the arcade monitor; 8x8 source pixels per glyph.
tiles=[]
for layer in range(2):
 group=[]
 for n in range(256):
  pix=[[0]*8 for _ in range(8)]
  for line in range(8):
   lo=g[layer*4096+n*8+line];hi=g[layer*4096+2048+n*8+line]
   for x in range(8):pix[x][7-line]=((lo>>x)&1)|(((hi>>x)&1)<<1)
  group.append(pix)
 tiles.append(group)
(R/'build/tiles.json').write_text(json.dumps(tiles))
target=[(0,0,0),(35,180,215),(220,60,65),(245,205,65)]
# The arcade alphabet loses its counters and strokes when an eight-pixel
# glyph is squeezed into four ANTIC 4 pixels.  These are our own compact
# three-by-five drawings.  Keep the decoded arcade tiles above unchanged:
# player/missile art generation still needs the original sprite pixels.
text_patterns={
 'A':'010101111101101','B':'110101110101110','C':'011100100100011',
 'D':'110101101101110','E':'111100110100111','F':'111100110100100',
 'G':'011100101101011','H':'101101111101101','I':'111010010010111',
 'J':'001001001101010','K':'101101110101101','L':'100100100100111',
 'M':'101111111101101','N':'101111111111101','O':'010101101101010',
 'P':'110101110100100','Q':'010101101111011','R':'110101110101101',
 'S':'011100010001110','T':'111010010010010','U':'101101101101111',
 'V':'101101101101010','W':'101101111111101','X':'101101010101101',
 'Y':'101101010010010','Z':'111001010100111',
 '0':'111101101101111','1':'010110010010111','2':'110001010100111',
 '3':'110001010001110','4':'101101111001001','5':'111100110001110',
 '6':'011100111101111','7':'111001010010010','8':'111101111101111',
 '9':'111101111001110','[':'110100100100110',']':'011001001001011',
 '*':'000101010101000','.':'000000000000010','-':'000000111000000',
 '?':'110001010000010',
}
text_codes={n+1:c for n,c in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ')}
text_codes.update({0x20+n:str(n) for n in range(10)})
text_codes.update({0x1b:'[',0x1c:']',0x1f:'*',0x2a:'.',0x2b:'-',0x2f:'?'})
# The renderer samples source rows 0,1,3,4,5,7 when reducing 8 to 6.
# Its last row and the fourth horizontal pixel supply character spacing.
text_rows={y:i for i,y in enumerate((0,1,3,4,5))}
for palette in range(2):
 out=bytearray(8192)
 for layer in range(2):
  for n,pix in enumerate(tiles[layer]):
   white=layer==1 and n<64
   colors=target[:3]+([(235,235,235)] if white else [target[3]])
   # Preserve distinctions between the three arcade ink colours. Independent
   # nearest-colour rounding erased the mothership's hull and armour details.
   rgbmap={c:tuple(pal[(palette<<6)|(32 if layer else 0)|(c<<3)|(n>>5)]) for c in range(1,4)}
   inks=list(dict.fromkeys(rgb for rgb in rgbmap.values() if sum(rgb)>25))
   assignment=min(itertools.permutations(range(1,4),len(inks)),key=lambda perm:sum(sum((rgb[j]-colors[k][j])**2 for j in range(3)) for rgb,k in zip(inks,perm)))
   mapped=dict(zip(inks,assignment))
   # Preserve the mothership's visual roles explicitly: its lime upper
   # structure becomes cyan, purple detail becomes pink, and gold armour
   # stays gold. A distance-only assignment traded the gold hull for pink
   # because two original inks compete for the one Atari yellow register.
   if layer==0 and 0x40<=n<0x60:
    mapped={rgbmap[1]:1,rgbmap[2]:2,rgbmap[3]:3}
   elif layer==0 and 0x60<=n<0x80:
    mapped={rgbmap[1]:2,rgbmap[2]:1,rgbmap[3]:3}
   for y in range(8):
    packed=mask=0
    for x in range(4):
     pair=pix[y][x*2:x*2+2]
     candidates=[c for c in pair if c]
     if candidates:
      def rgb(c):return pal[(palette<<6)|(32 if layer else 0)|(c<<3)|(n>>5)]
      c=max(candidates,key=lambda c:sum(rgb(c)))
      rgbv=rgb(c)
      v=mapped.get(tuple(rgbv),0)
     else:v=0;mask|=3<<(6-x*2)
     packed|=v<<(6-x*2)
    offset=(0 if layer else 2048)+y*256+n
    if layer==1 and n in text_codes:
     bits=text_patterns[text_codes[n]]
     packed=sum((3 if bits[text_rows[y]*3+x]=='1' else 0)<<(6-x*2)
                for x in range(3)) if y in text_rows else 0
     # Foreground compositing ANDs the background with this mask first.
     # All spaces remain transparent; every lit glyph pixel is opaque.
     mask=packed^0xff
    out[offset]=packed
    if layer:out[4096+y*256+n]=mask
 import random
 rng=random.Random(0x50484f45)
 for n in range(1,128):
  if rng.randrange(4)==0:
   y=rng.choice([0,1,3,4,5,7]);x=rng.randrange(4)
   out[6144+y*256+n]=1<<(6-x*2)
 (R/f'assets/art-bank{palette+1}.bin').write_bytes(out)
rowaddr=[]
for y in range(192):
 cr=y//8;rowaddr.append(0x8000+(cr//4)*1024+((cr%4)*26+1)*8+(y%8))
(R/'src/render_tables.h').write_text('static const uint16_t rowaddr[192] __attribute__((section(".platformdata"))) = {'+','.join(hex(x) for x in rowaddr)+'};\n')
print('Prepared arcade art, readable text glyphs, and transparency masks.')
