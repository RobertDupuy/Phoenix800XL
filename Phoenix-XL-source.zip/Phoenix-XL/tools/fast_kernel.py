from pathlib import Path
R=Path(__file__).resolve().parents[1]
s=['.section .text,"ax",@progbits','.global draw_select','draw_select:',' lda 0xd0',' beq choose_background',' lda 0xd1',' ora 0xd2',' bne choose_full',' ldy 0xd5',' lda star_nonzero,y',' bne choose_full',' txa',' and #3',' tax',' lda fast_fg_lo,x',' sta 0xd6',' lda fast_fg_hi,x',' sta 0xd7',' ldx 0xd0',' jmp (0xd6)','choose_full:',' lda draw_lo,x',' sta 0xd6',' lda draw_hi,x',' sta 0xd7',' ldx 0xd0',' jmp (0xd6)','choose_background:',' lda 0xd1',' ora 0xd2',' beq choose_stars',' lda fast_bg_lo,x',' sta 0xd6',' lda fast_bg_hi,x',' sta 0xd7',' jmp (0xd6)','choose_stars:',' txa',' and #3',' tax',' lda fast_star_lo,x',' sta 0xd6',' lda fast_star_hi,x',' sta 0xd7',' ldx 0xd5',' jmp (0xd6)']
for mode in ['bg','fg','star']:
 phases=range(8) if mode=='bg' else range(1)
 names=[]
 for phase in phases:
  for kind in range(4):
   name=f'fast_{mode}_{phase}_{kind}';names.append(name);s.append(name+':')
   for k,sr in enumerate([0,1,3,4,5,7]):
    split=2 if kind==1 else 4 if kind==2 else 6
    ptr=0xcc if k>=split else 0xca;dy=k-split if k>=split else k
    if mode=='bg':s.extend([f' ldy 0x{0xd2 if sr+phase>=8 else 0xd1:x}',f' lda 0x{0xa800+((sr+phase)%8)*256:x},y'])
    else:s.append(f' lda 0x{(0xa000 if mode=="fg" else 0xb800)+sr*256:x},x')
    s.extend([f' ldy #{dy}',f' sta (0x{ptr:x}),y'])
   s.append(' rts')
 for part in ['lo','hi']:s.extend([f'fast_{mode}_{part}:','.byte '+','.join(f'{n}@mos16{part}' for n in names)])
b=(R/'assets/art-bank1.bin').read_bytes()
s.extend(['star_nonzero:','.byte '+','.join(str(int(any(b[6144+y*256+i] for y in [0,1,3,4,5,7]))) for i in range(128))])
(R/'src/fast_kernel.S').write_text('\n'.join(s)+'\n')
