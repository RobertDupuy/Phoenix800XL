"""Package the separate capture cartridge, reproducible source and evidence."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'diagnostic-release'
OUT.mkdir(exist_ok=True)
BASELINE_SHA = '2ff138c75dafef103963094558db78721ee95cbcb147f57d2231c2a1daec4a69'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert sha(ROOT / 'build/Phoenix-XL.car') == BASELINE_SHA
assert sha(ROOT / 'release/Phoenix-XL.car') == BASELINE_SHA
car = ROOT / 'diagnostic/build/Phoenix-XL-r4-Diagnostic.car'
validation = json.loads((ROOT / 'diagnostic/build/diagnostic-test-results.json').read_text())
assert validation['sha256'] == sha(car), 'Validation must match delivered binary'
header = car.read_bytes()[:16]
assert header[:4] == b'CART' and int.from_bytes(header[4:8], 'big') == 41
assert car.stat().st_size == 131088
assert int.from_bytes(header[8:12], 'big') == sum(car.read_bytes()[16:]) & 0xffffffff
shutil.copy2(car, OUT / car.name)

files = {}
def add_tree(source, archive):
    for path in source.rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:
            files[str(Path(archive) / path.relative_to(source))] = path

# Start with the complete released source package; overlay investigation tools.
base = ROOT / 'build/package/Phoenix-XL'
assert base.exists(), 'Build the ordinary source package first'
add_tree(base, 'Phoenix-XL')
add_tree(ROOT / 'tests', 'Phoenix-XL/tests')
add_tree(ROOT / 'tools', 'Phoenix-XL/tools')
add_tree(ROOT / 'diagnostic/src', 'Phoenix-XL/diagnostic/src')
for name in ('build_diagnostic.py', 'test_diagnostic.py', 'README.md'):
    files['Phoenix-XL/diagnostic/' + name] = ROOT / 'diagnostic' / name
for name in ('Phoenix-XL-r4-Diagnostic.car', 'Phoenix-XL-r4-Diagnostic.rom',
             'diagnostic.elf', 'diagnostic.map', 'manifest.json',
             'diagnostic-test-results.json', 'diagnostic-live.png',
             'audit-stall-140.png'):
    path = ROOT / 'diagnostic/build' / name
    assert path.is_file(), path
    files['Phoenix-XL/diagnostic/build/' + name] = path

files['START-HERE.txt'] = OUT / 'INVESTIGATION.txt'
evidence_patterns = (
    'control-*-results.json', 'control-*.csv', 'control-*.csv.stall.mem',
    'causal-*.csv', 'causal-*.csv.stall.mem',
    'altirra-control-search-results.json', 'altirra-held-reversal-results.json',
    'altirra-control-diagnostic-report.txt', 'altirra-control-search-*.trace.json',
    'altirra-held-reversal-*.trace.json',
)
for pattern in evidence_patterns:
    for path in (ROOT / 'build').glob(pattern):
        if path.is_file():
            files['Phoenix-XL/evidence/' + path.name] = path

archive = OUT / 'Phoenix-Control-Diagnostics.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, path in sorted(files.items()):
        z.write(path, name)
    manifest = {'baseline_cartridge_sha256': BASELINE_SHA,
                'diagnostic_cartridge_sha256': sha(car),
                'files': {name: sha(path) for name, path in sorted(files.items())}}
    z.writestr('MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
print(json.dumps({'files': [{'name': p.name, 'bytes': p.stat().st_size, 'sha256': sha(p)}
                           for p in (OUT / car.name, archive)],
                  'archive_entries': len(files) + 1, 'baseline_unchanged': True}, indent=2))
