"""Build the optional host reference and instrumented Atari800 harness."""
from pathlib import Path
import os,subprocess,tarfile
R=Path(__file__).resolve().parents[1];B=R/'build';B.mkdir(exist_ok=True)
cc=os.environ.get('CC','gcc')
ref=R/'reference/hhi/c-phoenix'
sources=[ref/p.name for p in sorted((R/'src/arcade').glob('*.c'))]
subprocess.run([cc,'-shared','-fPIC','-O2','-I'+str(ref),str(R/'tests/core_reference.c'),*map(str,sources),'-o',str(B/'core_reference.so')],check=True)
if os.environ.get('ATARI800_SOURCE'):
 root=Path(os.environ['ATARI800_SOURCE']).resolve()
else:
 root=B/'atari800-test-source'
 if not (root/'.extracted-complete').exists():
  with tarfile.open(R/'vendor/atari800-test-source.tar.gz') as t:t.extractall(B,filter='data')
  (root/'.extracted-complete').write_text('Complete source extraction.\n')
config=root/'src/config.h'
if not (root/'src/libatari800.a').exists() or not config.exists() or '#define MONITOR_PROFILE 1' not in config.read_text():
 subprocess.run(['sh','configure','--target=libatari800','--enable-monitorbreak','--enable-monitorprofile','--disable-netsio'],cwd=root,check=True)
 # The lib target forcibly disables these configure options. Enable the
 # profiling instrumentation explicitly in this isolated development build.
 cfg=config.read_text()
 for flag in ['MONITOR_BREAK','MONITOR_PROFILE']:
  cfg=cfg.replace(f'/* #undef {flag} */',f'#define {flag} 1')
 config.write_text(cfg)
 # This version spells its 32-bit ULONG macro two ways in the public/core
 # headers. The compatible redefinition warning must not become a build error.
 subprocess.run(['make','-C','src','-j2','CFLAGS=-O2 -Wno-error','CFLAGS_NOANSI=-O2 -Wno-error','libatari800.a'],cwd=root,check=True)
assert 'hg_monitor_write' in (root/'src/memory.h').read_text(),'The test harness needs the supplied memory-write observation hook.'
subprocess.run([cc,'-w','-O2','-I'+str(root/'src'),str(R/'tests/emulator.c'),str(R/'tests/profile_stubs.c'),str(root/'src/libatari800.a'),'-lz','-lm','-o',str(B/'emulator')],check=True)
