"""Revision-4 focused input verification; retain broader revision-3 evidence."""
from pathlib import Path
import argparse,hashlib,json,shutil,struct

parser=argparse.ArgumentParser(description='Generate the revision-4 direct-polling verification report.')
parser.add_argument('--clean-build-verified',action='store_true',help='A fresh source package rebuilt a byte-identical cartridge for this revision.')
args=parser.parse_args()
R=Path(__file__).resolve().parents[1];B=R/'build';D=R/'docs'
def result(name):return json.loads((B/(name+'.json')).read_text())
car=(B/'Phoenix-XL.car').read_bytes();rom=(B/'Phoenix-XL.rom').read_bytes()
assert len(car)==131088 and len(rom)==131072 and car[16:]==rom
assert car[:4]==b'CART' and struct.unpack('>III',car[4:16])==(41,sum(rom)&0xffffffff,0)
sha=hashlib.sha256(car).hexdigest()
poll=result('input-polling-results');controls=result('controls-results')
held=result('held-controls-results');pm=result('pm-visibility-results')
altirra=result('altirra-keyboard-results')
assert poll['cartridge_sha256']==sha and poll['direct_porta_read'] and poll['direction_history_removed'] and poll['direction_edge_detection_removed']
assert {r['tv'] for r in controls}=={'pal','ntsc'}
assert all(r['reset'] and r['game_over'] and r['two_player_banks']==[0,1] for r in controls)
assert {r['tv'] for r in held}=={'pal','ntsc'}
assert all(r['direction_history_independent'] and r['both_pins_forwarded'] and r['released_neutral'] and r['held_tv_frames']>=24000 and {h['pins'] for h in r['long_holds']}=={4,8} and all(h['tv_frames']>=12000 for h in r['long_holds']) and len(r['history_checks'])==4 and len(r['wave_holds'])==5 and r['shield_resume'] and r['pia_init'] for r in held)
assert pm['cartridge_sha256']==sha and {r['tv'] for r in pm['systems']}=={'pal','ntsc'}
assert all(r['initial_motion'] and r['death_seen'] and r['resumed_without_release'] for r in pm['systems'])
assert altirra['cartridge_sha256']==sha and {r['tv'] for r in altirra['results']}=={'pal','ntsc'}
assert all(r['input_losses']==0 and r['completed_poll_samples']>100 for r in altirra['results'])
assert (D/'TEST_REPORT-v3.md').is_file(),'Preserve the revision-3 report before generating revision 4.'
key_samples=sum(r['samples'] for r in altirra['results'])
completed=sum(r['completed_poll_samples'] for r in altirra['results'])
held_frames=sum(r['held_tv_frames'] for r in held)
blocked=sum(len(r.get('blocked_poll_samples',[])) for r in altirra['results'])
ship_cases=sum(r['native_visibility_cases'] for r in pm['systems'])
projectile_cases=sum(r['native_projectile_visibility_checks'] for r in pm['systems'])
lines=['# Verification report — revision 4','',
 'Revision 4 removes direction-change detection and remembered direction preferences. Each game tick reads current active-low PORTA pins and directly supplies the original LEFT/RIGHT input bits. It has no direction history, latch, edge requirement or repeat timer. Both active pins are forwarded; the original movement routine gives left priority.','',
 f'Cartridge SHA-256: `{sha}`.','',
 '## Focused revision-4 checks','',
 '- **Direct polling confirmed in source and disassembly:** the adapter reads `$D300`; `previous_directions`, `last_direction` and their transition/resolution logic are removed. Evidence is in `input-polling-results.json` and `input-polling-disassembly.txt`.',
 '- **History-independent input passed on PAL and NTSC:** four different preceding pin states produce the same pair of active direction bits when both current pins are low. Single directions and releases follow their current levels.',
 f'- **{held_frames:,} TV frames of held-input checks passed:** 12,000 per direction on each TV standard, plus shield recovery, all five wave-entry paths and explicit PIA initialization.',
 '- **Normal controls passed on PAL and NTSC:** left/right movement, firing, shield activation, reset, credit/start handling, alternating player banks and return to attract mode.',
 f'- **Actual AltirraSDL frontend checks passed:** {key_samples} keyboard-routing samples, including {completed} samples after completed input polls, recorded no lost direction input. Scripted SDL key events traversed the normal frontend/input manager; both PORTA and the arcade input byte were checked. The emulator and cartridge hashes are recorded.',
 f'- **Held direction survived death/respawn on both TV standards:** movement resumed without releasing/repressing right. The same run checked {ship_cases} native ship-visibility cases and {projectile_cases} projectile-visibility cases.',
 '- **Cartridge structure passed:** 128 KiB raw image, CART type 41, matching checksum and identical headered/raw payloads.',
 ('- **Clean source rebuild passed:** a fresh package directory produced a byte-for-byte identical revision-4 cartridge.' if args.clean_build_verified else '- **Clean source rebuild:** no revision-4 clean-rebuild certification was requested for this report.'),'',
 'The Altirra test runs on Linux through the full frontend. It distinguishes current hardware levels from an arcade input byte that has not yet reached its next game-tick poll. This is polling on game ticks, not on every television frame. Existing rendering or original game-state delays can postpone a poll.']
if blocked:
 lines += ['',f'{blocked} sampled points occurred before a complete new input poll; they are recorded separately as `blocked_poll_samples`, not counted as lost input. Held-level follow-up checks verify that polling subsequently observes the current direction.']
lines += ['',
 '## Retained revision-3 evidence','',
 'This revision changes horizontal input adaptation only. Full arcade/native parity, all-wave scenarios, presentation/HUD composition, renderer comparisons, sound capture, asset regeneration and timing were not rerun for this focused change. Their completed revision-3 evidence is preserved in `TEST_REPORT-v3.md` and `results-v3/`; it is not presented as new revision-4 testing.','',
 'The revision-3 report includes 1,400 native comparisons, 854 MAME frame comparisons, 40 renderer comparisons, five original-content information pages, 936 HUD cell checks, 16 wave/round scenarios and mothership completion. Its timing measurements continue to describe the known busy-scene slowdown, not a new revision-4 benchmark.','',
 '`Phoenix-XL-preview.mp4` remains the revision-3 capture. The input-only revision retains its graphics, original arcade text, sound and PM visibility corrections.','',
 '## Reproduction and limits','',
 'Run `tests/controls.py`, `tests/held_controls.py`, `tests/pm_visibility.py` and `tests/altirra_keyboard.py` after building. The first three use the bundled Atari800 test harness. The Altirra test requires `ALTIRRA_SDL` to select an AltirraSDL executable with test-mode support. Result JSON and the inspected input disassembly are included under `docs/results/`.','',
 'Original fire/shield edge handling, shield lockout and noninteractive formation/death/respawn states remain original gameplay rules. No horizontal direction-change logic remains in the adapter.','',
 'Physical Atari and flash-cartridge operation remain untested. Busy scenes still have measured slowdown, and POKEY effects/music approximate the arcade analog sound.','']
D.mkdir(exist_ok=True);(D/'TEST_REPORT.md').write_text('\n'.join(lines))
res=D/'results';res.mkdir(exist_ok=True)
for name in ['input-polling-results','controls-results','held-controls-results','pm-visibility-results','altirra-keyboard-results']:
 shutil.copyfile(B/(name+'.json'),res/(name+'.json'))
shutil.copyfile(B/'input-polling-disassembly.txt',res/'input-polling-disassembly.txt')
if args.clean_build_verified and (B/'clean-build-results.json').exists():
 shutil.copyfile(B/'clean-build-results.json',res/'clean-build-results.json')
print('Revision-4 focused input report generated; revision-3 report retained.')
