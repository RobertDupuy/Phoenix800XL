import json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
t=json.loads((R/'build/tiles.json').read_text())[1];rom=(R/'reference/program.rom').read_bytes();frames=[]
for phase in range(8):
 s=rom[0x1600+phase]; ids=rom[0x1400+s:0x1400+s+4];f=[]
 for y in [0,1,3,4,5,7,8,9,11,12,13,15]:
  bits=0
  for x in range(8):
   sx=x*2;tile=ids[(sx//8)*2+y//8]
   v=any(t[tile][y%8][sx%8+j] for j in (0,1));bits=(bits<<1)|v
  f.append(bits)
 frames.append(f)
(R/'src/pm_assets.h').write_text('static const uint8_t pm_ship[8][12] __attribute__((section(".platformdata")))={'+','.join('{'+','.join(map(str,f))+'}' for f in frames)+'};\n')
