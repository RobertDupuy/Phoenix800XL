from pathlib import Path
import re,math,numpy as np,json
R=Path(__file__).resolve().parents[1]
s=(R/'reference/tms36xx.cpp').read_text()
scale={'C':1.18921,'Cx':1.25992,'D':1.33484,'Dx':1.41421,'E':1.49831,'F':1.58740,'Fx':1.68179,'G':1.78180,'Gx':1.88775,'A':2,'Ax':2.11892,'B':2.24492}
notes=[]
for tune in range(1,4):
 body=s.split(f'static const int tune{tune}[96*6] = {{')[1].split('};')[0];body=re.sub(r'/\*.*?\*/','',body,flags=re.S)
 tokens=re.findall(r'\b([A-G]x?\(\d\)|0)\s*,',body)
 tokens += ['0']*(576-len(tokens));t=[]
 for n in range(96):
  pair=[]
  for voice in [0,3]:
   tok=tokens[n*6+voice];hz=0
   if tok!='0':
    a,o=tok[:-3],int(tok[-2]);hz=int(1024*(2**(o-1))*scale[a])*372//1024/2
   pair.append(hz)
  t.append(pair)
 notes.append(t)
raw=np.fromfile(R/'build/tones.pcm',dtype='<i2').reshape(2,64,-1)
fx=[];metrics=[]
for ch in range(2):
 row=[]
 for v in range(64):
  a=raw[ch,v].astype(float);a-=np.mean(a);spec=np.abs(np.fft.rfft(a*np.hanning(len(a))));freqs=np.fft.rfftfreq(len(a),1/48000);spec[freqs<40]=0
  hz=float(freqs[np.argmax(spec)]);rms=float(np.sqrt(np.mean(a*a)))
  row.append(hz);metrics.append({'circuit':ch,'latch':v,'peak_hz':hz,'rms':rms})
 fx.append(row)
lines=['/* Pitches derived from MAME circuit model / MM6221AA tune data. */']
for tv,clock in [('ntsc',1789772.5),('pal',1773447)]:
 def div(hz):return max(0,min(255,round(clock/56/hz-1))) if hz else 0
 lines.append(f'const uint8_t music_{tv}[3][96][2] __attribute__((section(".platformdata"))) = '+'{'+','.join('{'+','.join('{'+','.join(str(div(v)) for v in p)+'}' for p in t)+'}' for t in notes)+'};')
 lines.append(f'const uint8_t fx_{tv}[2][64] __attribute__((section(".platformdata"))) = '+'{'+','.join('{'+','.join(str(div(v)) for v in t)+'}' for t in fx)+'};')
(R/'src/sound_tables.h').write_text('\n'.join(lines)+'\n');(R/'build/sound-metrics.json').write_text(json.dumps(metrics,indent=2));print('Tone and melody pitch tables generated')
