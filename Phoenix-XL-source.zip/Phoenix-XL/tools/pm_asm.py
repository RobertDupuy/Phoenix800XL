from pathlib import Path
import re
R=Path(__file__).resolve().parents[1]
s='''# GTIA P0: ship; P1/P2: player shots; P3: fifth enemy shot.
# M0..M3: first four enemy shots. Original software collision RAM remains intact.
.section .bss,"aw",@nobits
old_pm_y: .zero 7
old_ship_x: .zero 1
old_ship_y: .zero 1
ship_visible: .zero 1
.section .text,"ax",@progbits
.global pm_update
pm_update:
 # Object flags retain bit 3 (and bit 7) during death/respawn. The game
 # state, not those draw flags, decides whether an intact ship may exist.
 lda 0x13a4
 cmp #3
 beq pm_ship_game_state
 cmp #6
 beq pm_ship_game_state
 cmp #7
 bne pm_hide_ship
pm_ship_game_state:
 lda 0x13c0
 and #8
 beq pm_hide_ship
 # Only these original phases call player_update: 1, 3, 5, 7 and B.
 # Initialized coordinates during fade-in do not mean the ship is drawn.
 lda 0x13b8
 and #15
 cmp #9
 beq pm_hide_ship
 and #1
 beq pm_hide_ship
 lda ship_visible
 beq pm_new_ship
 lda 0x13c2
 cmp old_ship_x
 bne pm_new_ship
 lda 0x13c3
 cmp old_ship_y
 beq pm_shots
pm_new_ship:
 jsr pm_erase_ship
 lda 0x13c2
 sta old_ship_x
 and #0xf8
 lsr
 clc
 adc #80
 sta 0xd000
 lda 0x13c3
 sta old_ship_y
 and #0xf8
 tax
 lda pm_y_scale,x
 sta ship_visible
 tay
 lda 0x13c2
 and #7
 tax
 lda pm_shape_index,x
 tax
 lda #12
 sta 0xc0
pm_draw_ship:
 lda pm_ship,x
 sta 0x9c00,y
 inx
 iny
 dec 0xc0
 bne pm_draw_ship
 jmp pm_shots
pm_hide_ship:
 jsr pm_erase_ship
 lda #0
 sta 0xd000
pm_shots:
 # Original clear_foreground removes all surviving shots when the death
 # counter reaches $20. Stale object flags must not keep PM shots alive.
 lda #0
 sta 0xc6
 lda 0x13a4
 cmp #3
 beq pm_shots_active_phase
 cmp #6
 beq pm_shots_active_phase
 cmp #7
 beq pm_shots_active_phase
 cmp #4
 bne pm_shots_filter_ready
 lda 0x13a5
 cmp #0x21
 bcc pm_shots_filter_ready
 bcs pm_shots_allow
pm_shots_active_phase:
 lda 0x13b8
 and #15
 cmp #9
 beq pm_shots_filter_ready
 and #1
 beq pm_shots_filter_ready
pm_shots_allow:
 lda #8
 sta 0xc6
pm_shots_filter_ready:
 lda #0
 sta 0xc0
 sta 0xc2
pm_shot_loop:
 ldx 0xc0
 lda pm_pages,x
 sta 0xc3
 ldy old_pm_y,x
 beq pm_shot_new
 lda pm_clear,x
 sta 0xc4
 lda #4
 sta 0xc5
pm_shot_erase:
 lda (0xc2),y
 and 0xc4
 sta (0xc2),y
 iny
 dec 0xc5
 bne pm_shot_erase
pm_shot_new:
 lda #0
 sta old_pm_y,x
 ldy pm_hpos,x
 sta 0xd000,y
 txa
 asl
 asl
 tax
 lda 0x13c4,x
 and 0xc6
 beq pm_shot_next
 lda 0x13c6,x
 lsr
 clc
 adc #80
 sta 0xd000,y
 lda 0x13c7,x
 tax
 lda pm_y_scale,x
 tay
 ldx 0xc0
 sta old_pm_y,x
 lda pm_bits,x
 sta 0xc4
 lda #4
 sta 0xc5
pm_shot_draw:
 lda (0xc2),y
 ora 0xc4
 sta (0xc2),y
 iny
 dec 0xc5
 bne pm_shot_draw
pm_shot_next:
 inc 0xc0
 lda 0xc0
 cmp #7
 bne pm_shot_loop
 rts
pm_erase_ship:
 ldy ship_visible
 beq pm_ship_end
 lda #0
 ldx #12
pm_ship_clear:
 sta 0x9c00,y
 iny
 dex
 bne pm_ship_clear
 sta ship_visible
pm_ship_end:
 rts
pm_pages: .byte 0x9d,0x9e,0x9b,0x9b,0x9b,0x9b,0x9f
pm_hpos: .byte 1,2,4,5,6,7,3
pm_bits: .byte 128,128,3,12,48,192,192
pm_clear: .byte 0,0,252,243,207,63,0
pm_shape_index: .byte 0,12,24,36,48,60,72,84
pm_y_scale:
'''
s+='.byte '+','.join(str(32+y*3//4) for y in range(256))+'\npm_ship:\n'
data=re.findall(r'\d+', (R/'src/pm_assets.h').read_text().split('={')[1])
s+='.byte '+','.join(data)+'\n'
(R/'src/pm.S').write_text(s)
