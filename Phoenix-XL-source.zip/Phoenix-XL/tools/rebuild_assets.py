"""Optional regeneration of checked-in graphics, kernels, and sound tables."""
from pathlib import Path
import subprocess,sys,os
R=Path(__file__).resolve().parents[1];B=R/'build';B.mkdir(exist_ok=True)
for name in ['assets','render_kernel','fast_kernel','pm_assets','pm_asm','hud_assets','presentation_assets']:
 subprocess.run([sys.executable,str(R/f'tools/{name}.py')],cwd=R,check=True)
ref=R/'reference/hhi/c-phoenix'
subprocess.run([os.environ.get('CC','gcc'),'-O2','-I'+str(ref),str(R/'tools/sound_probe.c'),*[str(ref/(s+'.c')) for s in ['sound','sound_discrete','tms36xx','mame_lofi_resampler']],'-lm','-o',str(B/'sound_probe')],check=True)
with (B/'tones.pcm').open('wb') as f:subprocess.run([str(B/'sound_probe')],stdout=f,check=True)
subprocess.run([sys.executable,str(R/'tools/sound_assets.py')],check=True)
subprocess.run([sys.executable,str(R/'tools/sound_circuit_tables.py')],check=True)
