from pathlib import Path
import subprocess,os,struct,json,shutil
R=Path(__file__).resolve().parents[1];B=R/'build';B.mkdir(exist_ok=True)
def find_tool(name,env,subdir=''):
 root=os.environ.get(env)
 if root:
  p=Path(root)/subdir/name
  if p.is_file():return str(p)
 p=shutil.which(name)
 if p:return p
 if env=='LLVM_MOS':
  p=R.parent/'toolchain/llvm-mos/bin'/name
  if p.is_file():return str(p)
 raise SystemExit(f'Missing {name}: put it on PATH or set {env}.')
mos=find_tool('mos-common-clang','LLVM_MOS','bin')
ca65=find_tool('ca65','CC65_BIN');ld65=find_tool('ld65','CC65_BIN')
subprocess.run([str(mos),os.environ.get('OPT','-Os'),'-nostartfiles','-Lsrc','-Wl,-Map,build/game.map','-I','src/arcade','src/start.S','src/platform.c','src/audio.c','src/audio.S','src/video.c','src/hud.S','src/presentation.S','src/pm.S','src/memory.S','src/native_hot.S','src/renderer.S','src/draw_kernel.S','src/fast_kernel.S',*map(str,sorted(p for p in (R/'src/arcade').glob('*.c') if p.name!='sprite_rendering.c')),'-o','build/game.bin'],cwd=R,check=True)
subprocess.run([ca65,'src/loader.s','-o','build/loader.o'],cwd=R,check=True)
subprocess.run([ld65,'-C','src/loader.cfg','build/loader.o','-o','build/loader.bin'],cwd=R,check=True)
b=(B/'game.bin').read_bytes();print('imagebytes',len(b));assert len(b)==0x5e00+0x27f0+0x1ff0
rom=bytearray([255])*131072
rom[:0x1ff0]=b[0x5e00+0x27f0:]
for i in [1,2]:
 art=(R/f'assets/art-bank{i}.bin').read_bytes();assert len(art)==8192
 rom[i*8192:(i+1)*8192]=art
font=(R/'assets/hud-font.bin').read_bytes();assert len(font)==1024
rom[14*8192:14*8192+1024]=font
screen=(R/'assets/game-screen.bin').read_bytes();assert len(screen)==768
rom[14*8192+1024:14*8192+1792]=screen
for name,offset,size in [('hud-map.bin',0x700,120),('hud-glyphs.bin',0x800,4096),('hud-pointers.bin',0x1800,312)]:
 data=(R/'assets'/name).read_bytes();assert len(data)==size
 rom[14*8192+offset:14*8192+offset+size]=data
for i in range(8,13):
 page=(R/f'assets/presentation-{i}.bin').read_bytes();assert len(page)==7104
 rom[i*8192:i*8192+len(page)]=page
records=bytearray();page=0
for base,d in [(0x2000,b[:0x5e00]),(0xd800,b[0x5e00:0x5e00+0x27f0])]:
 for ofs in range(0,len(d),256):
  bank=3+page//31;addr=0xa000+(page%31)*256;dest=base+ofs
  chunk=d[ofs:ofs+256].ljust(256,b'\0');rom[bank*8192+(addr-0xa000):bank*8192+(addr-0xa000)+256]=chunk
  records.extend([bank,addr>>8,dest>>8]);page+=1
records.append(255);assert len(records)<1024
loader=(B/'loader.bin').read_bytes();assert len(loader)<=256
# bank 15 boot entry copies the loader to RAM then enters it.
stub=bytes([0x78,0xa2,0,0xbd,0,0xa1,0x9d,0,7,0xe8,0xd0,0xf7,0x4c,0,7])
rom[15*8192:15*8192+len(stub)]=stub
rom[15*8192+256:15*8192+512]=loader.ljust(256,b'\xea')
rom[15*8192+1024:15*8192+1024+len(records)]=records
footer=bytes([0x8d,0x0f,0xd5,0x4c,0,0xa0,0xea,0xea,0xea,0x60,0xf0,0xbf,0,4,0xf9,0xbf])
for i in range(16):rom[i*8192+8176:(i+1)*8192]=footer
(B/'Phoenix-XL.car').write_bytes(b'CART'+struct.pack('>III',41,sum(rom)&0xffffffff,0)+rom)
(B/'Phoenix-XL.rom').write_bytes(rom)
print('128K AtariMax cartridge assembled;',page,'RAM pages')
