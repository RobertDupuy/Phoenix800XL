"""ROM-faithful Phoenix presentation, lettered for ANTIC 4.

The source VRAM tile maps retain the arcade artwork and composition. Every
printed character is read from the original 1980 ROM's text records; only
its bitmap is replaced by the independently drawn 5x7 alphabet below.
40 ANTIC 4 columns provide 160 color pixels, allowing all 26 arcade columns
at six pixels per character without abbreviating or inventing text.
"""
from pathlib import Path
from collections import Counter
import json
R=Path(__file__).resolve().parents[1]
FONT={
'A':['01110','10001','10001','11111','10001','10001','10001'],
'B':['11110','10001','10001','11110','10001','10001','11110'],
'C':['01111','10000','10000','10000','10000','10000','01111'],
'D':['11110','10001','10001','10001','10001','10001','11110'],
'E':['11111','10000','10000','11110','10000','10000','11111'],
'F':['11111','10000','10000','11110','10000','10000','10000'],
'G':['01111','10000','10000','10111','10001','10001','01111'],
'H':['10001','10001','10001','11111','10001','10001','10001'],
'I':['11111','00100','00100','00100','00100','00100','11111'],
'J':['00111','00010','00010','00010','10010','10010','01100'],
'K':['10001','10010','10100','11000','10100','10010','10001'],
'L':['10000','10000','10000','10000','10000','10000','11111'],
'M':['10001','11011','10101','10101','10001','10001','10001'],
'N':['10001','11001','11001','10101','10011','10011','10001'],
'O':['01110','10001','10001','10001','10001','10001','01110'],
'P':['11110','10001','10001','11110','10000','10000','10000'],
'Q':['01110','10001','10001','10001','10101','10010','01101'],
'R':['11110','10001','10001','11110','10100','10010','10001'],
'S':['01111','10000','10000','01110','00001','00001','11110'],
'T':['11111','00100','00100','00100','00100','00100','00100'],
'U':['10001','10001','10001','10001','10001','10001','01110'],
'V':['10001','10001','10001','10001','10001','01010','00100'],
'W':['10001','10001','10001','10101','10101','10101','01010'],
'X':['10001','10001','01010','00100','01010','10001','10001'],
'Y':['10001','10001','01010','00100','00100','00100','00100'],
'Z':['11111','00001','00010','00100','01000','10000','11111'],
'0':['01110','10001','10011','10101','11001','10001','01110'],
'1':['00100','01100','00100','00100','00100','00100','01110'],
'2':['01110','10001','00001','00010','00100','01000','11111'],
'3':['11110','00001','00001','01110','00001','00001','11110'],
'4':['00010','00110','01010','10010','11111','00010','00010'],
'5':['11111','10000','10000','11110','00001','00001','11110'],
'6':['01110','10000','10000','11110','10001','10001','01110'],
'7':['11111','00001','00010','00100','01000','01000','01000'],
'8':['01110','10001','10001','01110','10001','10001','01110'],
'9':['01110','10001','10001','01111','00001','00001','01110'],
' ':['00000']*7,'/':['00001','00001','00010','00100','01000','10000','10000'],
'-':['00000','00000','00000','11111','00000','00000','00000'],
':':['00000','00100','00100','00000','00100','00100','00000'],
'.':['00000']*6+['00100'],
}

FONT.update({
 '[':['01110','01000','01000','01000','01000','01000','01110'],
 ']':['01110','00010','00010','00010','00010','00010','01110'],
 '*':['00000','10101','01110','11111','01110','10101','00000'],
 '?':['01110','10001','00001','00010','00100','00000','00100'],
 '©':['01110','10001','10111','10101','10111','10001','01110'],
})
CODES={0:' ',**{i+1:c for i,c in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ')},
       **{0x20+i:str(i) for i in range(10)},
       0x1b:'[',0x1c:']',0x1f:'*',0x2a:'.',0x2b:'-',0x2f:'?',0x7e:'©'}
ROM=(R/'reference/program.rom').read_bytes()
GFX=(R/'reference/graphics.rom').read_bytes()
PALETTE=json.loads((R/'reference/palette-rgb.json').read_text())
TARGET=[(0,0,0),(45,185,215),(220,65,135),(245,205,65),(240,240,240)]
# Two layers, 256 original tiles/layer, monitor already rotated upright.
TILES=[]
for layer in range(2):
    group=[]
    for n in range(256):
        tile=[[0]*8 for _ in range(8)]
        for line in range(8):
            lo=GFX[layer*4096+n*8+line]
            hi=GFX[layer*4096+2048+n*8+line]
            for x in range(8):tile[x][7-line]=((lo>>x)&1)|(((hi>>x)&1)<<1)
        group.append(tile)
    TILES.append(group)

def color(layer,tile,pixel):
    if not pixel:return 0
    rgb=PALETTE[(32 if layer else 0)|(pixel<<3)|(tile>>5)]
    return min(range(5),key=lambda i:sum((rgb[j]-TARGET[i][j])**2 for j in range(3)))

def ink(code):
    # Arcade letters are cyan, digits and hyphens red, full stops white.
    if 0x20<=code<=0x29 or code in (0x2b,0x2f):return 2
    if code==0x2a:return 4
    if code==0x7e:return 2
    return 1

def blank():return [[0]*160 for _ in range(192)]

def paint_char(p,code,col,y):
    x=2+col*6
    if code==0x7f:
        # Original spare-ship icon; do not replace it with an invented label.
        for dy in range(7):
            for dx in range(5):
                v=TILES[1][code][dy*8//7][dx*8//5]
                if v:p[y+dy][x+dx]=min(color(1,code,v),3)
        return
    c=CODES.get(code)
    assert c is not None,hex(code)
    for dy,row in enumerate(FONT[c]):
        for dx,v in enumerate(row):
            if v=='1':p[y+dy][x+dx]=ink(code)

def text_record(p,address,y,manifest,clear=True):
    data=ROM[address+6:address+32]
    if clear:
        for yy in range(y,y+8):p[yy]=[0]*160
    for col,code in enumerate(data):paint_char(p,code,col,y)
    manifest.append(dict(rom=f'{address:04X}',source_y=ROM[address+1]&31,
                         x=2,y=y,advance=6,bytes=list(data),
                         text=''.join('SHIP' if c==0x7f else CODES[c] for c in data)))

def graphics(p,vram,table=False):
    # Preserve original art; text tiles are replaced separately at readable
    # line positions. Table images move with their corresponding score line.
    fg=vram[:832];bg=vram[832:]
    for sy in range(256):
        if sy%4==3:continue
        dy=(sy//4)*3+sy%4
        if table and sy>=14*8:dy+=8
        if dy>=192:continue
        for sx in range(208):
            if sx%4==3:continue
            dx=2+(sx//4)*3+sx%4
            a=(25-sx//8)*32+sy//8
            f=fg[a];b=bg[a]
            fv=0 if f in CODES or f==0x7f else TILES[1][f][sy%8][sx%8]
            bv=TILES[0][b][sy%8][sx%8]
            value=color(1,f,fv) if fv else color(0,b,bv)
            p[dy][dx]=min(value,3)

def encode(p):
    fonts=bytearray(6144);screen=bytearray(960);counts=[]
    for band in range(6):
        # HUD cells are intentionally independent so runtime score updates
        # never alter a shared glyph. Row 3 stays empty (glyph 120).
        glyphs=[] if band else [bytes(8)]*120
        for rr in range(4):
            row=band*4+rr
            for col in range(40):
                pix=[p[y][x] for y in range(row*8,row*8+8) for x in range(col*4,col*4+4)]
                assert not (3 in pix and 4 in pix),(band,row,col,'gold and white share cell')
                g=bytes(sum(min(p[row*8+yy][col*4+xx],3)<<(6-xx*2) for xx in range(4)) for yy in range(8))
                if band==0 and rr<3:
                    code=rr*40+col;glyphs[code]=g
                elif band==0:
                    assert g==bytes(8),'fourth row is reserved blank'
                    code=120
                    if len(glyphs)==120:glyphs.append(g)
                else:
                    if g not in glyphs:glyphs.append(g)
                    code=glyphs.index(g)
                assert code<128,(band,len(glyphs))
                screen[row*40+col]=code|(128 if 4 in pix else 0)
        counts.append(len(glyphs))
        for code,g in enumerate(glyphs):fonts[band*1024+code*8:band*1024+code*8+8]=g
    return fonts+screen,counts

def main():
    # Visible FG and BG tile bytes captured from the unmodified arcade-state
    # renderer: Counter98=01A0 score table, 03C0 title, and one/two-credit prompt.
    # No machine-code, input state, unused RAM, or code from another Atari port.
    raw=(R/'assets/arcade-presentation-vram.bin').read_bytes()
    assert len(raw)==4*1664
    pages={8:('score-table',raw[:1664]),9:('title',raw[1664:3328]),
           10:('one-credit',raw[3328:4992]),11:('two-credits',raw[4992:]),
           12:('game-over',bytes(1664))}
    manifest={}
    for bank,(name,vram) in pages.items():
        p=blank();lines=[]
        graphics(p,vram,table=bank==8)
        # Preserve the arcade's three-part score header; no added wave/shield UI.
        for y in range(32):p[y]=[0]*160
        for addr,y in [(0x1800,0),(0x1820,8),(0x1840,16)]:text_record(p,addr,y,lines)
        if bank==8:
            positions=[(0x1860,32),(0x1880,48),(0x18a0,64),(0x18c0,88),
                       (0x18e0,104),(0x1900,122),(0x1920,140),(0x1940,158)]
            # Text and examples share a row. Clear only its textual horizontal
            # portion, keeping the original bird images to the left.
            for addr,y in positions:
                if addr>=0x18e0:
                    for yy in range(y,y+7):
                        for xx in range(2+8*6,160):p[yy][xx]=0
                    text_record(p,addr,y,lines,clear=False)
                else:text_record(p,addr,y,lines)
        elif bank in (10,11):
            text_record(p,0x19c0,48,lines)
            text_record(p,0x19e0 if bank==10 else 0x1ba0,72,lines)
            # The ROM shows the current coin count; seed correct value before
            # the platform's live score/coin updater takes over.
            for yy in range(16,24):
                for xx in range(2+15*6,2+16*6):p[yy][xx]=0
            paint_char(p,0x20+bank-9,15,16)
        if bank==12:text_record(p,0x1a00,48,lines)
        if bank in (8,9,12):
            for addr,y in [(0x1960,168),(0x1980,176),(0x19a0,184)]:text_record(p,addr,y,lines)
        binary,counts=encode(p)
        (R/f'assets/presentation-{bank}.bin').write_bytes(binary)
        manifest[str(bank)]={'name':name,'size':[160,192],'font_glyph_counts':counts,'lines':lines}
        try:
            from PIL import Image
            im=Image.new('RGB',(160,192));im.putdata([TARGET[c] for row in p for c in row])
            im.resize((640,576),Image.Resampling.NEAREST).save(R/f'build/arcade-readable-{name}.png')
        except ImportError:pass
    (R/'assets/presentation-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    layout=bytes((0 if c<3 or c>=29 else 1+(r%4)*26+c-3) for r in range(24) for c in range(32))
    (R/'assets/game-screen.bin').write_bytes(layout)
    print('Built ROM-faithful table, title, 1/2-credit and game-over pages in 40-column ANTIC 4.')

if __name__=='__main__':main()
