from pathlib import Path
R=Path(__file__).resolve().parents[1]
s=['.section .platform,"ax",@progbits','.global draw_dispatch','draw_dispatch:',' jmp (0xd6)']
# Four possible alignments of a six-line source tile in eight-line ANTIC glyphs.
for phase in range(8):
 for kind in range(4):
  s.append(f'draw_p{phase}_{kind}:')
  for k,sr in enumerate([0,1,3,4,5,7]):
   split=2 if kind==1 else 4 if kind==2 else 6
   ptr=0xcc if k>=split else 0xca;dy=k-split if k>=split else k
   s.extend([f' ldy 0x{0xd2 if sr+phase>=8 else 0xd1:02x}',f' lda 0x{0xa800+((sr+phase)%8)*256:04x},y',' ldy 0xd5',f' ora 0x{0xb800+sr*256:04x},y',f' and 0x{0xb000+sr*256:04x},x',f' ora 0x{0xa000+sr*256:04x},x',f' ldy #{dy}',f' sta (0x{ptr:02x}),y'])
  s.append(' rts')
for name in ['lo','hi']:
 s.extend([f'.global draw_{name}',f'draw_{name}:','.byte '+','.join(f'draw_p{p}_{k}@{"mos16lo" if name=="lo" else "mos16hi"}' for p in range(8) for k in range(4))])
def addr(y):return 0x8000+(y//32)*1024+(((y//8)%4)*26+1)*8+(y%8)
for num in [0,1]:
 vals=[addr(r*6+(2 if r%4==1 else 4 if r%4==2 else 0)) for r in range(32)] if num else [addr(r*6) for r in range(32)]
 for part in ['lo','hi']:
  s.extend([f'.global dest{num}_{part}',f'dest{num}_{part}:','.byte '+','.join(str(v&255 if part=='lo' else v>>8) for v in vals)])
(R/'src/draw_kernel.S').write_text('\n'.join(s)+'\n')
