#include <stdio.h>
#include <stdint.h>
#include "sound.h"
int main(void){
 int16_t out[1024];
 for(int ch=0;ch<2;ch++)for(int v=0;v<64;v++){
  sound_init();sound_set_frame_sample_index(0);
  sound_write_control_a(ch==0?v:15);sound_write_control_b(ch==1?v:15);
  for(int f=0;f<24;f++){int n=sound_render_frame(out);if(f>=16)fwrite(out,2,n,stdout);}
 }
 return 0;
}
