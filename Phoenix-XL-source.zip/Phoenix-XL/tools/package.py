"""Create the deliverable and a self-contained, reproducible source archive."""
from pathlib import Path
import shutil,zipfile,hashlib,json
R=Path(__file__).resolve().parents[1];out=R/'release';out.mkdir(exist_ok=True)
stage=R/'build/package/Phoenix-XL'
if stage.exists():shutil.rmtree(stage)
stage.mkdir(parents=True)
def copy(src,dst=None):
 target=stage/(dst or str(src));target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/src,target)
for folder in ['src','assets','docs','tools','vendor']:
 for p in (R/folder).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:
   if p.relative_to(R).as_posix() in ['src/pm.c','src/memory.c','src/hud.c','tools/mame_reference.lua']:continue
   copy(p.relative_to(R))
copy(Path('README.md'))
for p in sorted((R/'tests').glob('*')):
 if p.is_file() and p.name not in ['boss_completion.py','perf.py']:
  copy(p.relative_to(R))
for name in ['allwaves.ram.gz','allwaves.csv','cfg/default.cfg','cfg/phoenix.cfg']:
 copy(Path('tests/mame')/name)
for name in ['Phoenix-XL.car','game.bin.elf']:
 copy(Path('build/revision4-baseline')/name)
for name in ['program.rom','graphics.rom','proms.rom','palette-rgb.json','phoenix-arcade-z80.asm','phoenix.cpp','phoenix_v.cpp','phoenix_a.cpp','tms36xx.cpp']:
 copy(Path('reference')/name)
for p in (R/'reference/roms/phoenix').iterdir():
 if p.is_file():copy(p.relative_to(R))
ref=R/'reference/hhi/c-phoenix'
names={p.name for p in (R/'src/arcade').glob('*.c')}
names.update(['sound.c','sound_discrete.c','tms36xx.c','mame_lofi_resampler.c'])
names.update(p.name for p in ref.glob('*.h') if p.name not in ['phoenix_render_assets.h'])
for name in sorted(names):copy(Path('reference/hhi/c-phoenix')/name)
for name in ['Phoenix-XL.car','Phoenix-XL.rom','Phoenix-XL-preview.mp4']:
 shutil.copyfile(R/'build'/name,out/name)
 if name.endswith(('.car','.rom')):copy(Path('build')/name,name)
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.name in ['Phoenix-XL.car','Phoenix-XL.rom','Phoenix-XL-preview.mp4']}
(stage/'SHA256SUMS.txt').write_text(''.join(v+'  '+k+'\n' for k,v in hashes.items()))
with zipfile.ZipFile(out/'Phoenix-XL-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(stage.rglob('*')):
  if p.is_file():
   info=zipfile.ZipInfo(str(p.relative_to(stage.parent)),(2026,10,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
   z.writestr(info,p.read_bytes())
print(json.dumps({p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(out.iterdir()) if p.is_file()},indent=2))
