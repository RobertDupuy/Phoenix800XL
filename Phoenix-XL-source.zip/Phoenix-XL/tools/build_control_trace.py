"""Build a separate CPU-observing harness; leave game binaries untouched."""
from pathlib import Path
import os,subprocess,shutil
R=Path(__file__).resolve().parents[1];B=R/'build/control-observer';B.mkdir(parents=True,exist_ok=True)
root=Path(os.environ.get('ATARI800_SOURCE','/workspace/scratch/acd7af60810a/research/atari800')).resolve()
if not (root/'src/libatari800.a').exists():
 root=R/'build/atari800-test-source'
 if not (root/'src/libatari800.a').exists():subprocess.run(['python3',str(R/'tools/build_tests.py')],check=True)
src=root/'src';s=(src/'cpu.c').read_text()
needle='\twhile (ANTIC_xpos < ANTIC_xpos_limit) {'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n\t\textern void control_trace_instruction(unsigned short,unsigned char,unsigned char,unsigned char,unsigned char);\n\t\tcontrol_trace_instruction(GET_PC(),A,X,Y,S);',1)
(B/'cpu.c').write_text(s)
cc=os.environ.get('CC','gcc')
subprocess.run([cc,'-w','-O2','-I'+str(src),'-c',str(B/'cpu.c'),'-o',str(B/'cpu.o')],check=True)
shutil.copyfile(src/'libatari800.a',B/'libatari800.a')
subprocess.run(['ar','r',str(B/'libatari800.a'),str(B/'cpu.o')],check=True)
subprocess.run([cc,'-w','-O2','-DCONTROL_TRACE','-I'+str(src),'-I'+str(R/'tests'),str(R/'tests/emulator.c'),str(R/'tests/control_observer.c'),str(R/'tests/profile_stubs.c'),str(B/'libatari800.a'),'-lz','-lm','-o',str(R/'build/control-trace-emulator')],check=True)
print(R/'build/control-trace-emulator')
