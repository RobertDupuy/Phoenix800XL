local m=manager.machine
local cpu=m.devices[':maincpu']
local mem=cpu.spaces['program']
local frame=0
local csv=io.open('tests/mame/allwaves.csv','w')
local ram=io.open('tests/mame/allwaves.ram','wb')
csv:write('frame,pc,mode,state,level,aliens,birds,lives,x\n')
local stages={[1500]=2,[2800]=4,[4100]=6,[5400]=8,[7100]=0x10}
emu.register_frame_done(function()
 frame=frame+1
 for tag,p in pairs(m.ioport.ports) do
  for name,f in pairs(p.fields) do
   if name=='Coin 1' then f:set_value(frame==60 and 1 or 0) end
   if name=='1 Player Start' then f:set_value(frame>=90 and frame<94 and 1 or 0) end
   if name=='P1 Button 1' then f:set_value(frame%8<4 and 1 or 0) end
   if name=='P1 Button 2' then f:set_value(frame%400==100 and 1 or 0) end
   if name=='P1 Left' then f:set_value(frame%360>=180 and 1 or 0) end
   if name=='P1 Right' then f:set_value(frame%360<180 and 1 or 0) end
  end
 end
 if stages[frame] then
  local level=stages[frame]
  mem:write_u8(0x43b8,level);mem:write_u8(0x43a4,1);mem:write_u8(0x43a5,128)
  mem:write_u8(0x43a2,1);mem:write_u8(0x4390,3);mem:write_u8(0x439c,0)
  mem:write_u8(0x43ba,(level==4 or level==6) and 0 or 16)
  mem:write_u8(0x43bb,(level==4 or level==6) and 8 or 0)
 end
 if frame==6500 then
  local vals={[0x43b8]=11,[0x43a4]=3,[0x43ba]=16,[0x43c0]=0x9c,[0x43c4]=8,[0x43c6]=92,[0x43c7]=56,[0x43b9]=32,[0x49ca]=0x61,[0x49c9]=0x70}
  for a,v in pairs(vals) do mem:write_u8(a,v) end
 end
 ram:write(mem:read_range(0x4000,0x4bff,8));ram:flush()
 csv:write(string.format('%d,%04x,%d,%d,%d,%d,%d,%d,%d\n',frame,cpu.state['PC'].value,mem:read_u8(0x43a2),mem:read_u8(0x43a4),mem:read_u8(0x43b8),mem:read_u8(0x43ba),mem:read_u8(0x43bb),mem:read_u8(0x4390),mem:read_u8(0x43c2)));csv:flush()
 if frame>=8300 then ram:close();csv:close();m:exit() end
end)
