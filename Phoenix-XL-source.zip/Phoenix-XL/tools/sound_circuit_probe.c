/* Independent timing oracle: run the existing sample-domain circuit model,
   count the actual 555 output transitions, then apply its LS163 divider. */
#include <stdio.h>
#include <math.h>
#include "sound_discrete.h"
int main(void) {
 SoundDiscrete sd;
 puts("case,frame,a,b,hz_a,hz_b");
 for (int c=0;c<5;c++) {
  sound_discrete_init(&sd);
  long sample=0;
  for (int f=0;f<700;f++) {
   int a=c<4?(c*16+13):15;
   int b=c<4?15:((f/40&1)?0x34:0x24);
   long end=(long)((f+1)*SOUND_DISCRETE_SAMPLE_RATE/61.03515625);
   long count_a=0,count_b=0,n=end-sample;
   for (;sample<end;sample++) {
    sound_discrete_step(&sd,a,b);
    count_a+=(int)sd.effect2_node39.last_output;
    count_b+=(int)sd.effect1_node21.last_output;
   }
   printf("%d,%d,%d,%d,%.6f,%.6f\n",c,f,a,b,
     count_a*(double)SOUND_DISCRETE_SAMPLE_RATE/n/2/(16-(a&15)),
     count_b*(double)SOUND_DISCRETE_SAMPLE_RATE/n/2/(16-(b&15)));
  }
 }
 return 0;
}
