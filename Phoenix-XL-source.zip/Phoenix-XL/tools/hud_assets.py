"""Readable live arcade HUD: original 26 columns and three source tile rows.

Bank 14: A000 blank 1KB font, A700 120-byte screen map, A800 128 glyphs
with two pre-shifted 16-byte phases, B800 four 78-byte address planes.
Pixels are generated once; runtime replaces only changed source cells.
"""
from pathlib import Path
from presentation_assets import blank, paint_char, CODES
R=Path(__file__).resolve().parents[1]
A=R/'assets'
A.mkdir(exist_ok=True)
(A/'hud-font.bin').write_bytes(bytes(1024))
(A/'hud-map.bin').write_bytes(bytes(range(120)))
glyphs=bytearray()
for code in range(128):
    p=blank()
    if code in CODES or code==0x7f:
        paint_char(p,code,0,0)
    # paint_char starts at x=2. Include the sixth blank spacing pixel so
    # overwriting a wider prior letter or a flashing score leaves no debris.
    pixels=[p[y][2:8] for y in range(8)]
    for phase in (0,2):
        rows=[]
        for row in pixels:
            row=[0]*phase+row+[0]*(2-phase)
            rows.append([sum(min(row[x+i],3)<<(6-i*2) for i in range(4)) for x in (0,4)])
        glyphs.extend(rows[y][half] for half in (0,1) for y in range(8))
assert len(glyphs)==4096
(A/'hud-glyphs.bin').write_bytes(glyphs)
# Three successive HUD rows share one source-column pointer at runtime.
# Source arcade columns run right-to-left in VRAM; the Atari display runs
# left-to-right. All 78 source cells are retained without rewriting RAM.
sources=[];destinations=[]
for col in range(26):
    for row in range(3):
        sources.append(0x1000+(25-col)*32+row)
        destinations.append(0x1400+(row*40+(2+col*6)//4)*8)
pointers=bytes([a&255 for a in sources]+[a>>8 for a in sources]+
               [a&255 for a in destinations]+[a>>8 for a in destinations])
assert len(pointers)==312
(A/'hud-pointers.bin').write_bytes(pointers)
