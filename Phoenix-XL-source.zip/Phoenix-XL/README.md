# Phoenix XL — revision 5

A playable native 6502 port of the 1980 Phoenix arcade game for the Atari 800XL.
128 KiB AtariMax cartridge, PAL/NTSC, ANTIC 4 character graphics, five screen
colours, standard GTIA and one POKEY. No VBXE or expanded system RAM is needed.

Revision 5 fixes verified sound stalls during rendering and restores continuous
pitch modulation to the arcade effects. The reported indefinite loss of held
left/right input has **not** been reproduced or fixed. Direct joystick polling
and the original movement rules are unchanged. See `docs/CHANGES-v5.md` and
`docs/TEST_REPORT.md` for the evidence and remaining limitations.

## Play

Open `Phoenix-XL.car` as a cartridge in an Atari XL emulator with 64 KiB RAM.
Its CART header selects **type 41: AtariMax 128 KiB / 1 Mbit**. BASIC is disabled
by the cartridge. For a compatible physical cartridge programmer, use the
131,072-byte `Phoenix-XL.rom`, without the 16-byte CART header.

| Control | Action |
| --- | --- |
| Joystick port 1, left/right | Move |
| Fire | Shoot; press again for each shot |
| Joystick down | Shield |
| Fire or START at the title | Start a one-player game |
| SELECT | Add a credit |
| OPTION with two credits | Start alternating two-player play |
| RESET | Restart the cartridge |

Both players use joystick port 1. Allow the original introductory formation
sequence to finish before movement begins. Shield activation, temporary
movement lockout and cooldown follow the original counters.

The complete cycle is present: the two small-alien waves, both growing-bird
waves, and the mothership with destructible armour, rotating protection and
the central pilot. Destroying the pilot runs the explosion and bonus sequence
and starts the next round. Later rounds use the original progression tables.
The default switches give three lives and the original 3,000/30,000 bonus
settings; the original threshold comparison is retained.

Revision 4 reads the current left/right joystick pins on every game tick and
uses them directly. Direction has no change detection, previous-direction
state, last-pressed resolver, latch or repeat timer. If both pins are active,
both are passed to the original movement routine, which gives left priority.
See `docs/CHANGES-v4.md` for this focused input change and its checks.

The revision-3 arcade presentation remains: SCORE1 / HI-SCORE / SCORE2,
coin/life indicators, SCORE AVERAGE TABLE with original bird examples,
PHOENIX artwork, copyright, start prompts and GAME OVER, using readable 5×7
text. Its corrected ship/projectile visibility is also retained.

## Fidelity and limits

The game mechanics are translated from the arcade ROM, using its original
tables, BCD scores, collision cells, movement, shield rules, sound commands,
enemy behavior and state transitions. The original arcade program was loaded
in MAME and disassembled. Sampled game-state comparisons are documented in
`docs/TEST_REPORT-v3.md`. The current input checks are in
`docs/TEST_REPORT.md`.

The gameplay display adapts the portrait arcade picture to the Atari: eight
source pixels become four multicolour pixels horizontally and six scanlines
vertically. Colours are reassigned to preserve distinct graphic details.
The HUD uses 40-column ANTIC 4 for legible 5×7 text above the 32-column game
field. The information pages also use 40 columns, retaining the original
text, artwork and composition within the Atari screen. The fonts were drawn
for this port. The HUD reads the original foreground cells, preserving both
players' scores, life/coin counts and the original score flashing. The supplied screenshots were used only as visual references
for contrast and clarity; no code, font or artwork from another Atari port
was copied. Decorative scrolling star tiles are
replaced with a sparse stationary star pattern; gameplay graphics and
collision data retain the original shapes and positions.

The music uses the original three tune sequences. A private assembly driver
advances music and sound envelopes from the vertical-blank interrupt at the
arcade clock rate, independently of drawing or a backlog in game logic.
Continuous oscillator and capacitor states replace the old single-pitch
effect lookup. Sound A's half-volume control is respected; Sound B's filtered
tone no longer selects a noise waveform. The game still supplies its original
sound commands. POKEY pitches, filter levels and noise remain approximations
of the analog circuitry.

The scheduler targets 61.035 arcade logic updates per second on both TV
standards. Rendering is adaptive and less frequent than game logic. Busy
large-bird and mothership scenes can fall below arcade speed. See the measured
rates in the test report. Verification used emulation; physical Atari and
flash-cartridge operation have not been tested.

`Phoenix-XL-preview.mp4` is a fresh revision-5 capture. It shows real emulator
output and sound, using test-only
stage-selection fixtures to show all five waves quickly. The shipping
cartridge contains no stage selection, invulnerability or test patches.

## Build

Required: Python 3, the LLVM-MOS SDK (`mos-common-clang`), and cc65's `ca65`
and `ld65`. No Python packages are required for the normal cartridge build.
The validated compiler was LLVM-MOS clang 24.0.0git, commit
`cd9145597347753c7cabd1c34d24722d4d8a8f96`; the loader used ca65 from cc65 2.19.

```sh
export LLVM_MOS=/path/to/llvm-mos
export CC65_BIN=/path/to/cc65/bin
python3 tools/build.py
```

The tools can alternatively be on PATH. Output is `build/Phoenix-XL.car` and
`build/Phoenix-XL.rom`. Generated assembler, graphics banks and sound tables
are included so rebuilding does not require downloading arcade material.
Optional regeneration with `python3 tools/rebuild_assets.py` additionally
requires a host C compiler and NumPy.

## Development checks

The package contains the exact instrumented Atari800 test sources, compressed
under `vendor/`, plus original MAME frame captures under `tests/mame/`.
The emulator is a development dependency and is not part of the cartridge.
Python 3.12+, a C compiler, make, zlib development headers and Pillow are
needed for these optional checks. FFmpeg is needed only for preview capture.

```sh
python3 tools/build_tests.py
python3 tests/native_parity.py
python3 tests/mame_parity.py
python3 tests/render_parity.py
python3 tests/controls.py
python3 tests/held_controls.py
python3 tests/presentation.py
python3 tests/hud_parity.py
python3 tests/pm_visibility.py
python3 tests/waves.py
python3 tests/ending_fixture.py
python3 tests/timing.py
python3 tools/build_control_trace.py
python3 tests/audio_interrupt.py
python3 tests/audio_circuit.py
python3 tests/input_bus_audit.py
```

`ATARI800_SOURCE` can point to an already-built copy of the supplied test
emulator. `ATARI_OS_ROM` optionally selects a local XL OS image; the test
default is Atari800's Altirra replacement OS. To regenerate the independent
arcade captures, run MAME 0.264 with `tools/mame_allwaves.lua`, the supplied
Phoenix chip set and the configuration in `tests/mame/cfg/`. The Lua script
records 8,300 frames and exits. The injected fixtures are recorded in that
script; they affect the tests only.

The held-input regression exercises 12,000 TV frames per direction on each
TV standard (48,000 total),
shield lockout, every wave's entry sequence, history-independent raw-pin
levels, both active direction pins and PIA initialization. The presentation check verifies the five ROM-backed pages,
their font and screen data, and restoration of the normal demo/game display.
The HUD check verifies replacement/erasure of adjacent 5×7 characters while
preserving the original foreground RAM.

`tests/altirra_keyboard.py` is a separate frontend check. Set `ALTIRRA_SDL`
to an AltirraSDL executable with its test-mode support. It sends SDL physical
keyboard events through the full frontend, checks PORTA and the arcade input
byte, and records the emulator and cartridge hashes. This is a Linux test;
it does not reproduce the user's host OS, keyboard settings or input profile.
The current report separates completed revision-5 checks from earlier evidence.
The revision-4 compiled cartridge/ELF in `build/revision4-baseline/` provides
the independent old-driver and sound-stall comparison for the new tests.

## Sources

- [Phoenix C translation](https://github.com/hhi/org.hhi.phoenix-arcade),
  revision `d58adc3f5fe6fd8dc3745100010eecb755f6d7ba`.
- [Computer Archeology's Phoenix disassembly](https://computerarcheology.com/Arcade/Phoenix/).
- [MAME Phoenix driver](https://github.com/mamedev/mame/blob/master/src/mame/phoenix/phoenix.cpp)
  and [sound device](https://github.com/mamedev/mame/blob/master/src/devices/sound/tms36xx.cpp).
- [LLVM-MOS](https://github.com/llvm-mos/llvm-mos-sdk),
  [cc65](https://github.com/cc65/cc65), and
  [Atari800](https://github.com/atari800/atari800).

See `docs/PORTING.md` for the implementation and `docs/THIRD_PARTY.md` for
attribution and source-license scope. No ownership or relicensing of the
original Phoenix game material is claimed.
