"""Capture the readable pages and five waves from the actual emulator."""
from check import *
import json,os,math,array

out=R/'build/preview';out.mkdir(exist_ok=True)
fps=1789772.5/(114*262)
clips=[];metrics=[]
def page_clip(e,name):
 fifo=out/f'{name}.fifo';fifo.unlink(missing_ok=True);os.mkfifo(fifo)
 silent=out/f'{name}-silent.mp4';pcm=out/f'{name}.pcm';clip=out/f'{name}.mp4'
 ff=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','384x240','-framerate',str(fps),'-i',str(fifo),'-vf','scale=768:480:flags=neighbor','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p',str(silent)])
 meta=e.cmd(f'record {fifo} {pcm}').split();rate,channels,sample=map(int,meta[:3])
 e.step(150);assert int(e.cmd('recordstop'))==150
 assert ff.wait()==0;fifo.unlink()
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(silent),'-f','s16le','-ar',str(rate),'-ac',str(channels),'-i',str(pcm),'-c:v','copy','-c:a','aac','-b:a','128k','-shortest',str(clip)],check=True)
 clips.append(clip);silent.unlink();pcm.unlink()

e=Emu();e.step(50)
for bank,name in [(8,'scores'),(9,'title')]:
 for _ in range(120):
  if e.val('presentation_bank')==bank:break
  e.step(10)
 else:raise AssertionError((bank,'page not reached'))
 e.step(16);page_clip(e,name)
e.step(20,select=1);e.step(40)
assert e.val('presentation_bank')==10
page_clip(e,'one-credit')
e.step(20,select=1);e.step(40)
assert e.val('presentation_bank')==11
page_clip(e,'two-credits');e.close()
for wave in [0,2,4,6,8]:
 e=Emu();e.step(300);e.step(20,start=1);e.step(550)
 if wave:
  for a,v in {0x13b8:wave,0x13a4:1,0x13a5:128,0x13ba:0 if wave in [4,6] else 16,0x13bb:8 if wave in [4,6] else 0,0x139c:0,0x1390:3}.items():e.cmd(f'queue {a} {v}')
  e.cmd(f'apply {L["logic_tick"]}');e.step(650)
 fifo=out/f'wave-{wave}.fifo';fifo.unlink(missing_ok=True);os.mkfifo(fifo)
 silent=out/f'wave-{wave}-silent.mp4';pcm=out/f'wave-{wave}.pcm';clip=out/f'wave-{wave}.mp4'
 ff=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','384x240','-framerate',str(fps),'-i',str(fifo),'-vf','scale=768:480:flags=neighbor','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p',str(silent)])
 meta=e.cmd(f'record {fifo} {pcm}').split();rate,channels,sample=map(int,meta[:3])
 for i in range(24):
  e.step(8,j=8 if i<12 else 4,t=i%2)
  if i==12:e.shot(f'preview-wave-{wave}')
 frames=int(e.cmd('recordstop'));e.close();assert ff.wait()==0;fifo.unlink()
 a=array.array('h');a.frombytes(pcm.read_bytes());rms=math.sqrt(sum(v*v for v in a)/len(a));peak=max(abs(v) for v in a)
 assert rms>10 and peak>100,(wave,rms,peak)
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(silent),'-f','s16le','-ar',str(rate),'-ac',str(channels),'-i',str(pcm),'-c:v','copy','-c:a','aac','-b:a','128k','-shortest',str(clip)],check=True)
 metrics.append(dict(wave=wave//2+1,frames=frames,sample_rate=rate,channels=channels,sample_bytes=sample,rms=rms,peak=peak));clips.append(clip)
 silent.unlink();pcm.unlink()
listing=out/'concat.txt';listing.write_text(''.join("file '"+str(p)+"'\n" for p in clips))
subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(listing),'-c','copy','-movflags','+faststart',str(R/'build/Phoenix-XL-preview.mp4')],check=True)
(R/'build/audio-results.json').write_text(json.dumps(metrics,indent=2));print(metrics)
