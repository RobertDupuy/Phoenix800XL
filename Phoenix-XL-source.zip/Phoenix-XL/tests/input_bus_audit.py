"""Trace every PIA write and actual movement in all five waves.

This checks a concrete alternative suggested by the user's screenshot:
whether the cartridge accidentally reconfigures the input port while playing.
It cannot determine the physical key state at a historical screenshot.
"""
from control_trace import *
from audio_interrupt import Cartridge
results=[]
for tv in ['ntsc','pal']:
 for baseline in [True,False]:
  e=Cartridge(tv,baseline)
  tag=f'input-bus-{tv}-'+('r4' if baseline else 'r5')
  port_path=R/'build'/f'{tag}.csv'
  boot_path=R/'build'/f'{tag}-boot.csv';e.cmd(f'portwatch {boot_path}')
  e.step(300);e.step(20,t=1);e.step(550);e.cmd('save 0')
  e.cmd('portstop');e.cmd(f'portwatch {port_path}')
  waves=[]
  for wave in [0,2,4,6,8]:
   e.cmd('load 0')
   if wave:
    fixture={0x13b8:wave,0x13a4:1,0x13a5:128,0x13ba:0 if wave in (4,6) else 16,
             0x13bb:8 if wave in (4,6) else 0,0x139c:0,0x1390:3}
    for a,v in fixture.items():e.cmd(f'queue {a} {v}')
    e.cmd(f'apply {e.labels["logic_tick"]}')
   path=R/'build'/f'{tag}-wave{wave}.trace.csv'
   if not baseline:e.cmd('controltrace '+str(path)+' '+' '.join(map(str,addresses())))
   max_sound_gap=gap=0;previous=e.word('audio_ticks') if not baseline else 0
   for f in range(1500):
    # Long constant holds, reversals, and independent fire/shield activity.
    direction=8 if (f//173)%2 else 4
    if f in range(630,634):direction|=2
    e.step(1,j=direction,t=f%19<3)
    pia=bytes.fromhex(e.cmd('pia'))
    assert pia[0]&0x3f==0x3c and pia[1]==255,(tv,baseline,wave,f,pia.hex())
    if not baseline:
     current=e.word('audio_ticks');gap=gap+1 if current==previous else 0
     max_sound_gap=max(max_sound_gap,gap);previous=current
   info=dict(wave=wave//2+1,tv_frames=1500)
   if not baseline:
    e.cmd('controlstop');r=analyse(path)
    assert not r['failures'],(tv,wave,r['failures'][:2])
    records=list(csv.DictReader(path.open()))
    starts=[int(v['cpu_clock']) for v in records if v['event']=='audio_enter']
    ends=[int(v['cpu_clock']) for v in records if v['event']=='audio_exit']
    tv_cycles=114*(262 if tv=='ntsc' else 312)
    start_gap=max(b-a for a,b in zip(starts,starts[1:]))
    end_gap=max(b-a for a,b in zip(ends,ends[1:]))
    # Completion can cross a TV-frame boundary when an envelope starts.
    # Measure the actual CPU-clock interval instead of mistaking that for
    # a missing VBI service. No two-frame render-induced gap is allowed.
    assert start_gap<=tv_cycles+500 and end_gap<=tv_cycles+2000,(tv,wave,start_gap,end_gap)
    info.update(movement_calls=r['movement_calls'],pm_calls=r['pm_calls'],
                audio_start_max_cycles=start_gap,audio_end_max_cycles=end_gap,tv_cycles=tv_cycles,
                completion_boundary_gaps=max_sound_gap,worst_active_gaps={k:v['tv_frames'] for k,v in r['worst_active_gaps'].items()})
   waves.append(info)
  e.cmd('portstop');e.close()
  writes=list(csv.DictReader(port_path.open()))
  expected=[(0xd301,0xfe),(0xd302,0x38),(0xd300,0),(0xd302,0x3c)]
  actual=[(int(row['address']),int(row['value'])) for row in writes]
  boot=[(int(row['address']),int(row['value'])) for row in csv.DictReader(boot_path.open())]
  # The OS initializes PIA before the cartridge takes ownership. Inspect
  # the final takeover separately from the zero-write gameplay interval.
  assert boot[-4:]==expected,(tag,boot)
  assert actual==[],(tag,actual)
  result=dict(tv=tv,baseline=baseline,boot_pia_writes=boot,gameplay_pia_writes=0,waves=waves)
  results.append(result);print(result,flush=True)
(R/'build/input-bus-audit-results.json').write_text(json.dumps(results,indent=2)+'\n')
