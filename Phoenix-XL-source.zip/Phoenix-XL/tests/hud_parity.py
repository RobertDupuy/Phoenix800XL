"""Exercise native HUD character replacement against original tile positions.
The 78 independent source cells share Atari glyph bytes, so transitions must
clear every old glyph pixel without erasing an adjacent source character.
"""
from check import *
import sys,json,random,hashlib
sys.path.insert(0,str(R/'tools'))
from presentation_assets import blank,paint_char

codes=[0,*range(1,27),*range(0x20,0x2a),0x2b,0x7f]
rng=random.Random(9800)
e=Emu();e.step(300)
e.cmd('io 54286 0')
def invoke(name):
 e.cmd(f'rendercall {L[name]}');e.step(12)
 assert int(e.cmd('pc'))==0x07e0,(name,e.cmd('pc'))
invoke('hud_load')
assert e.mem(0x0540,120)==bytes(range(120))
checks=0
for case in range(12):
 source=[rng.choice(codes) for _ in range(78)] if case else [0]*78
 for col in range(26):
  for row in range(3):e.poke(0x1000+(25-col)*32+row,source[col*3+row])
 before=e.mem(0x1000,1024)
 invoke('hud_update')
 assert e.mem(0x1000,1024)==before,'HUD modified original foreground/game RAM'
 p=blank()
 for col in range(26):
  for row in range(3):paint_char(p,source[col*3+row],col,row*8)
 expected=bytearray(1024)
 for row in range(3):
  for col in range(40):
   for y in range(8):
    expected[(row*40+col)*8+y]=sum(min(p[row*8+y][col*4+x],3)<<(6-x*2) for x in range(4))
 assert e.mem(0x1400,1024)==expected,case
 checks+=78
 # Unchanged calls must neither alter the font nor the original RAM.
 invoke('hud_update')
 assert e.mem(0x1400,1024)==expected,('unchanged',case)
 assert e.mem(0x1000,1024)==before
e.close()
result=dict(cartridge_sha256=hashlib.sha256((R/'build/Phoenix-XL.car').read_bytes()).hexdigest(),native_source_cell_checks=checks,unchanged_passes=12,source_ram_preserved=True)
print(json.dumps(result,indent=2))
(R/'build/hud-parity-results.json').write_text(json.dumps(result,indent=2)+'\n')
