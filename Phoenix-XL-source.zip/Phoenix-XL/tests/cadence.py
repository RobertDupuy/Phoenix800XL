from check import *
for tv in ['ntsc','pal']:
 e=Emu(tv);e.step(250);e.step(20,start=1);e.step(300)
 for i in range(8):
  a=int.from_bytes(e.mem('logic_tick',2),'little');b=e.val('render_tick');e.step(300,j=4 if i%2 else 8,t=i%2);print(tv,i,'logic',int.from_bytes(e.mem('logic_tick',2),'little')-a,'render',(e.val('render_tick')-b)&255,'due',e.val('game_due'),'max',e.val('missed_frames'),'level',e.val(0x13b8),'lives',e.val(0x1390),flush=True)
 e.shot(tv+'-cadence');e.close()
