from pathlib import Path
import subprocess,re,os,shutil
R=Path(__file__).resolve().parents[1]
def labels():
 nm=shutil.which('llvm-nm') or str(Path(os.environ.get('LLVM_MOS',R.parent/'toolchain/llvm-mos'))/'bin/llvm-nm')
 out=subprocess.check_output([nm,str(R/'build/game.bin.elf')],text=True)
 return {m[3]:int(m[1],16) for l in out.splitlines() if (m:=re.match(r'^([0-9a-fA-F]+)\s+(\w)\s+(.+)',l))}
L=labels()
class Emu:
 def __init__(self,tv='ntsc'):
  self.p=subprocess.Popen([str(R/'build/emulator'),'-'+tv,str(R/'build/Phoenix-XL.car')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=open(R/'build/emulator.log','w'),text=True,bufsize=1)
  while True:
   s=self.p.stdout.readline().strip()
   if s=='READY':break
   if not s and self.p.poll()!=None:raise RuntimeError((R/'build/emulator.log').read_text())
 def cmd(self,s):
  self.p.stdin.write(s+'\n');self.p.stdin.flush();r=self.p.stdout.readline().strip()
  if not r:raise RuntimeError((R/'build/emulator.log').read_text())
  return r
 def step(self,n,j=0,t=0,start=0,select=0,option=0):return self.cmd('step '+' '.join(str(int(v)) for v in [n,j,t,start,select,option]))
 def mem(self,a,n=1):return bytes.fromhex(self.cmd(f'mem {L[a] if isinstance(a,str) else a} {n}'))
 def val(self,a):return self.mem(a)[0]
 def poke(self,a,v):return self.cmd(f'poke {L[a] if isinstance(a,str) else a} {v}')
 def shot(self,n):
  p=R/'build'/f'{n}.ppm';self.cmd(f'shot {p}');from PIL import Image
  q=p.with_suffix('.png');Image.open(p).save(q);return q
 def close(self):self.cmd('quit') if False else self.p.terminate()
if __name__=='__main__':
 e=Emu();e.step(200);print('PC',e.cmd('pc'),'state',e.mem(0x1380,64).hex(),'ticks',e.val('frame_tick'),e.val('render_tick'));e.shot('boot')
 e.step(2,select=1);e.step(5);e.step(2,start=1);e.step(350)
 print('game',e.mem(0x1380,64).hex(),'ticks',e.val('frame_tick'),e.val('render_tick'));e.shot('game');e.close()
