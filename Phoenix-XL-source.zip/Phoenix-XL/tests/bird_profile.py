from check import *
e=Emu();e.step(300);e.step(20,start=1);e.step(350)
for a,v in {0x13b8:5,0x13a4:2,0x13ba:0,0x13bb:8,0x139c:0,0x1390:3}.items():e.cmd(f'queue {a} {v}')
e.cmd(f'apply {L["logic_tick"]}');e.step(120)
e.cmd('profile_start');a=e.val('render_tick');logic=int.from_bytes(e.mem('logic_tick',2),'little');e.step(300);print('logic',int.from_bytes(e.mem('logic_tick',2),'little')-logic,'renders',(e.val('render_tick')-a)&255,'state',e.val(0x13a4),'birds',e.val(0x13bb));e.cmd('profile_dump '+str(R/'build/profile.csv'));e.shot('bird-profile');e.close()
exec(open(R/'tests/profile.py').read().split('from collections')[1].join(['from collections','']))
