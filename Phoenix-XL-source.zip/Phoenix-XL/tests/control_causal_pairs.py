"""Same-savestate held/reversed/repressed branches on the unchanged cartridge.

A candidate needs 120 consecutive TV frames of stationary *interior* ship
position during active play. Edge clamps, shield, death and intros are counted
separately. A short renderer pause is not accepted as the reported failure.
"""
from control_trace import TraceEmu,addresses,analyse,R,L
import hashlib,json,collections,zlib,csv

def sample(e):
 m=e.mem(0x1380,80)
 active=m[34]==1 and m[36]==3 and (m[56]&15)in(1,3,5,7,11) and bool(m[64]&8)
 x=m[66]
 return dict(mode=m[34],game_state=m[36],phase=m[56]&15,player_state=m[64],x=x,
             in0=m[32],active=active,interior=13<x<192,shield=m[38],
             logic=int.from_bytes(e.mem('logic_tick',2),'little'),vbi=e.val('frame_tick'),
             hpos=bytes.fromhex(e.cmd('gtia'))[0],pokey=e.cmd('pokey'),
             enemies=zlib.crc32(e.mem(0x1b50,160)),screen=zlib.crc32(e.mem(0x8000,6144)))

def branch(e,tv,wave,direction,name,frames,artificial=False):
 path=R/f'build/causal-{tv}-{wave}-{direction}-{name}.csv'
 e.cmd('controltrace '+str(path)+' '+' '.join(map(str,addresses())))
 initial=sample(e);samples=[];steady=0;longest=0;recover=None;classes=collections.Counter()
 prev=initial
 for f in range(frames):
  j=(8 if direction==4 else 4) if name.endswith('reverse') else direction
  if name.endswith('repress') and f<2:j=0
  e.step(1,j=j,t=0);s=sample(e);samples.append(s)
  if s['active'] and s['interior'] and prev['active'] and prev['interior'] and s['x']==prev['x']:
   steady+=1;longest=max(longest,steady)
  else:steady=0
  if recover is None and s['x']!=initial['x']:recover=f+1
  if not s['active']:
   cls='shield' if s['game_state']==3 and not(s['player_state']&8) else 'intro_death_or_transition'
  elif not s['interior']:cls='normal_edge_clamp'
  elif s['x']==prev['x']:cls='interior_stationary'
  else:cls='moving'
  classes[cls]+=1;prev=s
 e.cmd('controlstop');trace=analyse(path)
 # This analyser's movement/PM comparisons remain active on every branch.
 unexpected=[x for x in trace['failures']if not(artificial and x['kind']=='main_loop_and_audio_stalled_120_tvframes')]
 assert not unexpected,(tv,wave,direction,name,unexpected[:1])
 events=collections.Counter(r['event']for r in csv.DictReader(open(path)))
 return dict(initial=initial,final=samples[-1],longest_active_interior_stationary_frames=longest,
             first_x_change_frame=recover,classes=dict(classes),movement_calls=trace['movement_calls'],
             world_ram_changed_samples=sum(a['enemies']!=b['enemies']for a,b in zip([initial]+samples,samples)),
             screen_changed_samples=sum(a['screen']!=b['screen']for a,b in zip([initial]+samples,samples)),
             audio_calls=events['audio_enter'],input_polls=events['input_poll'],pm_calls=trace['pm_calls'],
             detected_stalls=events['main_audio_stall'],worst_active_gaps=trace['worst_active_gaps'])

report=[]
initial_sha=hashlib.sha256((R/'build/Phoenix-XL.car').read_bytes()).hexdigest()
for tv in ('ntsc','pal'):
 for wave in (0,2,4,6,8):
  e=TraceEmu(tv);e.step(300);e.step(20,t=1);e.step(550)
  if wave:
   fixture={0x13b8:wave,0x13a4:1,0x13a5:128,0x13ba:0 if wave in (4,6)else 16,0x13bb:8 if wave in(4,6)else 0,0x139c:0,0x1390:3}
   for a,v in fixture.items():e.cmd(f'queue {a} {v}')
   e.cmd(f'apply {L["logic_tick"]}')
   e.step(1)
  for _ in range(1800):
   s=sample(e)
   if s['active'] and s['interior'] and s['phase']=={0:1,2:3,4:5,6:7,8:11}[wave]:break
   e.step(1,j=4 if s['x']>110 else 8)
  else:raise AssertionError((tv,wave,'could not reach live checkpoint',s))
  e.cmd('save 0')
  for direction in (4,8):
   e.cmd('load 0')
   lead=branch(e,tv,wave,direction,'lead',180)
   e.cmd('save 1')
   held=branch(e,tv,wave,direction,'held',180)
   e.cmd('load 1');reverse=branch(e,tv,wave,direction,'reverse',30)
   e.cmd('load 1');repress=branch(e,tv,wave,direction,'repress',30)
   candidate=held['longest_active_interior_stationary_frames']>=120
   input_recovery=candidate and (reverse['first_x_change_frame'] is not None and reverse['first_x_change_frame']<=10 or repress['first_x_change_frame']is not None and repress['first_x_change_frame']<=10)
   item=dict(tv=tv,wave=wave//2+1,direction='left'if direction==4 else'right',lead=lead,held=held,reverse=reverse,repress=repress,
             persistent_active_stall=candidate,input_dependent_recovery=input_recovery)
   report.append(item)
   print(tv,wave,direction,'held-stationary',held['longest_active_interior_stationary_frames'],'reverse-first-change',reverse['first_x_change_frame'],'candidate',input_recovery,flush=True)
  e.close()

# Artificial detector validation, not a discovered game defect. Redirect the
# CPU into unused loader RAM while preserving its original execution state.
# This RAM-only loop waits for the physical horizontal input to change. The
# NMI continues, but game/audio work remains stopped under the unchanged hold.
# PHP/PHA ... PLA/PLP preserves both A and processor flags on resumption.
negative=[]
for tv in ('ntsc','pal'):
 e=TraceEmu(tv);e.step(300);e.step(20,t=1);e.step(550)
 for _ in range(1800):
  s=sample(e)
  if s['active'] and 50<s['x']<150:break
  e.step(1,j=4 if s['x']>110 else 8)
 else:raise AssertionError((tv,'no live negative-control checkpoint',s))
 direction=8;e.step(1,j=direction)
 resume=int(e.cmd('pc'));start=0x07e0
 # PHP; PHA; LDA $D300; AND #$0C; CMP #$04; BEQ back to LDA;
 # PLA; PLP; JMP originalPC. No shipping code or cartridge byte is patched.
 trap=bytes([0x08,0x48,0xad,0x00,0xd3,0x29,0x0c,0xc9,0x04,0xf0,0xf7,
             0x68,0x28,0x4c,resume&255,resume>>8])
 original=e.mem(start,len(trap))
 for offset,value in enumerate(trap):e.poke(start+offset,value)
 e.cmd(f'controlsetpc {start}')
 e.step(2,j=direction);e.cmd('save 2')
 held=branch(e,tv,'artificial',direction,'held',180,artificial=True)
 e.cmd('load 2');reverse=branch(e,tv,'artificial',direction,'reverse',30,artificial=True)
 e.cmd('load 2');repress=branch(e,tv,'artificial',direction,'repress',30,artificial=True)
 assert held['longest_active_interior_stationary_frames']>=120
 assert held['audio_calls']==held['input_polls']==held['movement_calls']==held['world_ram_changed_samples']==held['screen_changed_samples']==0
 assert held['initial']['logic']==held['final']['logic']
 assert (held['final']['vbi']-held['initial']['vbi'])&255>=120
 assert held['initial']['pokey']==held['final']['pokey']
 assert held['detected_stalls']>0
 for recovered in (reverse,repress):
  assert recovered['first_x_change_frame'] is not None and recovered['first_x_change_frame']<=10
  assert recovered['audio_calls']>0 and recovered['input_polls']>0 and recovered['movement_calls']>0
  assert recovered['world_ram_changed_samples']>0
 negative.append(dict(tv=tv,artificial=True,resume_pc=resume,trap_address=start,trap_bytes=trap.hex(),
                      original_ram_bytes=original.hex(),held=held,reverse=reverse,repress=repress,detected=True))
 e.close()
assert hashlib.sha256((R/'build/Phoenix-XL.car').read_bytes()).hexdigest()==initial_sha
result=dict(cartridge_sha256=initial_sha,cartridge_unchanged=True,paired_cases=len(report),
            positive_input_dependent_stalls=sum(x['input_dependent_recovery']for x in report),cases=report,
            artificial_direction_gated_stall_controls=negative)
(R/'build/control-causal-pairs-results.json').write_text(json.dumps(result,indent=2)+'\n')
