"""Measure the new continuous effect against the sample-domain circuit.

Checks physical pitch range/mean and that held latches keep modulating. It
does not claim sample or waveform identity between POKEY and analog hardware.
"""
from audio_interrupt import *
import csv,statistics
ref=R/'reference/hhi/c-phoenix'
subprocess.run(['gcc','-O2','-I'+str(ref),str(R/'tools/sound_circuit_probe.c'),
 str(ref/'sound_discrete.c'),'-lm','-o',str(B/'sound_circuit_probe')],check=True)
with (B/'sound-circuit-reference.csv').open('w') as f:
 subprocess.run([str(B/'sound_circuit_probe')],stdout=f,check=True)
rows=list(csv.DictReader((B/'sound-circuit-reference.csv').open()))
results=[]
for tv,clock in [('ntsc',1789772.5),('pal',1773447)]:
 for case in range(5):
  e=Cartridge(tv);e.step(300);e.cmd('io 54286 0');e.cmd('io 54272 0')
  for name,size in [('mod_phase',2),('slow_phase',2),('c22_level',1),('c7_level',1)]:
   for i in range(size):e.poke(e.labels[name]+i,0)
  got=[];want=[];divisors=[]
  for row in rows[case*700:(case+1)*700]:
   e.poke('g_sound_a',int(row['a']));e.poke('g_sound_b',int(row['b']))
   e.cmd(f'invoke {e.labels["audio_tick"]} 0 0 0 0');e.step(1)
   pk=bytes.fromhex(e.cmd('pokey'));d=pk[4 if case<4 else 6]
   if int(row['frame'])>=180:
    divisors.append(d);got.append(clock/56/(d+1));want.append(float(row['hz_a' if case<4 else 'hz_b']))
  e.close()
  mean_error=abs(statistics.mean(got)/statistics.mean(want)-1)
  r=dict(tv=tv,circuit='A' if case<4 else 'B',mode=case,divisors=sorted(set(divisors)),
   pokey_mean_hz=round(statistics.mean(got),2),reference_mean_hz=round(statistics.mean(want),2),
   mean_error_percent=round(mean_error*100,2),pokey_range_hz=[round(min(got),2),round(max(got),2)],
   reference_range_hz=[round(min(want),2),round(max(want),2)])
  assert mean_error<.12,r
  if case in (1,2,3,4):assert len(set(divisors))>=2,r
  assert min(got)>min(want)*.75 and max(got)<max(want)*1.25,r
  results.append(r);print(r,flush=True)
(B/'audio-circuit-results.json').write_text(json.dumps(results,indent=2)+'\n')
