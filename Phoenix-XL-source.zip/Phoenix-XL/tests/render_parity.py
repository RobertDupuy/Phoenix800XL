"""Check incremental damage against full recomposition of the same game state."""
from check import *
import json
results=[]
def draw(e):
 e.cmd(f'rendercall {L["render_frame"]}')
 for i in range(80):
  e.step(1)
  if int(e.cmd('pc'))==0x7e0:return
 raise AssertionError('Renderer did not return')
for wave in [0,2,4,6,8]:
 e=Emu();e.step(300);e.step(20,start=1);e.step(550)
 if wave:
  for a,v in {0x13b8:wave,0x13a4:1,0x13a5:128,0x13ba:0 if wave in [4,6] else 16,0x13bb:8 if wave in [4,6] else 0,0x139c:0,0x1390:3}.items():e.cmd(f'queue {a} {v}')
  e.cmd(f'apply {L["logic_tick"]}');e.step(650)
 for j in range(8):
  e.step(70,j=8 if j%2 else 4,t=j%2)
  # Interrupt at arbitrary CPU progress, but use the same frozen state for
  # both versions; preserve the running game after each comparison.
  e.cmd('save 0');e.cmd('io 54286 0');e.poke('game_due',1);e.step(40)
  draw(e);incremental=e.mem(0x8000,0x1800)
  e.poke('full_dirty',1);draw(e);full=e.mem(0x8000,0x1800)
  differences=[hex(0x8000+i) for i,(a,b) in enumerate(zip(incremental,full)) if a!=b]
  assert not differences,(wave,j,differences[:20])
  e.cmd('load 0')
 results.append(dict(wave=wave//2+1,comparisons=8,differences=0));e.close()
print(results);(R/'build/render-parity.json').write_text(json.dumps(results,indent=2))
