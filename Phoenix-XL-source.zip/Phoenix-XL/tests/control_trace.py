"""Observe the unmodified cartridge's CPU execution, movement and PM hardware.

The optional fault modes act only on emulator RAM/hardware after loading the
same cartridge, proving that movement, display and main-loop checks can fail.
"""
from check import *
from control_rom_oracle import ArcadeMoveOracle
import csv,json,hashlib,argparse,collections

class TraceEmu(Emu):
 def __init__(self,tv='ntsc'):
  self.p=subprocess.Popen([str(R/'build/control-trace-emulator'),'-'+tv,str(R/'build/Phoenix-XL.car')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=open(R/'build/control-trace-emulator.log','w'),text=True,bufsize=1)
  while True:
   s=self.p.stdout.readline().strip()
   if s=='READY':break
   if not s and self.p.poll()!=None:raise RuntimeError((R/'build/control-trace-emulator.log').read_text())

def addresses():
 image=(R/'build/game.bin').read_bytes();base=L['player_update'];code=image[base-0x2000:base-0x2000+0x180]
 # These signatures locate the inlined original movement routine, not a
 # rebuilt or specially annotated version of the released game.
 begin=bytes.fromhex('49ffa82960aec213c900')
 end=bytes.fromhex('8dc213a2ff8e6013')
 assert code.count(begin)==1 and code.count(end)==1
 return [base+code.index(begin),base+code.index(end)+len(end),base,L['pm_update'],L['logic_tick'],L['frame_tick'],L['audio_tick'],L['render_frame'],L['wait_vblank_coin'],L['hw_read_inputs']]

def expected_pm(x):
 rom=(R/'reference/program.rom').read_bytes();gfx=(R/'reference/graphics.rom').read_bytes();tile=[]
 ids=rom[0x1400+rom[0x1600+(x&7)]:0x1404+rom[0x1600+(x&7)]]
 mass=moment=0;hp=80+(x&248)//2
 for y in (0,1,3,4,5,7,8,9,11,12,13,15):
  for px in range(8):
   on=False
   for dx in (0,1):
    sx=px*2+dx;n=ids[(sx//8)*2+y//8];tx=sx%8;ty=y%8
    # Arcade graphics are rotated upright: tile[row=x][col=7-line].
    line=7-tx;bit=ty
    lo=gfx[4096+n*8+line];hi=gfx[4096+2048+n*8+line]
    on|=bool((lo|hi)&(1<<bit))
   if on:mass+=1;moment+=hp+px
 return hp,mass,moment
PM=[expected_pm(x) for x in range(256)]

def analyse(path):
 rows=[{k:(v if k=='event' else int(v)) for k,v in r.items()}for r in csv.DictReader(open(path))]
 oracle=ArcadeMoveOracle();failures=[];pending=None;pm_start=None;move_count=0;pm_count=0
 frame_classes=collections.Counter();last_port=None;held_since=0;held_frames={};last_logic=None;last_audio=None
 poll_count=0;previous_frame=None;gaps={k:0 for k in ('input_poll','logic','audio','movement','visual')}
 worst={k:dict(tv_frames=0) for k in gaps};render_start=None;longest_render=dict(tv_frames=0)
 def active(r):
  return r['mode']==1 and r['game_state']==3 and (r['phase']&15)in(1,3,5,7,11) and bool(r['player_state']&8) and 13<r['x']<192 and ((~r['porta'])&12)in(4,8)
 def located(r):
  q=dict(r);symbols=[(v,k)for k,v in L.items()if v<=r['pc'] and v>=0x2000]
  if symbols:
   at,name=max(symbols);q['pc_symbol']=name+'+'+hex(r['pc']-at)
  return q
 for r in rows:
  ev=r['event']
  if ev=='input_poll':poll_count+=1
  if ev=='render_enter':render_start=r
  elif ev=='render_exit' and render_start:
   span=r['tv']-render_start['tv']
   if span>longest_render['tv_frames']:longest_render=dict(tv_frames=span,start=located(render_start),end=located(r))
   render_start=None
  if ev=='frame':
   r['poll_calls']=poll_count;r['movement_calls']=move_count
   if previous_frame and active(r) and active(previous_frame) and ((r['porta']^previous_frame['porta'])&12)==0:
    values={'input_poll':r['poll_calls']==previous_frame['poll_calls'],'logic':r['logic']==previous_frame['logic'],
            'audio':r['audio_calls']==previous_frame['audio_calls'],'movement':r['movement_calls']==previous_frame['movement_calls'],
            'visual':(r['hpos'],r['dma_hash'])==(previous_frame['hpos'],previous_frame['dma_hash'])}
    for k,unchanged in values.items():
     gaps[k]=gaps[k]+1 if unchanged else 0
     if gaps[k]>worst[k]['tv_frames']:worst[k]=dict(tv_frames=gaps[k],end=located(r))
   else:
    for k in gaps:gaps[k]=0
   previous_frame=r
   p=(~r['porta'])&12
   if p!=last_port:held_since=r['tv'];last_port=p
   held_frames[r['tv']]=(p,r['tv']-held_since)
   if r['game_state'] in (0,1,2,4,5):cls='death_respawn_or_start'
   elif r['phase']&15 not in (1,3,5,7,11):cls='intro_or_transition'
   elif not(r['player_state']&8):cls='shield'
   elif r['render_active']:cls='render'
   elif last_logic==r['logic']:cls='waiting_or_other_work'
   else:cls='logic_progress'
   frame_classes[cls]+=1;last_logic=r['logic'];last_audio=r['audio_calls']
  elif ev=='move_enter':pending=r
  elif ev=='move_exit':
   assert pending,'unmatched movement exit'
   expected=oracle.move(pending['x'],pending['in0'],pending['moved']);got=r['x'],r['moved'];move_count+=1
   if got!=expected:failures.append(dict(kind='original_rom_movement_mismatch',tv=r['tv'],before=pending,after=r,expected=expected))
   # Check the complete hardware->input->movement chain after the same
   # single physical direction has been held for at least two TV frames.
   prev=held_frames.get(pending['tv']-1)
   direction=(~pending['porta'])&12
   if prev and prev[0]==direction and prev[1]>=2 and direction in (4,8):
    want=0x40 if direction==4 else 0x20
    if ((~pending['in0'])&0x60)!=want:failures.append(dict(kind='held_direction_not_delivered_to_movement',tv=r['tv'],before=pending,after=r))
   pending=None
  elif ev=='pm_enter':pm_start=r
  elif ev=='pm_exit':
   assert pm_start,'unmatched PM return'
   ps=pm_start;live=ps['game_state'] in (3,6,7) and (ps['phase']&15) in (1,3,5,7,11) and bool(ps['player_state']&8)
   expected=PM[ps['x']] if live else (0,0,0);actual=r['hpos'],r['mass'],r['moment'];pm_count+=1
   if actual!=expected:failures.append(dict(kind='pm_position_or_centroid_mismatch',tv=r['tv'],before=ps,after=r,expected=expected))
   pm_start=None
  elif ev=='main_audio_stall':failures.append(dict(kind='main_loop_and_audio_stalled_120_tvframes',at=r))
 oracle.close()
 return dict(movement_calls=move_count,pm_calls=pm_count,frame_classes=dict(frame_classes),worst_active_gaps=worst,longest_render_call=longest_render,failures=failures,trace_rows=len(rows))

def run_case(tv,name,fault=0,frames=1600,wave=None):
 e=TraceEmu(tv);e.step(300)
 marker=addresses()[0];image=(R/'build/game.bin').read_bytes()
 assert e.mem(marker,10)==image[marker-0x2000:marker-0x2000+10],'ELF/CAR movement block mismatch'
 e.step(20,t=1)
 if wave is not None:
  e.step(550)
  fixture={0x13b8:wave,0x13a4:1,0x13a5:128,0x13ba:0 if wave in (4,6)else 16,0x13bb:8 if wave in(4,6)else 0,0x139c:0,0x1390:3}
  for address,value in fixture.items():e.cmd(f'queue {address} {value}')
  e.cmd(f'apply {L["logic_tick"]}')
 path=R/f'build/control-{tv}-{name}.csv';a=addresses();e.cmd('controltrace '+str(path)+' '+' '.join(map(str,a)))
 if fault:e.cmd(f'controlfault {fault}')
 for f in range(frames):
  # Real held requests and rapid reversals, plus trigger pulses and shield.
  j=8 if f//73%2 else 4
  if 500<=f<510:j|=2
  e.step(1,j=j,t=f%17==0)
 e.cmd('controlstop');e.close();return analyse(path)

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--quick',action='store_true');args=parser.parse_args()
 initial_sha=hashlib.sha256((R/'build/Phoenix-XL.car').read_bytes()).hexdigest()
 results={}
 for tv in ['ntsc','pal']:
  clean=run_case(tv,'unmodified',frames=900 if args.quick else 2400)
  results[tv]=clean
  assert clean['movement_calls']>100 and clean['pm_calls']>100,'trace did not observe real calls'
  assert not clean['failures'],(tv,clean['failures'][:2])
 wave_results=[]
 if not args.quick:
  for tv in ['ntsc','pal']:
   for wave in (2,4,6,8):
    measured=run_case(tv,f'wave-{wave}',frames=1500,wave=wave)
    assert measured['movement_calls']>100 and measured['pm_calls']>100,'wave trace did not observe real calls'
    assert not measured['failures'],(tv,wave,measured['failures'][:2])
    wave_results.append(dict(tv=tv,wave=wave//2+1,**measured))
 # Each negative control uses the same ROM file. Only labelled harness
 # fault injection mutates emulated RAM or GTIA after the relevant call.
 negatives={}
 for mode,name,expected in [(1,'stuck-input','held_direction_not_delivered_to_movement'),(2,'stuck-x','original_rom_movement_mismatch'),(3,'stale-pm','pm_position_or_centroid_mismatch')]:
  result=run_case('ntsc',name,fault=mode,frames=900)
  kinds=collections.Counter(f['kind']for f in result['failures'])
  assert kinds[expected],(name,kinds)
  negatives[name]=dict(expected_detection=expected,detected=dict(kinds),movement_calls=result['movement_calls'],pm_calls=result['pm_calls'])
 # Isolated detector fixture: deliberately stop the foreground CPU while
 # preserving VBI/NMI and latched POKEY output. This forced loop does NOT
 # recover on direction change and therefore does not reproduce the user
 # report; it only verifies that a main/audio stall is detected.
 e=TraceEmu();e.step(300);e.step(20,t=1);e.step(550)
 path=R/'build/control-ntsc-main-stall.csv';e.cmd('controltrace '+str(path)+' '+' '.join(map(str,addresses())))
 e.step(30,j=8);e.cmd('controlfault 4');e.poke(0x07e0,0x4c);e.poke(0x07e1,0xe0);e.poke(0x07e2,7);e.cmd('call 2016');e.step(135,j=8)
 e.cmd('controlstop');e.close();stalled=analyse(path)
 assert any(f['kind']=='main_loop_and_audio_stalled_120_tvframes'for f in stalled['failures'])
 stall_frames=[r for r in csv.DictReader(open(path))if r['event']=='frame' and r['fault']=='4']
 vbi_progress=(int(stall_frames[-1]['vbi'])-int(stall_frames[0]['vbi']))&255
 assert vbi_progress>=120
 assert path.with_name(path.name+'.stall.mem').stat().st_size==65536
 negatives['main-audio-stall']=dict(detected=True,vbi_ticks_while_stalled=vbi_progress,memory_snapshot_saved=True,details=[f for f in stalled['failures']if f['kind']=='main_loop_and_audio_stalled_120_tvframes'])
 assert hashlib.sha256((R/'build/Phoenix-XL.car').read_bytes()).hexdigest()==initial_sha
 report=dict(cartridge_sha256=initial_sha,cartridge_unchanged=True,wave_systems=wave_results,movement_entry=addresses()[0],movement_exit=addresses()[1],systems=results,negative_controls=negatives)
 (R/'build/control-trace-results.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
