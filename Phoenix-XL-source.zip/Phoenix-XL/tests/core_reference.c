#include <stdbool.h>
#include <stdint.h>
#include "phoenix_state.h"
PhoenixState state;
uint8_t g_vram_page,g_palette_bank,g_scroll,g_sound_a,g_sound_b;
void coverage_hit(const char *s) {(void)s;}
void hw_write_video_register(uint8_t v){g_vram_page=v&1;g_palette_bank=(v>>1)&1;}
void hw_toggle_palette_bank(void){g_palette_bank^=1;}
void hw_write_scroll_register(uint8_t v){g_scroll=v;}
void hw_write_sound_a(uint8_t v){g_sound_a=v;}
void hw_write_sound_b(uint8_t v){g_sound_b=v;}
uint8_t hw_read_inputs(void){return 255;}
uint8_t hw_read_dsw(void){return 0;}
bool hw_is_vblank(void){return false;}
bool platform_wait_vblank(void){return false;}
void platform_ram_dump_hook(void){}
void platform_audio_frame_hook(void){}
void sound_set_frame_sample_index(uint16_t v){}
void copy_memory_bank(uint8_t f,uint8_t t){}
