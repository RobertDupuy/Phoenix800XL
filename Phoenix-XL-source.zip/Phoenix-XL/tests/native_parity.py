from check import *
import ctypes,random,json
ref=ctypes.CDLL(str(R/'build/core_reference.so'));ram=(ctypes.c_uint8*3072).in_dll(ref,'state')
rng=random.Random(800);rom=(R/'reference/program.rom').read_bytes();e=Emu();e.step(250);e.cmd('io 54286 0');e.cmd('io 54528 0');
tmp=R/'build/native-state.bin'
flags=R/'build/dirtyflags.bin';flags.write_bytes(bytes([2])*832);e.cmd(f'loadmem {flags} 52224 832')
checks={}
def run(name,data,args=()):
 ctypes.memmove(ram,bytes(data),3072);getattr(ref,name)(*args);expected=bytes(ram)
 tmp.write_bytes(data);e.cmd(f'loadmem {tmp} 4096 3072')
 a=args[0] if args else 0;b=args[1] if len(args)>1 else 0
 if name=='draw_bird_shape_350c':
  e.poke(0x24,args[2]>>8);e.cmd(f'invoke {L[name]} {a} {b&255} {b>>8} {args[2]&255}')
 else:e.cmd(f'invoke {L[name]} {a&255} {a>>8} {b&255} {b>>8}')
 e.step(1)
 got=e.mem(4096,3072)
 if got!=expected:
  dif=[(hex(i+0x4000),expected[i],got[i]) for i in range(3072) if expected[i]!=got[i]]
  raise AssertionError((name,args,dif[:16]))
 checks[name]=checks.get(name,0)+1
for k in range(200):
 d=bytearray(3072);d[0x3c2:0x3c4]=bytes([rng.randrange(256),rng.randrange(256)])
 run('get_screen_ram_address',d,(0x43c2,0x43e2))
for k in range(150):
 d=bytearray(3072);d[0x394]=0x10;d[0x395]=rng.randrange(16)
 for i in range(16):
  addr=rng.choice([0x1000,0x1020,0x1064,0x2c00,0x2c34,0x2d00])+rng.randrange(16)
  d[0xb50+i*2:0xb52+i*2]=addr.to_bytes(2,'big')
  d[0xb70+i*4:0xb74+i*4]=bytes([rng.choice([0,0x08,0x18,0x3b,0x9c]),0,rng.randrange(256),rng.randrange(256)])
 run('alien_movement_update',d);run('alien_animation_update',d);run('get_screen_ram_address_for_all_aliens',d)
for k in range(300):
 d=bytearray(rng.randrange(256) for _ in range(3072));
 oldkind=rng.choice([0,1,3,4]);newkind=rng.choice([0,1,3,4]);ctrl=(oldkind<<5)|rng.choice([0,8,16,24])|newkind
 d[0x3c0:0x3c2]=bytes([ctrl,rng.randrange(0xdd)])
 old=rng.choice([0x4000,0x4020,0x41e5,0x433f,0x43ff,0x0000]);new=rng.choice([0x4000,0x4020,0x41e5,0x433f,0x43ff,0x0000])
 d[0x3e0:0x3e4]=old.to_bytes(2,'big')+new.to_bytes(2,'big')
 run('update_screen_objects',d,(0x43c0,0x43e0))
for k in range(150):
 d=bytearray(3072)
 entry=rng.randrange(0x20,0x70,8);hl=rng.randrange(0x4800,0x4b40);shape=rng.choice([0x17f0,0x3c00,0x3c38,0x3d18,0x3da8])
 run('draw_bird_shape_350c',d,(entry,hl,shape))
for k in range(150):
 d=bytearray(3072);i=0xb70
 d[i:i+8]=bytes([rng.randrange(16),0x49,rng.randrange(256),rng.randrange(8),rng.randrange(256),rng.randrange(256),rng.randrange(32),rng.randrange(256)])
 d[0x3c2]=rng.randrange(13,193)
 run('update_bird_behavior',d,(0x4b70,))
 run('drawbirdobject',d,(0x4b70,))
e.close();print(checks);(R/'build/native-parity.json').write_text(json.dumps(checks,indent=2))
