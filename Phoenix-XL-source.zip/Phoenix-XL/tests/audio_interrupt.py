"""Exercise the actual cartridge audio, including a stopped foreground CPU.

The rev4 comparison uses the previous compiled driver as an independent
register-output oracle. RAM-only test fixtures never enter the shipped ROM.
"""
from check import *
import json,hashlib,random

B=R/'build'
class Cartridge(Emu):
 def __init__(self,tv='ntsc',baseline=False):
  self.folder=B/'revision4-baseline' if baseline else B
  nm=shutil.which('llvm-nm') or str(Path(os.environ.get('LLVM_MOS',R.parent/'toolchain/llvm-mos'))/'bin/llvm-nm')
  self.labels={m[3]:int(m[1],16) for line in subprocess.check_output([
   nm,str(self.folder/'game.bin.elf')],text=True).splitlines()
   if (m:=re.match(r'^([0-9a-fA-F]+)\s+(\w)\s+(.+)',line))}
  self.p=subprocess.Popen([str(B/'control-trace-emulator'),'-'+tv,str(self.folder/'Phoenix-XL.car')],
   stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=open(B/f'audio-interrupt-{tv}-{baseline}.log','w'),text=True,bufsize=1)
  while self.p.stdout.readline().strip()!='READY':
   if self.p.poll() is not None:raise RuntimeError('emulator failed')
 def mem(self,a,n=1):return super().mem(self.labels[a] if isinstance(a,str) else a,n)
 def poke(self,a,v):return super().poke(self.labels[a] if isinstance(a,str) else a,v)
 def word(self,a):return int.from_bytes(self.mem(a,2),'little')

def component_parity(tv):
 old,new=Cartridge(tv,True),Cartridge(tv)
 names=['tune','tune_pos','env0','env1','fr0','fr1','noise_env','old_noise','music_phase']
 for e in [old,new]:
  e.step(300);e.cmd('io 54286 0');e.cmd('io 54272 0')
  for name in names:
   e.poke(name,0)
  e.poke(e.labels['music_phase']+1,0)
 rng=random.Random(0x50484f45)
 commands=[(0x0f,0xcf)]*1300+[(v,0x0f) for v in range(256)]+[(0x0f,v) for v in range(256)]
 commands += [(rng.randrange(256),rng.randrange(256)) for _ in range(512)]
 for i,(a,b) in enumerate(commands):
  output=[]
  for e in [old,new]:
   e.poke('g_sound_a',a);e.poke('g_sound_b',b)
   e.cmd(f'invoke {e.labels["audio_tick"]} 0 0 0 0');e.step(1)
   assert int(e.cmd('pc'))==0x200
   output.append((e.cmd('pokey'),[e.mem(n,2 if n=='music_phase' else 1).hex() for n in names]))
  # Melody, noise envelopes and command sequencing are retained. The two
  # discrete tone channels intentionally replace the old static FFT pitch
  # with continuous circuit modulation (tested against the circuit model).
  assert output[0][1]==output[1][1],(tv,i,hex(a),hex(b),output)
  assert output[0][0][:8]==output[1][0][:8],(tv,i,output)
  old_ch4=bytes.fromhex(output[0][0])[6:8]
  if old_ch4[1]&0xf0==0x80:
   assert old_ch4==bytes.fromhex(output[1][0])[6:8],(tv,i,output)
 old.close();new.close()
 return dict(tv=tv,compiled_driver_comparisons=len(commands),melody_and_noise_match=True)

def stopped_foreground(tv,baseline=False):
 e=Cartridge(tv,baseline);e.step(300);e.step(20,t=1);e.step(550)
 e.cmd('save 0');e.cmd('io 54286 0')
 # A register-sentinel loop is the only foreground work. Record registers
 # after interrupt return: a TV-frame boundary may fall *inside* the NMI.
 loop=bytes.fromhex('8dd0078ed1078cd207ba8ed307aed1074ce007')
 for i,v in enumerate(loop):e.poke(0x7e0+i,v)
 e.cmd('invoke 2016 165 90 0 0');e.step(1)
 e.poke('g_sound_a',0x8f);e.poke('g_sound_b',0xcf)
 regs=e.mem(0x7d0,4);zp=e.mem(0,256)
 assert regs==bytes.fromhex('a55a00fd'),regs.hex()
 logic0=e.word('logic_tick');audio0=0 if baseline else e.word('audio_ticks')
 e.cmd('io 54286 192')
 outputs=[];music=[];ticks=[]
 for _ in range(240):
  e.step(1,j=8)
  outputs.append(e.cmd('pokey'));music.append(e.word('music_phase'))
  assert e.mem(0x7d0,4)==regs,(tv,'interrupted register corruption')
  if not baseline:ticks.append(e.word('audio_ticks'))
 assert e.word('logic_tick')==logic0
 after=e.mem(0,256)
 allowed={0xe8} if baseline else {0xe8,0xe9,0xea}
 assert not [i for i in range(256) if zp[i]!=after[i] and i not in allowed]
 if baseline:
  assert len(set(outputs))==1 and len(set(music))==1
 else:
  increments=[(b-a)&65535 for a,b in zip([audio0]+ticks,ticks)]
  assert min(increments[1:])>=1 and max(increments)<=2,(tv,min(increments[1:]),max(increments))
  assert len(set(outputs))>30 and len(set(music))==240
  assert e.val('noise_env')==0,'noise envelope failed to finish while game was stopped'
 e.cmd('load 0');e.step(20,j=4)
 assert e.word('logic_tick')!=logic0
 result=dict(tv=tv,baseline=baseline,stopped_tv_frames=240,distinct_pokey_states=len(set(outputs)),
  distinct_music_phases=len(set(music)),registers_and_scratch_preserved=True,
  audio_ticks=0 if baseline else (ticks[-1]-audio0)&65535,game_resumed_from_saved_state=True)
 e.close();return result

if __name__=='__main__':
 results={'cartridge_sha256':hashlib.sha256((B/'Phoenix-XL.car').read_bytes()).hexdigest(),
          'parity':[],'stopped_mainline':[]}
 for tv in ['ntsc','pal']:
  r=component_parity(tv);results['parity'].append(r);print(r,flush=True)
  for baseline in [True,False]:
   r=stopped_foreground(tv,baseline);results['stopped_mainline'].append(r);print(r,flush=True)
 (B/'audio-interrupt-results.json').write_text(json.dumps(results,indent=2)+'\n')
