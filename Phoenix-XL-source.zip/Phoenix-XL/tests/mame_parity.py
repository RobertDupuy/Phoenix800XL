from check import *
import csv,json,gzip
records=list(csv.DictReader((R/'tests/mame/allwaves.csv').open()))
p=R/'tests/mame/allwaves.ram'
data=p.read_bytes() if p.exists() else gzip.decompress(p.with_suffix('.ram.gz').read_bytes())
e=Emu();e.step(300);e.cmd('io 54286 0');e.cmd('io 54528 0')
p=R/'build/parity-input.bin';flags=R/'build/parity-flags.bin';flags.write_bytes(bytes([2])*832);e.cmd(f'loadmem {flags} 52224 832')
results=[];counts={}
for i in range(320,len(data)//3072-1,7):
 before=bytearray(data[i*3072:(i+1)*3072]);after=data[(i+1)*3072:(i+2)*3072]
 if before[0x3a2]!=1 or before[0x3a4] not in [3,6,7] or after[0x3a2]!=1:continue
 if i+2 in [1500,2800,4100,5400,6500,7100]:continue
 counts[before[0x3b8]]=counts.get(before[0x3b8],0)+1
 before[0x3a1]=before[0x3a0];before[0x3a0]=after[0x3a0]
 counter=((before[0x39a]<<8)|before[0x39b])+1;before[0x39a]=counter>>8;before[0x39b]=counter&255
 p.write_bytes(before);e.cmd(f'loadmem {p} 4096 3072');e.poke('g_vram_page',0);e.poke('g_scroll',before[0x3b9]);e.poke('game_due',1)
 e.cmd(f'invoke {L["phoenix_run_game_frame"]} 0 0 0 0')
 for _ in range(40):
  e.step(1)
  if int(e.cmd('pc'))==0x200:break
 else:raise AssertionError(('call did not return',i+1,e.cmd('pc')))
 got=e.mem(4096,3072)
 dif=[(hex(a+0x4000),after[a],got[a]) for a in range(0xbd8 if before[0x3b8]&15 in [5,7] else 0xbf0) if after[a]!=got[a]]
 if dif:results.append(dict(frame=i+1,level=before[0x3b8],diff= dif[:20]))
 if len(results)>=30:break
print('Counts',counts,'Differences:',results)
(R/'build/mame-parity.json').write_text(json.dumps(dict(counts=counts,differences=results),indent=2));e.close()
assert not results
