from check import *
import json
e=Emu('ntsc');e.step(300);e.step(20,start=1);e.step(350)
for a,v in {0x13b8:8,0x13a4:1,0x13a5:128,0x13ba:16,0x13bb:0,0x139c:0,0x1390:3}.items():e.cmd(f'queue {a} {v}')
e.cmd(f'apply {L["logic_tick"]}');e.step(600)
# An exposed core and a bullet crossing its collision cell; no new game rules.
for a,v in {0x13b8:11,0x13a4:3,0x13ba:16,0x13c0:0x9c,0x13c4:8,0x13c6:92,0x13c7:56,0x13b9:32,0x19ca:0x61,0x19c9:0x70}.items():e.cmd(f'queue {a} {v}')
e.cmd(f'apply {L["logic_tick"]}')
seen=set();transitions=[]
for i in range(600):
 e.step(2);s=e.val(0x13a4);l=e.val(0x13b8)
 if (s,l) not in seen:
  seen.add((s,l));transitions.append(dict(frame=i*2,state=s,level=l,score=e.mem(0x1381,3).hex()));e.shot(f'ending-{s}-{l}')
 if l>=16:break
e.close();print(transitions);assert (6,11) in seen and (7,11) in seen and any(l==16 for s,l in seen)
(R/'build/ending-results.json').write_text(json.dumps(transitions,indent=2))
