"""Seeded whole-loop stall search on the unchanged released cartridge.

This observes video and game clocks separately, not merely the input byte.
On a three-second game-clock stall it saves RAM, recent PC/input/sound samples,
and the screen. Test-only stage fixtures are explicit; the cartridge is intact.
"""
from check import *
from collections import deque
import hashlib,json,random

def run(tv,seed,total=36000):
 rng=random.Random(seed);e=Emu(tv);e.step(300);e.step(20,t=1)
 timeline=deque(maxlen=256);frames=0;unchanged=0;max_gap=0
 last=int.from_bytes(e.mem('logic_tick',2),'little')
 previous_pokey=e.cmd('pokey');same_sound=0;longest_sound=0
 next_wave=6000;phase_index=0;next_input=0;j=8;t=0
 results=dict(tv=tv,seed=seed,tv_frames=0,maximum_logic_gap_tvframes=0,
              longest_unchanged_sound_registers_tvframes=0,states=set(),phases=set(),faults=[])
 while frames<total:
  if frames>=next_wave and phase_index<4:
   wave=[2,4,6,8][phase_index];phase_index+=1;next_wave+=6000
   fixture={0x13b8:wave,0x13a4:1,0x13a5:128,0x13a2:1,
            0x13ba:0 if wave in (4,6) else 16,0x13bb:8 if wave in (4,6) else 0,
            0x139c:0,0x1390:3}
   for a,v in fixture.items():e.cmd(f'queue {a} {v}')
   e.cmd(f'apply {L["logic_tick"]}')
  if frames>=next_input:
   j=rng.choice([0,4,8,4,8,6,10,12]);next_input=frames+rng.randrange(1,481)
  n=min(rng.randrange(1,32),total-frames);t=rng.randrange(2)
  e.step(n,j=j,t=t);frames+=n
  tick=int.from_bytes(e.mem('logic_tick',2),'little');vbi=e.val('frame_tick')
  s=e.mem(0x13a0,40);pc=int(e.cmd('pc'));sound=e.cmd('pokey')
  if tick==last:unchanged+=n
  else:unchanged=0
  max_gap=max(max_gap,unchanged);last=tick
  same_sound=same_sound+n if sound==previous_pokey else 0
  longest_sound=max(longest_sound,same_sound);previous_pokey=sound
  sample=dict(tvframe=frames,requested=j,fire=t,vbi=vbi,logic=tick,
              pc=pc,input=s[0],mode=s[2],state=s[4],phase=s[24],
              flags=s[32],x=s[34],shield=s[6],sound=sound)
  timeline.append(sample);results['states'].add(s[4]);results['phases'].add(s[24])
  if unchanged>=180:
   prefix=R/'build'/f'control-stall-{tv}-{seed}-{frames}'
   prefix.with_suffix('.ram').write_bytes(e.mem(0,65536))
   prefix.with_suffix('.json').write_text(json.dumps(list(timeline),indent=2)+'\n')
   e.shot(prefix.name)
   results['faults'].append(dict(frame=frames,logic_gap=unchanged,evidence=str(prefix)))
   break
 e.close()
 results.update(tv_frames=frames,maximum_logic_gap_tvframes=max_gap,
                longest_unchanged_sound_registers_tvframes=longest_sound)
 for key in ('states','phases'):results[key]=sorted(results[key])
 return results

if __name__=='__main__':
 results=[]
 for tv,seed in [('ntsc',0x50484f45),('pal',0x4e495858)]:
  r=run(tv,seed);results.append(r);print(json.dumps(r),flush=True)
 report=dict(cartridge_sha256=hashlib.sha256((R/'build/Phoenix-XL.car').read_bytes()).hexdigest(),
             criterion='No game-clock progress for 180 TV frames; sound constancy alone is not a failure',
             scope='Atari800 host input; seeded timing and explicit stage fixtures',results=results)
 (R/'build/control-stall-search-results.json').write_text(json.dumps(report,indent=2)+'\n')
 assert not any(r['faults'] for r in results)
