"""Physical PIA-pin regression: sustained and overlapping directions.

Atari800's host input layer resolves opposite keys before PORTA, so rawjoy
disables that filter and presents the actual pin levels each TV frame. This
checks direct, history-independent level polling. Both active direction pins
are passed to the original arcade logic, which gives left priority.
"""
from check import *
import json

CURRENT=0x13a0
SHIP_X=0x13c2
MODE=0x13a2
results=[]

def pins(e,bits,frames=20,**keys):
 e.cmd(f'rawjoy {bits}')
 e.step(frames,j=bits,**keys)

def horizontal(e,want):
 actual=(~e.val(CURRENT))&0x60
 assert actual==want,(hex(actual),hex(want),e.mem(0x13a0,7).hex())

for tv in ['ntsc','pal']:
 e=Emu(tv)
 e.step(300);e.step(20,t=1);e.step(550)
 assert e.val(MODE)==1
 e.cmd('save 0')

 # The same current pins must produce the same input bits regardless of
 # the preceding direction. In particular, both bits remain both bits;
 # the original arcade movement routine chooses left when both are active.
 history_checks=[]
 for previous in [0,4,8,12]:
  e.cmd('load 0');pins(e,previous,8)
  before=e.val(SHIP_X);pins(e,12,12);after=e.val(SHIP_X)
  horizontal(e,0x60)
  assert after<before,(tv,previous,before,after)
  history_checks.append(dict(previous_pins=previous,current_pins=12,
                             arcade_directions=0x60,x=[before,after]))
 # Releasing either side immediately exposes the other current level.
 pins(e,8,12);horizontal(e,0x20);right=e.val(SHIP_X)
 pins(e,4,12);horizontal(e,0x40);left=e.val(SHIP_X)
 assert left<right,(tv,left,right)
 pins(e,0,12);horizontal(e,0)

 # A right hold survives shield lockout and resumes without a new edge.
 e.cmd('load 0');pins(e,8,10);before_shield=e.val(SHIP_X)
 pins(e,10,8)
 assert e.val(0x13a6)>0
 seen_locked=False;resumed=False
 for _ in range(35):
  pins(e,8,4)
  horizontal(e,0x20)
  if not(e.val(0x13c0)&8):seen_locked=True
  elif seen_locked and e.val(SHIP_X)>before_shield:
   resumed=True;break
 assert seen_locked and resumed,(tv,seen_locked,resumed)

 # Keep right down throughout each original wave's entry/animation path.
 wave_holds=[]
 for wave,target in [(0,1),(2,3),(4,5),(6,7),(8,11)]:
  e.cmd('load 0');pins(e,8,8)
  fixture={0x13b8:wave,0x13a4:1,0x13a5:128,
           0x13ba:0 if wave in (4,6) else 16,
           0x13bb:8 if wave in (4,6) else 0,0x139c:0,0x1390:3}
  for a,v in fixture.items():e.cmd(f'queue {a} {v}')
  e.cmd(f'apply {L["logic_tick"]}')
  levels=set();moved=False;x=e.val(SHIP_X)
  for _ in range(60):
   pins(e,8,20)
   if e.val(MODE):horizontal(e,0x20)
   levels.add(e.val(0x13b8))
   xx=e.val(SHIP_X)
   if xx>x and x<192:moved=True
   x=xx
  assert target in levels and moved,(tv,wave,levels,moved)
  wave_holds.append(dict(initial=wave,active=target,levels=sorted(levels)))

 # More than three minutes per direction with one unchanged pin level,
 # no release/repress or repeat edges. Each hold crosses death/intro and
 # new-game states while fire is tapped independently.
 long_holds=[]
 for direction,want in [(8,0x20),(4,0x40)]:
  e.cmd('load 0');pins(e,direction,8)
  checks=0;states=set();starts=0
  for n in range(80):
   pins(e,direction,150,t=n&1)
   if e.val(MODE):
    horizontal(e,want);checks+=1;states.add(e.val(0x13a4))
   elif n&1:starts+=1
  assert checks>30 and 4 in states and 1 in states,(tv,direction,checks,states)
  long_holds.append(dict(pins=direction,arcade_directions=want,tv_frames=12000,
                         game_samples=checks,states=sorted(states)))

 # Cartridge entry must recover joystick pins configured as low outputs
 # by previous software. Startup cannot depend on the boot OS's DDR.
 e.cmd('rawjoy -1')
 e.cmd('io 54018 56') # PACTL $38: DDR access
 e.cmd('io 54016 255') # PORTA DDR: all outputs
 e.cmd('io 54018 60') # PACTL $3c: port access
 e.cmd('io 54016 0') # all output latches low
 e.cmd(f'call {L["entry"]}')
 e.step(350)
 pia=bytes.fromhex(e.cmd('pia'))
 assert pia[0]&0x3f==0x3c and pia[1]==255,(tv,pia.hex())
 e.step(20,t=1);e.step(550)
 x=e.val(SHIP_X);e.step(20,j=8);x_after=e.val(SHIP_X)
 horizontal(e,0x20)
 assert x_after>x,(tv,x,x_after)
 e.close()
 results.append(dict(tv=tv,direction_history_independent=True,history_checks=history_checks,
                     both_pins_forwarded=True,single_directions=[left,right],
                     released_neutral=True,shield_resume=True,held_tv_frames=24000,
                     held_game_samples=sum(h["game_samples"] for h in long_holds),
                     held_states=sorted(set().union(*(h["states"] for h in long_holds))),
                     long_holds=long_holds,
                     wave_holds=wave_holds,pia_init=True))
print(json.dumps(results,indent=2))
(R/'build/held-controls-results.json').write_text(json.dumps(results,indent=2)+'\n')
