"""Independent movement oracle: execute the arcade ROM bytes at $0900.

Only the common 8080 instruction subset used by this routine is executed;
there are no 8085-specific opcodes or timing assertions. The oracle does not
use the C translation's movement implementation. Set Z80EX_LIBRARY when the
shared CPU library is not installed in the development environment.
"""
from pathlib import Path
import ctypes as C
import ctypes.util
import hashlib,json,os

ROOT=Path(__file__).resolve().parents[1]

class ArcadeMoveOracle:
 def __init__(self):
  path=os.environ.get('Z80EX_LIBRARY') or C.util.find_library('z80ex')
  if not path:
   local=Path('/workspace/scratch/eb19bf6d9f73/toolchain/root/usr/lib/x86_64-linux-gnu/libz80ex.so.1.1.21')
   if local.exists():path=str(local)
  if not path:raise RuntimeError('Install libz80ex or set Z80EX_LIBRARY')
  self.lib=C.CDLL(path);self.mem=bytearray(65536)
  self.rom=(ROOT/'reference/program.rom').read_bytes()
  self.mem[:len(self.rom)]=self.rom
  self.read_type=C.CFUNCTYPE(C.c_ubyte,C.c_void_p,C.c_ushort,C.c_int,C.c_void_p)
  self.write_type=C.CFUNCTYPE(None,C.c_void_p,C.c_ushort,C.c_ubyte,C.c_void_p)
  self.port_type=C.CFUNCTYPE(C.c_ubyte,C.c_void_p,C.c_ushort,C.c_void_p)
  self.int_type=C.CFUNCTYPE(C.c_ubyte,C.c_void_p,C.c_void_p)
  self.read=self.read_type(lambda cpu,addr,m1,user:self.mem[addr])
  self.write=self.write_type(lambda cpu,addr,value,user:self.mem.__setitem__(addr,value))
  self.pread=self.port_type(lambda cpu,port,user:255)
  self.pwrite=self.write_type(lambda cpu,port,value,user:None)
  self.iread=self.int_type(lambda cpu,user:255)
  self.lib.z80ex_create.argtypes=[self.read_type,C.c_void_p,self.write_type,C.c_void_p,self.port_type,C.c_void_p,self.write_type,C.c_void_p,self.int_type,C.c_void_p]
  self.lib.z80ex_create.restype=C.c_void_p
  self.lib.z80ex_set_reg.argtypes=[C.c_void_p,C.c_int,C.c_ushort]
  self.lib.z80ex_get_reg.argtypes=[C.c_void_p,C.c_int];self.lib.z80ex_get_reg.restype=C.c_ushort
  self.lib.z80ex_step.argtypes=[C.c_void_p]
  self.lib.z80ex_reset.argtypes=[C.c_void_p]
  self.lib.z80ex_destroy.argtypes=[C.c_void_p]
  self.cpu=self.lib.z80ex_create(self.read,None,self.write,None,self.pread,None,self.pwrite,None,self.iread,None)
  if not self.cpu:raise RuntimeError('CPU creation failed')
 def move(self,x,in0,moved=0):
  self.lib.z80ex_reset(self.cpu)
  self.mem[0x43c2]=x;self.mem[0x43a0]=in0;self.mem[0x4360]=moved
  self.mem[0xf000:0xf002]=bytes([0,0xff])
  for reg,value in [(3,0x43c2),(10,0x0900),(11,0xf000)]:self.lib.z80ex_set_reg(self.cpu,reg,value)
  self.last_pcs=[]
  for _ in range(32):
   pc=self.lib.z80ex_get_reg(self.cpu,10)
   if pc==0xff00:return self.mem[0x43c2],self.mem[0x4360]
   assert 0x0900<=pc<=0x0921,hex(pc)
   self.last_pcs.append(pc);self.lib.z80ex_step(self.cpu)
  raise AssertionError('Original movement routine did not return')
 def close(self):
  if self.cpu:self.lib.z80ex_destroy(self.cpu);self.cpu=None

def main():
 from check import Emu,L
 oracle=ArcadeMoveOracle();e=Emu();e.step(300)
 e.cmd('io 54286 0');e.cmd('io 54528 0')
 # Movement is inlined into player_update in the shipping binary. Invoke
 # that actual routine with a live ship, no shots and shield cooling down.
 # Existing dirty flags prevent the isolated calls growing a render queue.
 flags=ROOT/'build/oracle-dirty.bin';flags.write_bytes(bytes([2])*832)
 e.cmd(f'loadmem {flags} 52224 832')
 state=ROOT/'build/oracle-state.bin';state.write_bytes(bytes(3072))
 e.cmd(f'loadmem {state} 4096 3072')
 count=0;failures=[]
 for x in range(256):
  for in0 in (0xff,0xbf,0xdf,0x9f):
   moved=(x*37)&255
   expected=oracle.move(x,in0,moved)
   e.poke(0x13c2,x);e.poke(0x13a0,in0);e.poke(0x1360,moved)
   e.poke(0x13c0,0x0c);e.poke(0x13a6,1)
   e.cmd(f'rendercall {L["player_update"]}');e.step(1)
   assert int(e.cmd('pc'))==0x7e0
   got=e.val(0x13c2),e.val(0x1360)
   if got!=expected:failures.append(dict(x=x,in0=in0,expected=expected,actual=got))
   count+=1
 # Prove that an unchanged-position fault is rejected by this oracle.
 expected=oracle.move(100,0xdf)
 assert expected[0]!=100
 result=dict(cartridge_sha256=hashlib.sha256((ROOT/'build/Phoenix-XL.car').read_bytes()).hexdigest(),
             program_rom_sha256=hashlib.sha256(oracle.rom).hexdigest(),
             oracle='Original ROM $0900-$0921 executed by libz80ex',
             native_cases=count,failures=failures,stuck_x_negative_control_detected=True)
 (ROOT/'build/control-rom-oracle-results.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2));e.close();oracle.close();assert not failures

if __name__=='__main__':main()
