"""P0 must represent the arcade's live, drawn ship, not stale coordinates.

Includes all original intro phases and a real death/respawn with right held
continuously. The native fixture directly checks actual GTIA and DMA state.
"""
from check import *
import hashlib,json

def hpos(e):return bytes.fromhex(e.cmd('gtia'))[0]
def pm_image(e):return e.mem(0x9c00,256)
results=[]
for tv in ['ntsc','pal']:
 e=Emu(tv);e.step(300);e.step(20,t=1)
 first_motion=False;death_seen=False;respawn_motion=False;hidden_samples=0
 dead_run=0;intro_run=0;live_run=0;max_dead_visible=0;first_active_x=None;after_death_x=None
 for f in range(2400):
  e.step(1,j=8) # One uninterrupted right hold: no repeated press events.
  ps=e.val(0x13c0);gs=e.val(0x13a4);wave=e.val(0x13b8)&15;x=e.val(0x13c2)
  visible=e.val('ship_visible');pos=hpos(e)
  if gs==4:death_seen=True
  if gs in (0,1,2,4,5):
   dead_run+=1
   if visible:max_dead_visible=max(max_dead_visible,dead_run)
   if dead_run>=8:
    assert visible==0 and pos==0 and pm_image(e)==bytes(256),(tv,'dead ghost',f,gs,ps)
    hidden_samples+=1
  else:dead_run=0
  if gs==3 and wave in (0,2,4,6,8,9,10):
   intro_run+=1
   if intro_run>=8:
    assert visible==0 and pos==0,(tv,'intro ghost',f,wave)
    hidden_samples+=1
  else:intro_run=0
  if gs==3 and wave in (1,3,5,7,11) and ps&8:
   live_run+=1
   if live_run>=8:assert visible and pos,(tv,'live ship hidden',f,ps)
   if not death_seen:
    if first_active_x is None:first_active_x=x
    if x>first_active_x and visible and pos>=80+((x-8)&248)//2:first_motion=True
   else:
    if after_death_x is None:after_death_x=x
    if x>after_death_x and visible:respawn_motion=True
  else:live_run=0
  if first_motion and death_seen and respawn_motion and hidden_samples>100:break
 assert first_motion and death_seen and respawn_motion,(tv,first_motion,death_seen,respawn_motion)
 e.cmd('save 0')
 e.cmd('io 54286 0')
 # Directly invoke the native display routine for each phase/flag pair.
 checks=0
 for phase in range(12):
  for flags in (0x0c,0x9c,0x04):
   e.poke(0x13a4,3);e.poke(0x13b8,phase);e.poke(0x13c0,flags)
   e.cmd(f'rendercall {L["pm_update"]}');e.step(3)
   assert int(e.cmd('pc'))==0x07e0
   should_show=bool(flags&8) and phase in (1,3,5,7,11)
   assert bool(e.val('ship_visible'))==should_show,(tv,phase,flags)
   assert bool(hpos(e))==should_show,(tv,phase,flags,'GTIA')
   assert bool(any(pm_image(e)))==should_show,(tv,phase,flags,'DMA')
   checks+=1
 for gs in range(8):
  e.poke(0x13a4,gs);e.poke(0x13b8,1);e.poke(0x13c0,0x9c)
  e.cmd(f'rendercall {L["pm_update"]}');e.step(3)
  should_show=gs in (3,6,7)
  assert bool(e.val('ship_visible'))==should_show,(tv,gs,'game state')
  assert bool(hpos(e))==should_show,(tv,gs,'GTIA game state')
  checks+=1
 # All seven PM projectile channels must clear with the original foreground.
 for i in range(7):
  e.poke(0x13c4+4*i,8);e.poke(0x13c6+4*i,64+i*8);e.poke(0x13c7+4*i,80+i*8)
 projectile_checks=0
 for gs,phase,counter,visible in [(3,1,0,True),(4,1,0x60,True),(4,1,0x21,True),
                                  (4,1,0x20,False),(4,1,0x10,False),(0,1,0,False),
                                  (1,1,0x80,False),(2,1,0,False),(5,1,0,False),
                                  (3,0,0,False),(3,9,0,False),(6,11,0x20,True),(7,11,0,True)]:
  e.poke(0x13a4,gs);e.poke(0x13b8,phase);e.poke(0x13a5,counter)
  e.cmd(f'rendercall {L["pm_update"]}');e.step(3)
  positions=bytes.fromhex(e.cmd('gtia'))[1:]
  assert all(bool(p)==visible for p in positions),(tv,gs,phase,counter,positions.hex())
  projectile_checks+=7
 e.close()
 results.append(dict(tv=tv,uninterrupted_right_frames=f+1,initial_motion=True,death_seen=True,
                     resumed_without_release=True,hidden_intro_death_samples=hidden_samples,
                     maximum_death_visibility_delay_tvframes=max_dead_visible,native_visibility_cases=checks,native_projectile_visibility_checks=projectile_checks))
result=dict(cartridge_sha256=hashlib.sha256((R/'build/Phoenix-XL.car').read_bytes()).hexdigest(),systems=results)
print(json.dumps(result,indent=2))
(R/'build/pm-visibility-results.json').write_text(json.dumps(result,indent=2)+'\n')
