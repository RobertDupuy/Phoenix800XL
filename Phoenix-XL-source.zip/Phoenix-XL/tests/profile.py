from check import *
e=Emu();e.step(300);e.step(25,select=1);e.step(20);e.step(25,start=1);e.step(2500)
e.cmd('profile_start');a=e.val('render_tick');e.step(300);b=e.val('render_tick');e.cmd('profile_dump '+str(R/'build/profile.csv'));print('renders',(b-a)&255);e.shot('profile');e.close()
from collections import defaultdict
symbols=sorted((v,k) for k,v in L.items() if 0x2000<=v<0x8000 or 0xd800<=v<0xfff0)
import bisect
vals=[x[0] for x in symbols];r=defaultdict(int)
for line in (R/'build/profile.csv').read_text().splitlines():
 a,n,c=map(int,line.split(','));idx=bisect.bisect_right(vals,a)-1
 if idx>=0:r[symbols[idx][1]]+=c
print(sorted(r.items(),key=lambda x:-x[1])[:30])
