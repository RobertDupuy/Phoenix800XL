#ifndef PHOENIX_CONTROL_OBSERVER_H
#define PHOENIX_CONTROL_OBSERVER_H
void control_trace_instruction(unsigned short pc,unsigned char a,unsigned char x,unsigned char y,unsigned char s);
void control_trace_frame(unsigned frame);
void control_trace_start(const char *path,const unsigned *addresses);
void control_trace_stop(void);
void control_trace_fault(int mode);
extern unsigned control_trace_tv;
#endif
