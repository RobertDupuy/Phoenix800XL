/* External observer only: no instruction or byte in the shipping ROM changes.
 * Fault modes deliberately corrupt emulator state and are labelled in output.
 */
#include <stdio.h>
#include <string.h>
#include "memory.h"
#include "pia.h"
#include "gtia.h"
#include "pokey.h"
#include "antic.h"
#include "cpu.h"
#include "atari.h"
#include "control_observer.h"
unsigned control_trace_tv;
static FILE *out;
static char trace_path[512];
static unsigned addr[10],last_logic,last_logic_tv,last_audio_tv,audio_calls,logic_calls;
static unsigned pm_ret,pm_stack,player_ret,player_stack,render_ret,render_stack,audio_ret,audio_stack;
static unsigned move_x,move_pending,fault_mode,pm_hpos;
static unsigned char pm_dma[256];
static unsigned last_pc,stall_reported;
static unsigned short return_pc(unsigned char s){return 1+MEMORY_mem[0x100+(unsigned char)(s+1)]+256*MEMORY_mem[0x100+(unsigned char)(s+2)];}
static void row(const char *event,unsigned pc){
 if(!out)return;
 unsigned char *m=MEMORY_mem;unsigned mass=0,moment=0;unsigned hash=2166136261u;
 for(unsigned y=0;y<256;y++){
  unsigned b=m[0x9c00+y];hash=(hash^b)*16777619u;
  for(unsigned x=0;x<8;x++)if(b&(128>>x)){mass++;moment+=GTIA_HPOSP0+x;}
 }
 fprintf(out,"%s,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%llu\n",
 event,control_trace_tv,pc,m[addr[5]],m[addr[4]]+256*m[addr[4]+1],PIA_GetByte(0xd300,1),m[0x13a0],m[0x13a2],m[0x13a4],m[0x13b8],m[0x13c0],m[0x13c2],m[0x1360],GTIA_HPOSP0,mass,moment,hash,audio_calls,logic_calls,fault_mode,render_ret!=0,player_ret!=0,
 POKEY_AUDF[0],POKEY_AUDC[0],POKEY_AUDF[1],POKEY_AUDC[1],POKEY_AUDF[2],POKEY_AUDC[2],POKEY_AUDF[3],POKEY_AUDC[3],POKEY_AUDCTL[0],m[0x13a6],
 (unsigned long long)control_trace_tv*Atari800_tv_mode*114+ANTIC_ypos*114+ANTIC_XPOS);
}
void control_trace_start(const char *path,const unsigned *addresses){
 control_trace_stop();memcpy(addr,addresses,sizeof(addr));snprintf(trace_path,sizeof(trace_path),"%s",path);out=fopen(path,"w");
 last_logic=MEMORY_mem[addr[4]]+256*MEMORY_mem[addr[4]+1];last_logic_tv=last_audio_tv=control_trace_tv;
 audio_calls=logic_calls=pm_ret=player_ret=render_ret=audio_ret=move_pending=stall_reported=0;
 if(out)fprintf(out,"event,tv,pc,vbi,logic,porta,in0,mode,game_state,phase,player_state,x,moved,hpos,mass,moment,dma_hash,audio_calls,logic_calls,fault,render_active,player_active,f1,c1,f2,c2,f3,c3,f4,c4,audctl,shield,cpu_clock\n");
}
void control_trace_stop(void){if(out)fclose(out);out=NULL;fault_mode=0;}
void control_trace_fault(int mode){fault_mode=mode;}
void control_trace_instruction(unsigned short pc,unsigned char a,unsigned char x,unsigned char y,unsigned char s){
 (void)a;(void)x;(void)y;if(!out)return;last_pc=pc;
 if(pm_ret && pc==pm_ret && s==(unsigned char)(pm_stack+2)){
  if(fault_mode==3){memcpy(MEMORY_mem+0x9c00,pm_dma,256);GTIA_PutByte(0xd000,pm_hpos);}
  pm_ret=0;row("pm_exit",pc);
 }
 if(player_ret && pc==player_ret && s==(unsigned char)(player_stack+2)){player_ret=0;row("player_exit",pc);}
 if(render_ret && pc==render_ret && s==(unsigned char)(render_stack+2)){render_ret=0;row("render_exit",pc);}
 if(audio_ret && pc==audio_ret && s==(unsigned char)(audio_stack+2)){audio_ret=0;row("audio_exit",pc);}
 if(pc==addr[2]){
  if(fault_mode==1)MEMORY_mem[0x13a0]=255;
  player_ret=return_pc(s);player_stack=s;row("player_enter",pc);
 }
 if(pc==addr[0]){move_x=MEMORY_mem[0x13c2];move_pending=1;row("move_enter",pc);}
 if(pc==addr[1] && move_pending){
  if(fault_mode==2)MEMORY_mem[0x13c2]=move_x;
  move_pending=0;row("move_exit",pc);
 }
 if(pc==addr[3]){
  pm_ret=return_pc(s);pm_stack=s;pm_hpos=GTIA_HPOSP0;memcpy(pm_dma,MEMORY_mem+0x9c00,256);row("pm_enter",pc);
 }
 if(pc==addr[6]){audio_calls++;last_audio_tv=control_trace_tv;audio_ret=return_pc(s);audio_stack=s;row("audio_enter",pc);}
 if(pc==addr[7]){render_ret=return_pc(s);render_stack=s;row("render_enter",pc);}
 if(pc==addr[8])row("wait_enter",pc);
 if(pc==addr[9])row("input_poll",pc);
}
void control_trace_frame(unsigned frame){
 control_trace_tv=frame;if(!out)return;
 unsigned logic=MEMORY_mem[addr[4]]+256*MEMORY_mem[addr[4]+1];
 if(logic!=last_logic){logic_calls+=(logic-last_logic)&65535;last_logic=logic;last_logic_tv=frame;stall_reported=0;}
 row("frame",last_pc);
 if(frame-last_logic_tv>=120 && frame-last_audio_tv>=120 && !stall_reported){
  row("main_audio_stall",last_pc);stall_reported=1;fflush(out);
  char dump_path[560];snprintf(dump_path,sizeof(dump_path),"%s.stall.mem",trace_path);
  FILE *dump=fopen(dump_path,"wb");if(dump){fwrite(MEMORY_mem,1,65536,dump);fclose(dump);}
 }
}
