#!/usr/bin/env python3
"""Exercise physical keyboard routing through the full AltirraSDL frontend.

Unlike the Atari800 harness, this sends SDL keyboard-down/up events through
Altirra's UI and input manager. No Atari joystick RAM or pin values are poked.
Set ALTIRRA_SDL to a desktop AltirraSDL binary with its test-mode support.
This does not reproduce the user's exact host OS or keyboard configuration.
"""
import hashlib,json,os,subprocess
from check import L
from pathlib import Path

R=Path(__file__).resolve().parents[1]
EXE=Path(os.environ.get('ALTIRRA_SDL','/workspace/scratch/0fe841472530/squashfs-root/usr/bin/AltirraSDL'))
CART=Path(os.environ.get('PHOENIX_CAR',str(R/'build/Phoenix-XL.car'))).resolve()
if not EXE.is_file():
 raise SystemExit('Set ALTIRRA_SDL to the AltirraSDL executable.')
B=R/'build';B.mkdir(exist_ok=True)

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
results=[]
for tv in ['ntsc','pal']:
 script=[];expected=[];direction_mark=None
 def key(direction,name):
  global direction_mark
  if name in ('Left','Right'):
   direction_mark=len(script);script.extend([f'mem_read {L["logic_tick"]:04x} 2',f'mem_read {L["frame_tick"]:04x} 1'])
  script.append(f'physical_key {direction} {name}')
 def wait(n):script.append(f'wait_frames {n}')
 def sample(label,pins):
  idx=len(script)
  script.extend(['mem_read 13a0 40','mem_read d300 4',f'mem_read {L["logic_tick"]:04x} 2',f'mem_read {L["frame_tick"]:04x} 1'])
  expected.append((label,pins,idx,direction_mark))
 wait(300);key('down','Left Ctrl');wait(20);key('up','Left Ctrl');wait(550)
 sample('start',0xff)
 # Press direction while fire is already held; lift/repress only fire while
 # direction remains down. Repeat transitions, including complete death and
 # respawn sequences. A direction never receives a synthetic release in a hold.
 for cycle in range(60):
  d='Right' if cycle%2==0 else 'Left';pins=0xf7 if d=='Right' else 0xfb
  key('down','Left Ctrl');key('down',d);wait(10);sample(f'{cycle}:fire-held',pins)
  key('up','Left Ctrl');wait(10);sample(f'{cycle}:fire-released',pins)
  key('down','Left Ctrl');wait(10);sample(f'{cycle}:fire-pressed',pins)
  key('up','Left Ctrl');key('up',d)
 # Altirra neutralizes opposing directions in its controller layer. Verify
 # that releasing the old direction preserves the new one without a new down.
 for direction,name,label,pins in [('down','Left','left',0xfb),('down','Right','both',0xff),('up','Left','right-remains',0xf7),('down','Left','both-again',0xff),('up','Right','left-remains',0xfb),('up','Left','released',0xff)]:
  key(direction,name);wait(12);sample('overlap:'+label+':early',pins)
  wait(24);sample('overlap:'+label+':settled',pins)
 script.append('quit')
 sp=B/f'altirra-keyboard-{tv}.txt';out=B/f'altirra-keyboard-{tv}.jsonl';log=B/f'altirra-keyboard-{tv}.log'
 sp.write_text('\n'.join(script)+'\n')
 env=os.environ.copy();env['ALTIRRA_TESTMODE_SCRIPT']=str(sp);env['ALTIRRA_TESTMODE_OUTPUT']=str(out)
 with log.open('w') as f:
  subprocess.run([str(EXE),'--headless','--test-mode','--renderer','sdlrenderer','--hardware','800xl',f'--{tv}','--nobasic','--cart',str(CART)],env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=90)
 responses=[json.loads(line) for line in out.read_text().splitlines()]
 assert all(r.get('ok') for r in responses),[r for r in responses if not r.get('ok')]
 assert len(responses)==len(script),(len(responses),len(script))
 trace=[];active=0;observed=set();delayed=[];initialization=[];checked=0
 for label,pins,idx,mark in expected:
  s=responses[idx]['bytes'];p=responses[idx+1]['bytes']
  tick=int.from_bytes(bytes(responses[idx+2]['bytes']),'little')
  starttick=int.from_bytes(bytes(responses[mark]['bytes']),'little') if mark is not None else tick-2
  ticks=(tick-starttick)&65535
  tvframes=(responses[idx+3]['bytes'][0]-responses[mark+1]['bytes'][0])&255 if mark is not None else 0
  assert p[0]==pins,(tv,label,'PORTA',p[0],pins)
  assert p[2]&0x3f==0x3c,(tv,label,'PACTL',p)
  if s[2]:
   want={0xff:0,0xf7:0x20,0xfb:0x40}[pins]
   # logic_tick increments just before hw_read_inputs. Two ticks prove
   # at least one whole input poll completed since this SDL direction event.
   # A blocking display transition may legitimately still be on the old tick;
   # record that separately instead of calling it a lost keyboard event.
   if s[4]==0 or s[3]==2:
    # Original new-game bank copies can replace IN0 with the previous
    # player's stored inputs before the first playable/score-flash tick.
    initialization.append(dict(label=label,ticks=ticks,state=s[4],submode=s[3]))
   elif ticks>=2:
    assert (~s[0]&0x60)==want,(tv,label,'arcade input after polling',s[0],pins,ticks)
    checked+=1
   elif (~s[0]&0x60)!=want:
    delayed.append(dict(label=label,ticks=ticks,tvframes=tvframes,state=s[4],input=s[0],porta=p[0]))
   if label.endswith(':settled'):
    assert s[4]!=0 and s[3]!=2,(tv,label,'new-game initialization did not finish')
    assert ticks>=2,(tv,label,'held input did not reach polling within 36 TV frames',ticks)
   active+=1;observed.add(s[4])
  trace.append(dict(label=label,porta=p[0],input=s[0],mode=s[2],state=s[4],level=s[24],player_state=s[32],x=s[34],logic_tick=tick,ticks_since_direction=ticks,tvframes_since_direction=tvframes))
 assert active>100 and checked>100 and 3 in observed,(tv,active,checked,observed)
 results.append(dict(tv=tv,samples=len(trace),game_samples=active,completed_poll_samples=checked,states=sorted(observed),input_losses=0,blocked_poll_samples=delayed,initialization_samples=initialization,trace=trace))
 print(tv,'physical-keyboard samples',len(trace),'game samples',active,'states',sorted(observed),flush=True)
report=dict(cartridge=str(CART),cartridge_sha256=sha(CART),emulator=str(EXE),emulator_sha256=sha(EXE),test='Full AltirraSDL frontend, SDL physical keyboard events',host='Linux headless; not user host OS',results=results)
(B/'altirra-keyboard-results.json').write_text(json.dumps(report,indent=2)+'\n')
