from check import *
import json

results=[]
for tv in ['ntsc','pal']:
 e=Emu(tv);e.step(300);e.step(20,t=1);e.step(550)
 assert e.val(0x13a2)==1 and e.val(0x13a4)==3
 x0=e.val(0x13c2);e.step(20,j=4);x1=e.val(0x13c2);e.step(20,j=8);x2=e.val(0x13c2)
 assert x1<x0 and x2>x1,(tv,x0,x1,x2)
 e.step(8,t=1);shot=e.val(0x13c4);assert shot&8,(tv,shot)
 e.step(8,j=2);shield=e.val(0x13a6);assert shield>0
 e.shot('controls-'+tv)
 e.cmd('warmstart');e.step(350)
 assert e.val(0x13a2)==0 and e.val('frame_tick')!=0
 e.step(20,select=1);e.step(20);e.step(20,select=1);e.step(20)
 assert e.val(0x138f)==2,(tv,e.val(0x138f))
 e.step(20,option=1);e.step(350)
 assert e.val(0x13a2)==2
 banks=set();modes=set()
 for i in range(200):
  e.step(100);banks.add(e.val('g_vram_page'));modes.add(e.val(0x13a2))
  if 0 in modes and banks=={0,1}:break
 assert banks=={0,1} and 0 in modes,(tv,banks,modes)
 results.append(dict(tv=tv,left=[x0,x1],right=x2,bullet_state=shot,shield_count=shield,reset=True,two_player_banks=sorted(banks),game_over=True))
 e.close()
print(results)
(R/'build/controls-results.json').write_text(json.dumps(results,indent=2))
