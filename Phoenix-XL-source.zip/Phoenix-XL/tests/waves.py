from check import *
import json
results=[]
for tv in ['ntsc','pal']:
 for wave in [0,2,4,6,8,0x10,0x20,0x60]:
  e=Emu(tv);e.step(260);e.step(20,start=1);e.step(350)
  changes={0x13b8:wave,0x13a4:1,0x13a5:128,0x13ba:0 if wave in [4,6] else 16,0x13bb:8 if wave in [4,6] else 0,0x139c:0,0x1390:3}
  for a,v in changes.items():e.cmd(f'queue {a} {v}')
  e.cmd(f'apply {L["logic_tick"]}')
  observed=set();beg=int.from_bytes(e.mem('logic_tick',2),'little')
  for i in range(120):
   e.step(10,j=8 if i%60<30 else 4,t=i%2)
   observed.add(e.val(0x13b8))
   if i==60:e.shot(f'wave-{tv}-{wave:02x}')
  result=dict(tv=tv,initial=wave,levels=sorted(observed),ticks=int.from_bytes(e.mem('logic_tick',2),'little')-beg,state=e.val(0x13a4),lives=e.val(0x1390),score=e.mem(0x1381,3).hex(),due=e.val('game_due'))
  print(result,flush=True);results.append(result);e.close()
(R/'build/wave-results.json').write_text(json.dumps(results,indent=2))
