#!/usr/bin/env python3
"""Full desktop keyboard search with independent CPU, audio and visible PM data.

The cartridge and emulated RAM are never patched. Physical SDL key events go
through the desktop frontend. Raw debugger dumps, script, samples and replay
checkpoints are retained so an anomalous observation can be replayed.
"""
import argparse, collections, hashlib, json, os, random, re, shutil, subprocess, wave
from pathlib import Path
from check import L
from control_trace import PM
from control_rom_oracle import ArcadeMoveOracle

R = Path(__file__).resolve().parents[1]
B = R / 'build'
EXE = Path(os.environ.get('ALTIRRA_SDL', str(R.parent/'squashfs-root/usr/bin/AltirraSDL')))
CART = Path(os.environ.get('PHOENIX_CAR', str(R/'release/Phoenix-XL.car'))).resolve()
GLOBAL_START = min(L[k] for k in ('old_ship_x','old_ship_y','frame_tick','logic_tick','music_phase'))
GLOBAL_END = max(L[k]+2 for k in ('noise_env','g_sound_a','g_sound_b','music_phase','logic_tick'))
_oracle=ArcadeMoveOracle()
CAN_MOVE={(x,d):_oracle.move(x,0xbf if d==4 else 0xdf)[0]!=x for x in range(256) for d in (4,8)}
_oracle.close()

class Search:
 def __init__(self,tv,quick=False):
  self.tv=tv;self.quick=quick;self.prefix=B/f'altirra-control-search-{tv}'
  self.script=[];self.samples=[];self.events=[];self.held=set();self.block='boot';self.frame=0
  self.add(f'debugger_console .logopen "{self.prefix}.debug.log"')
  self.add('set_speed normal')
 def add(self,s): self.script.append(s)
 def key(self,down,key):
  self.add(f'physical_key {"down" if down else "up"} {key}')
  (self.held.add if down else self.held.discard)(key)
  self.events.append(dict(frame=self.frame,block=self.block,key=key,down=down,line=len(self.script)))
 def release(self):
  for k in sorted(self.held):self.key(False,k)
 def wait(self,n,observe=True):
  if not observe:self.add(f'wait_frames {n}');self.frame+=n;return
  for _ in range(n):
   self.add('wait_frames 1');self.frame+=1;self.sample()
 def sample(self):
  i=len(self.samples);line=len(self.script)
  self.samples.append(dict(index=i,line=line,frame=self.frame,block=self.block,held=sorted(self.held)))
  self.add('mem_read 13a0 40')
  self.add(f'mem_read {GLOBAL_START:04x} {GLOBAL_END-GLOBAL_START}')
  self.add('mem_read d300 4')
  self.add('mem_read 9c00 256')
  self.add(f'debugger_console .printf "SEARCH_SAMPLE {i}"')
  self.add('debugger_console r');self.add('debugger_console .gtia');self.add('debugger_console .pokey')
 def checkpoint(self,name):
  self.add(f'save_state {self.prefix}-{name}.atstate');self.wait(2,False)
 def prepare(self):
  self.wait(300,False);self.key(True,'Left Ctrl');self.wait(20,False)
  self.key(False,'Left Ctrl');self.wait(550,False);self.checkpoint('base')
  # Restoring the same running-game snapshot varies the first press against
  # the original logic/display phase without changing any game memory.
  for phase in range(4 if self.quick else 16):
   self.release();self.block=f'phase-{phase}'
   self.add(f'load_state {self.prefix}-base.atstate');self.wait(2,False)
   self.wait(phase)
   direction='Left' if phase&1 else 'Right';other='Right' if phase&1 else 'Left'
   self.key(True,direction)
   for f in range(48):
    if f in (5,9,15,25,35):self.key(True,direction) # duplicate physical down, no release
    if f==8:self.key(True,'Left Ctrl')
    if f==16:self.key(True,'Left Shift')
    if f==24:self.key(False,'Left Ctrl')
    if f==32:self.key(False,'Left Shift')
    self.wait(1)
   # Overlap then release the old key, leaving the new direction held.
   self.key(True,other);self.wait(2);self.key(False,direction);self.wait(48)
   self.key(False,other);self.wait(8)
  self.release();self.block='long-seeded-choreography'
  self.add(f'load_state {self.prefix}-base.atstate');self.wait(2,False)
  self.checkpoint('long');rng=random.Random(0x50484f45)
  direction=None
  for f in range(720 if self.quick else 4200):
   if f%41==0:
    new='Right' if rng.randrange(2) else 'Left'
    self.key(True,new)
    if direction and direction!=new:self.key(False,direction)
    direction=new
   if f%7==0:self.key(True,direction)
   if f%17==0:self.key(True,'Left Ctrl')
   if f%17==3:self.key(False,'Left Ctrl')
   if f%223==0:self.key(True,'Down')
   if f%223==2:self.key(False,'Down')
   if f%109==0:self.key(True,'Left Shift')
   if f%109==5:self.key(False,'Left Shift')
   self.wait(1)
  self.release();self.block='focus-loss-explicit-probe'
  self.add(f'load_state {self.prefix}-base.atstate');self.wait(2,False)
  self.key(True,'Right');self.wait(20);self.checkpoint('before-focus-loss')
  self.add('physical_focus lost');self.add('query_state');self.wait(130);self.checkpoint('focus-frozen')
  self.add('physical_focus gained');self.add('query_state');self.wait(130)
  self.key(False,'Right');self.key(True,'Right');self.wait(30);self.release()
  self.add(f'save_state {self.prefix}-end.atstate');self.wait(2,False)
  self.add('debugger_console .logclose');self.add('quit')
 def run(self):
  self.prepare();p=self.prefix.with_suffix('.txt');p.write_text('\n'.join(self.script)+'\n')
  self.prefix.with_suffix('.events.json').write_text(json.dumps(dict(samples=self.samples,events=self.events),indent=2)+'\n')
  env=os.environ.copy();env['ALTIRRA_TESTMODE_SCRIPT']=str(p);env['ALTIRRA_TESTMODE_OUTPUT']=str(self.prefix)+'.jsonl'
  with self.prefix.with_suffix('.log').open('w') as out:
   subprocess.run([str(EXE),'--headless','--test-mode','--renderer','sdlrenderer','--hardware','800xl',f'--{self.tv}','--nobasic','--cart',str(CART)],env=env,stdout=out,stderr=subprocess.STDOUT,check=True,timeout=240)
  return self.analyse()
 def analyse(self):
  responses=[json.loads(l) for l in Path(str(self.prefix)+'.jsonl').read_text().splitlines()]
  errors=[dict(line=i,response=r) for i,r in enumerate(responses) if not r.get('ok')]
  assert not errors,errors[:5]
  assert len(responses)==len(self.script),(len(responses),len(self.script))
  dumps=re.split(r'SEARCH_SAMPLE (\d+)\n',Path(str(self.prefix)+'.debug.log').read_text())
  dbg={int(dumps[i]):dumps[i+1] for i in range(1,len(dumps),2)}
  trace=[];failures=[];runs=collections.Counter();maxruns=collections.Counter();last=None
  for meta in self.samples:
   i=meta['line'];s=responses[i]['bytes'];g=responses[i+1]['bytes'];p=responses[i+2]['bytes'];dma=responses[i+3]['bytes'];d=dbg[meta['index']]
   def val(name,n=1):return int.from_bytes(bytes(g[L[name]-GLOBAL_START:L[name]-GLOBAL_START+n]),'little')
   cpu=re.search(r'\((\d+):\s*(\d+),\s*(\d+)\) A=([0-9A-F]+) X=([0-9A-F]+) Y=([0-9A-F]+) S=([0-9A-F]+) P=([0-9A-F]+).*?\s([0-9A-F]{4}):',d)
   assert cpu,d[:200]
   hpos=int(re.search(r'Player  0: color = \w+, pos = (\w+)',d)[1],16)
   audio=[(int(a,16),int(c,16)) for a,c in re.findall(r'AUDF\d: (\w+)  AUDC\d: (\w+)',d)]
   mass=sum(v.bit_count() for v in dma)
   moment=sum((hpos+bit) for v in dma for bit in range(8) if v&(128>>bit))
   r=dict(meta,frame_tick=val('frame_tick'),logic=val('logic_tick',2),music_phase=val('music_phase',2),render=val('render_tick'),due=val('game_due'),porta=p[0],input=s[0],mode=s[2],state=s[4],shield=s[6],phase=s[24],player_state=s[32],x=s[34],old_x=val('old_ship_x'),visible=val('ship_visible'),hpos=hpos,mass=mass,moment=moment,audio=audio,pc=int(cpu[9],16),cpu_frame=int(cpu[1]),cpu_a=int(cpu[4],16),cpu_x=int(cpu[5],16),cpu_y=int(cpu[6],16),cpu_sp=int(cpu[7],16))
   active=r['mode'] and r['state'] in (3,6,7) and r['phase']&15 in (1,3,5,7,11) and r['player_state']&8
   direction=(~p[0])&12
   # Report prolonged interior stationary periods even if they have a known
   # shield/render cause; raw state is retained rather than silently excluded.
   eligible=bool(active and direction in (4,8) and CAN_MOVE[(r['x'],direction)])
   sameblock=last and r['block']==last['block']
   for name,condition in [('main',sameblock and r['logic']==last['logic'] and r['frame_tick']!=last['frame_tick']),('audio_phase',sameblock and r['music_phase']==last['music_phase'] and r['frame_tick']!=last['frame_tick']),('interior_x',sameblock and eligible and last.get('eligible') and direction==last['direction'] and r['x']==last['x']),('visible_pm',sameblock and eligible and last.get('eligible') and direction==last['direction'] and (hpos,mass,moment)==(last['hpos'],last['mass'],last['moment'])),('frontend_no_vbi',sameblock and r['frame_tick']==last['frame_tick'])]:
    runs[name]=runs[name]+1 if condition else 0;maxruns[name]=max(maxruns[name],runs[name])
    limit=120 if name in ('main','audio_phase','frontend_no_vbi') else 12
    if runs[name]==limit:failures.append(dict(kind=name,run_frames=limit,at=r.copy()))
   expected=PM[r['old_x']] if r['visible'] else (0,0,0)
   r.update(eligible=eligible,direction=direction,pm_expected=expected,pm_match=(hpos,mass,moment)==expected)
   trace.append(r);last=r
  self.prefix.with_suffix('.trace.json').write_text(json.dumps(trace,separators=(',',':'))+'\n')
  mismatch_runs=[];start=None
  for i,r in enumerate(trace):
   if not r['pm_match'] and start is None:start=i
   if r['pm_match'] and start is not None:mismatch_runs.append((start,i-start));start=None
  if start is not None:mismatch_runs.append((start,len(trace)-start))
  result=dict(tv=self.tv,samples=len(trace),blocks=dict(collections.Counter(r['block'] for r in trace)),max_consecutive_frames=dict(maxruns),observed_states=sorted({r['state'] for r in trace if r['mode']}),pm_mismatch_samples=sum(not r['pm_match'] for r in trace),max_pm_mismatch_run=max((n for _,n in mismatch_runs),default=0),candidate_events=failures,raw_debug_log=str(self.prefix)+'.debug.log',trace=str(self.prefix)+'.trace.json',script=str(self.prefix)+'.txt')
  self.prefix.with_suffix('.results.json').write_text(json.dumps(result,indent=2)+'\n');return result

class FocusSearch(Search):
 """Explicit frontend focus fault, kept separate from ordinary gameplay."""
 def __init__(self,tv):
  super().__init__(tv);self.prefix=B/f'altirra-focus-reproduction-{tv}'
  self.script[0]=f'debugger_console .logopen "{self.prefix}.debug.log"'
  self.images=[];self.audio_name=f'{self.prefix.name}-{os.getpid()}.wav'
 def sample(self):
  super().sample()
  if len(self.samples)%6==1:
   path=f'{self.prefix}-frame-{len(self.images):03d}.png';self.add(f'screenshot {path}');self.images.append(path)
 def stage(self,name,n):
  self.block=name;self.wait(n);self.checkpoint(name)
  self.add(f'screenshot {self.prefix}-{name}.png')
 def prepare(self):
  self.wait(300,False);self.key(True,'Left Ctrl');self.wait(20,False)
  self.key(False,'Left Ctrl');self.wait(550,False)
  self.checkpoint('base')
  self.add('file_dialog_builtin on');self.add('run_command Record.RecordAudio');self.wait(5,False)
  # The built-in save dialog accepts a filename, not an absolute path.
  self.add(f'send_text {self.audio_name}');self.wait(2,False)
  self.add('key enter');self.wait(5,False);self.add('query_state')
  self.key(True,'Right');self.stage('01-before-focus-loss',24)
  self.add('physical_focus lost');self.stage('02-focus-lost',120)
  self.add('physical_focus gained');self.stage('03-focus-returned-key-still-held',120)
  self.key(False,'Right');self.key(True,'Right');self.stage('04-after-release-repress',30)
  self.release();self.add('run_command Record.StopRecording');self.wait(2,False)
  self.add('debugger_console .logclose');self.add('quit')
 def run(self):
  result=super().run()
  self.prefix.with_suffix('.images.json').write_text(json.dumps(self.images,indent=2)+'\n')
  result['interpretation']='Injected focus loss pauses emulation and releases keys; returning focus does not restore the held key. This demonstrates frontend behavior, not the cause of the user report.'
  result['audio_limit']='Internal WAV recording omits paused emulation time. SDL dummy audio was used; audible host output during the pause is not measured.'
  for folder in (Path.home(),R,B):
   candidate=folder/self.audio_name
   if candidate.exists():
    dest=self.prefix.with_suffix('.wav');shutil.move(str(candidate),str(dest))
    with wave.open(str(dest)) as wav:result['recorded_audio_seconds']=wav.getnframes()/wav.getframerate()
    result['wav']=str(dest);break
  trace=json.loads(self.prefix.with_suffix('.trace.json').read_text());result['stages']=[]
  for block in dict.fromkeys(r['block'] for r in trace):
   rows=[r for r in trace if r['block']==block]
   result['stages'].append(dict(stage=block,samples=len(rows),first=rows[0],last=rows[-1]))
  if shutil.which('ffmpeg'):
   video=f'{self.prefix}-silent.mp4'
   subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-framerate','10','-i',f'{self.prefix}-frame-%03d.png','-c:v','libx264','-pix_fmt','yuv420p','-vf','scale=672:480:flags=neighbor',video],check=True)
   result['silent_video']=video
  self.prefix.with_suffix('.results.json').write_text(json.dumps(result,indent=2)+'\n')
  return result

class HoldSearch(Search):
 """No direction events for twenty seconds, then one immediate reversal."""
 def __init__(self,tv):
  super().__init__(tv);self.prefix=B/f'altirra-held-reversal-{tv}'
  self.script[0]=f'debugger_console .logopen "{self.prefix}.debug.log"'
 def prepare(self):
  self.wait(300,False);self.key(True,'Left Ctrl');self.wait(20,False)
  self.key(False,'Left Ctrl');self.wait(550,False)
  self.checkpoint('base')
  self.key(True,'Right')
  for direction in ('Right','Left'):
   self.block=f'unchanged-{direction.lower()}'
   if direction=='Left':self.key(False,'Right');self.key(True,'Left')
   for f in range(1200):
    # Fire and shield change independently; no duplicate direction down,
    # direction release, focus event or state restore occurs inside a hold.
    if f%17==0:self.key(True,'Left Ctrl')
    if f%17==3:self.key(False,'Left Ctrl')
    if f==200:self.key(True,'Down')
    if f==202:self.key(False,'Down')
    self.wait(1)
   self.checkpoint(direction.lower()+'-held')
  self.release();self.add('debugger_console .logclose');self.add('quit')

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--quick',action='store_true');parser.add_argument('--focus-only',action='store_true');parser.add_argument('--hold-only',action='store_true');parser.add_argument('--tv',choices=['ntsc','pal','both'],default='both');args=parser.parse_args()
 original=hashlib.sha256(CART.read_bytes()).hexdigest();results=[]
 for tv in (['ntsc','pal'] if args.tv=='both' else [args.tv]):
  r=(HoldSearch(tv) if args.hold_only else FocusSearch(tv) if args.focus_only else Search(tv,args.quick)).run();results.append(r);print(json.dumps(r,indent=2),flush=True)
 assert hashlib.sha256(CART.read_bytes()).hexdigest()==original
 report=dict(cartridge=str(CART),cartridge_sha256=original,emulator_sha256=hashlib.sha256(EXE.read_bytes()).hexdigest(),host='Linux AltirraSDL desktop, official test-mode physical events; not user host',repeat_limitation='Duplicate SDL keydown events; public API does not set the OS repeat flag',results=results)
 name='altirra-held-reversal-results.json' if args.hold_only else 'altirra-focus-reproduction-results.json' if args.focus_only else 'altirra-control-search-results.json'
 (B/name).write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__':main()
