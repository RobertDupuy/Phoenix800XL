from check import *
import json

results=[]
for tv,clock,lines in [('ntsc',1789772.5,262),('pal',1773447,312)]:
 for wave in [0,2,4,6,8]:
  e=Emu(tv);e.step(300);e.step(20,start=1);e.step(550)
  if wave:
   for a,v in {0x13b8:wave,0x13a4:1,0x13a5:128,0x13ba:0 if wave in [4,6] else 16,0x13bb:8 if wave in [4,6] else 0,0x139c:0,0x1390:3}.items():e.cmd(f'queue {a} {v}')
   e.cmd(f'apply {L["logic_tick"]}');e.step(650)
  ticks0=int.from_bytes(e.mem('logic_tick',2),'little');drops0=int.from_bytes(e.mem('dropped_ticks',2),'little');renders=0;levels=set()
  for i in range(50):
   r=e.val('render_tick');e.step(12,j=8 if i%30<15 else 4,t=i%2);renders+=(e.val('render_tick')-r)&255;levels.add(e.val(0x13b8))
  ticks=int.from_bytes(e.mem('logic_tick',2),'little')-ticks0;elapsed=600/(clock/(114*lines))
  result=dict(tv=tv,wave=wave//2+1,seconds=round(elapsed,3),logic_ticks=ticks,logic_hz=round(ticks/elapsed,2),renders=renders,render_hz=round(renders/elapsed,2),dropped_ticks=int.from_bytes(e.mem('dropped_ticks',2),'little')-drops0,levels=sorted(levels))
  results.append(result);print(result,flush=True);e.close()
(R/'build/timing-results.json').write_text(json.dumps(results,indent=2))
