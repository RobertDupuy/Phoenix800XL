"""Exercise readable pages, their original attract clock, and screen restore."""
from check import *
import json,hashlib

results=[]
for tv in ['ntsc','pal']:
 e=Emu(tv)
 seen=set();screens=[]
 for frame in range(0,1150,10):
  e.step(10)
  page=e.val('presentation_bank')
  if page and page not in seen:
   # Let the one-time bank copy finish before inspecting video memory.
   e.step(12)
   expected=(R/f'assets/presentation-{page}.bin').read_bytes()
   assert e.mem(0x8000,6144)==expected[:6144],(tv,page,'font data')
   assert e.mem(0x0878,840)==expected[6144+120:],(tv,page,'screen data')
   e.shot(f'v3-{tv}-page-{page}')
   screens.append(page);seen.add(page)
  assert int.from_bytes(e.mem('queue_count',2),'little')<=832
 assert seen=={8,9},(tv,seen)
 assert e.val('presentation_bank')==0,(tv,'demo not restored')
 expected=(R/'assets/game-screen.bin').read_bytes()
 assert e.mem(0x860,672)==expected[96:]
 e.shot(f'v3-{tv}-demo')

 # Credit/start page uses the same font, with no converted arcade lettering.
 e.step(20,select=1);e.step(40)
 assert e.val('presentation_bank')==10
 expected=(R/'assets/presentation-10.bin').read_bytes()
 assert e.mem(0x8000,6144)==expected[:6144]
 e.shot(f'v3-{tv}-page-10')
 e.step(20,select=1);e.step(40)
 assert e.val('presentation_bank')==11
 e.shot(f'v3-{tv}-page-11')
 e.step(20,start=1);e.step(550)
 assert e.val(0x13a2)==1
 assert e.val('presentation_bank')==0
 assert e.mem(0x860,672)==(R/'assets/game-screen.bin').read_bytes()[96:]
 e.shot(f'v3-{tv}-game')
 # Exact arcade GAME OVER wording remains readable after the final life.
 for a,v in {0x13a4:5,0x13a5:0,0x1390:0,0x1391:0}.items():e.cmd(f'queue {a} {v}')
 e.cmd(f'apply {L["logic_tick"]}');e.step(35)
 assert e.val('presentation_bank')==12
 e.shot(f'v3-{tv}-page-12')
 # Game logic changes mode before the next presentation update. Poll the
 # observable transition with a bound instead of requiring both operations
 # to coincide at one arbitrary TV-frame boundary (NTSC needed 202 here).
 for exit_frames in range(1,241):
  e.step(1)
  if e.val(0x13a2)==0 and e.val('presentation_bank') in (8,10,11):break
 else:
  raise AssertionError((tv,'game-over did not return',e.val(0x13a2),
                        e.val(0x13a4),e.val(0x13a5),e.val('presentation_bank')))
 page=e.val('presentation_bank')
 e.step(12) # Finish the one-time font/screen copy after page selection.
 assert e.mem(0x8000,6144)==(R/f'assets/presentation-{page}.bin').read_bytes()[:6144]
 e.close()
 results.append(dict(tv=tv,cartridge_sha256=hashlib.sha256((R/'build/Phoenix-XL.car').read_bytes()).hexdigest(),game_over_exit_tvframes=exit_frames,attract_pages=screens,credit_pages=[10,11],game_over_page=12,credits_page=True,demo_restored=True,game_restored=True,queue_bounded=True))
print(results)
(R/'build/presentation-results.json').write_text(json.dumps(results,indent=2)+'\n')
