# Revision 5 verification — 18 October 2026

This report verifies the sound corrections. The user's indefinite,
direction-dependent input failure remains unresolved. No test below should
be interpreted as proving that reported failure absent.

## Cartridge

- CART type 41, 131,088 bytes including its 16-byte header.
- Raw ROM: 131,072 bytes; stock 64 KiB 800XL RAM; PAL and NTSC; no VBXE.
- CAR SHA-256: `ec6f8cb447201428424a3888986c88c108494c537937c78ec5dd3446fd96c54b`.
- ROM SHA-256: `da01c7edb2997fe23857980dc4b1dd50a846438279f52ccec4bc87e5729c79f3`.
- No diagnostic overlay, invulnerability, forced wave, or stall fixture in
  the cartridge. Fixtures below exist only in the host test harness.

## Sound starvation: before and after

`tests/audio_interrupt.py` replaces foreground execution with a register
sentinel loop while leaving the real VBI and cartridge sound code running.
It observes 240 TV frames on each system. This deliberately imposed stall
tests sound independence; it does **not** reproduce the user's input fault.

| System/build | Sound services | Distinct POKEY states | Distinct music phases |
| --- | ---: | ---: | ---: |
| NTSC revision 4 | 0 | 1 | 1 |
| NTSC revision 5 | 245 | 105 | 240 |
| PAL revision 4 | 0 | 1 | 1 |
| PAL revision 5 | 293 | 113 | 240 |

The new noise envelope completes while foreground execution is stopped.
The sentinel confirms A/X/Y/stack preservation after interrupt return, and
checks all zero-page bytes except the documented private NMI scratch.
A TV-frame boundary can occur inside an interrupt, so register preservation
is observed after return rather than assumed from arbitrary frame-end CPU
snapshots. The running game restores correctly from its pre-test saved state.

The compiled revision-4 sound driver supplies an independent comparison for
2,324 command steps per TV standard, including a complete tune, all 256 A and
B latch values, and seeded transitions. Melody registers, note sequencing,
music/noise envelope state, and active noise output agree in 4,648 comparisons.
The two analog-effect tone channels intentionally differ.

## Continuous effects

`tests/audio_circuit.py` executes the existing sample-domain circuit model at
120 kHz and counts its 555 oscillator transitions. It compares those physical
frequencies with the actual POKEY register output from the compiled cartridge.
Four held A commands and a changing filtered B command are tested on both TV
standards, 700 command steps per case, measuring the final 520 after settling.

Mean pitch differences are 0.80–4.65% in these ten cases. The held A effects
continue modulating; the B effect follows a capacitor-driven pitch sweep.
This is a pitch/behavior comparison, not waveform or analog-filter identity.
Full ranges and quantized divisors are in `results-v5/audio-circuit-results.json`.

## Input and full-game execution

`tests/input_bus_audit.py` traces every PIA write in the old and new cartridges
over all five waves on PAL and NTSC: 30,000 TV frames total. It observes the
boot OS writes separately, verifies the cartridge's final DDR/input setup,
and finds **zero PIA writes during gameplay**. This did not reproduce the
reported missing directional input or identify its cause.

For the new build, the external CPU observer checks 10,412 movement calls
against executable original arcade ROM instructions and 14,765 PM updates
against the graphics-derived expected ship position/pixels. No mismatches
were found. Held directions, reversals, and independently changing fire and
shield inputs are included. The `hw_read_inputs` source is unchanged from
revision 4.

The longest completed sound-service intervals in these full-game traces are
30,388 CPU clocks on NTSC (16.98 ms) and 35,932 on PAL (20.26 ms). There are no
multi-frame sound-service stalls. Completion occasionally crosses a TV-frame
boundary when the work changes; the test measures CPU clocks as well as
frame counters to distinguish this from skipped servicing.

Short foreground rendering stalls remain: the worst observed active input
gap is nine NTSC TV frames or seven PAL TV frames. They self-recover with the
same direction still held. They do not explain the user's reported indefinite
stall that recovers only on input changes.

The full AltirraSDL frontend test sends physical keyboard events, including
direction presses while fire is held and overlapping opposite directions.
All 386 sampled hardware inputs match the requested states on PAL/NTSC. This
Linux test does not replicate an unknown user host/input configuration and
does not establish an emulator cause.

854 sampled game-frame comparisons with the original MAME arcade captures
have zero differences. Normal movement, firing, shield, reset, alternating
two-player banks and return to GAME OVER also pass on both systems.

## Deliverable preview and reproducibility

The preview was regenerated from revision 5 with real emulator video/audio,
including the four presentation pages and all five waves. Stage-selection
fixtures are used only for preview capture. All five wave recordings have
nonzero audio and no clipping (largest sample magnitude 14,157 of 32,768).
Representative gameplay frames were visually inspected.

`results-v5/` contains the new reports, raw PIA-write logs, sampled circuit
reference and hashes. `TEST_REPORT-v4.md`, `results-v4/`, and earlier versioned
reports preserve older evidence. The source package includes the compiled
revision-4 comparison cartridge and ELF at `build/revision4-baseline/`.
Build and test commands are in the README.
