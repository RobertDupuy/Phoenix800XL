# Revision 2 — 18 October 2026

## Readable screens

The title, instructions, score table and start prompt now use an independently
drawn 5×7 alphabet. Four prebuilt pages live in cartridge banks 8 through 11;
the display copies them on page changes and restores the normal character
map for the attract demo and gameplay. The original counters, gameplay RAM
and copyright-checksum text bytes remain intact.

Remaining arcade text uses new 3×5 letters, digits and punctuation in both
graphics banks, arranged for the renderer's six-line vertical sampling.
Playfield colour 1 is a brighter pink. The mothership now explicitly uses
gold armour, pink details and a cyan upper structure; its similar original
gold/lime inks no longer force the hull into the wrong colour. The cartridge still uses five-colour
ANTIC 4 character graphics, standard GTIA player/missile hardware and one
POKEY, with no VBXE or expanded system RAM.

The supplied reference screenshots were considered only for colour contrast
and readable presentation. No code, font or artwork from another Atari port
was copied; the screenshots' author was not independently verified.

## Held-direction fix

The previous cartridge forwarded overlapping left and right pins to the
arcade movement routine. That routine gives left priority, so a stale left
input could mask a newly pressed right indefinitely. Raw-pin tests reproduce
the old failure in both PAL and NTSC: the ship moves left while the new right
request remains held.

The adapter now follows the most recently pressed direction during an
overlap. Both directions pressed initially together produce neutral input.
An ordinary held direction remains level-sensitive and requires no repeat
press. Original fire and shield edge handling, shield duration and movement
lockout are unchanged. Startup also explicitly configures the PIA joystick
pins as inputs instead of inheriting the previous configuration.

This fixes a demonstrated old failure case. The user's particular frontend
was not available, so its connection to that reported symptom is not proven.

## Regression coverage

- `tests/held_controls.py`: both overlap orders, simultaneous neutral input,
  right held across shield lockout and every wave-entry sequence, 12,000 TV
  frames of sustained input on each TV standard, and PIA initialization.
- `tests/presentation.py`: all four prebuilt pages, font/screen data,
  restoration of normal demo and game display, and bounded dirty queues.
- `docs/results/held-controls-baseline.json` records the old failure;
  `held-controls-results.json` and `presentation-results.json` record the
  corresponding revision-2 checks. Full validation is in `TEST_REPORT.md`.

## Remaining limits

Busy large-bird and mothership scenes can run below arcade speed; the measured
logic and redraw rates remain explicit in the test report. POKEY music and
effects retain the original sequences and commands but approximate the analog
arcade circuitry. Verification uses emulation. Physical Atari hardware and
flash-cartridge operation have not been tested.

The build command and outputs are unchanged: `python3 tools/build.py` writes
`build/Phoenix-XL.car` and `build/Phoenix-XL.rom`.
