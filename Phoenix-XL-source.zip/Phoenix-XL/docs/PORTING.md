# Implementation notes

## Arcade logic

The 16 KiB program image is preserved under `reference/`, with a raw address
listing in `phoenix-arcade-z80.asm`. The arcade board uses an 8085-compatible
instruction set; the raw listing uses Z80 mnemonics for the common instructions.
It also decodes embedded tables as instructions. Use the linked annotated
Computer Archeology disassembly to distinguish code from data.

The HHi hand translation supplied the address-annotated C starting point.
The Atari version uses the same 3 KiB state layout, mapped from arcade
`$4000..$4BFF` to Atari `$1000..$1BFF`. Original ROM tables are native constants.
This is compiled 6502 gameplay, not an 8080 interpreter running in the cartridge.

Corrections made while comparing with the original program in MAME:

- The `$0700` player-object loop processes three records: ship and two player
  shots. The inherited C loop processed eleven because it compared the wrong
  point in the pointer increment. This also caused occasional projectile
  overwrites.
- The original updates the high score at the next game start, not on every
  score increment. Its BCD comparison and screen update are retained.
- Score arithmetic explicitly widens intermediate values where the host C
  translation assumed a 32-bit `int`; LLVM-MOS uses a 16-bit `int`.

No difficulty, scoring, enemy-population or collision shortcuts are compiled
into the game. Fixture writes exist only in the external tests.

## Display and sprite allocation

ANTIC mode 4 displays 24 rows. The three HUD rows use normal 40-character
DMA, providing 160 multicolour pixels; the game body uses narrow
32-character DMA with 26 centred game columns. Source gameplay tiles become
four multicolour pixels by six lines; source lines 0, 1, 3, 4, 5 and 7 are
retained. Six dynamic character sets provide four body rows each. DLI changes
select the next set and switch from the wider HUD to the game body's width.

Revision 3 uses five prebuilt 40-column information pages in banks 8–12:
SCORE AVERAGE TABLE, the original bird-built PHOENIX logo, one-credit and
two-credit start prompts, and GAME OVER. Literal text comes from original
program ROM records at `$1800..$1BA0`; independently drawn 5×7 glyphs provide
legibility. Original foreground/background tile maps supply the examples
and title artwork. The score-table labels, values, copyright and start
wording are preserved. No invented HOW TO PLAY, wave/round/shield labels or
replacement slogan remains.

Each page uses six 1 KiB character sets plus a 960-byte screen map. Glyphs
are deduplicated per four-row band. It is copied only when its selection
changes; the original attract counter still determines the table/title/demo
sequence. Complete pages replace the original character-at-a-time reveal.
The 192-line adaptation redistributes blank spacing to fit seven-line text.
GAME OVER uses the original black-background composition for the whole
message interval; the arcade clears the preceding background partway through
that interval. These are presentation adaptations, not gameplay changes.

The shared HUD renders the original 78 foreground cells (26 columns by
three rows) into a 5×7 font at `$1400`. The screen map is at `$0540` and a
source-cell cache at `$0650` skips unchanged characters. Pre-shifted glyph
halves in ROM bank 14 permit six-pixel spacing without runtime rasterization
or division. Original SCORE1 / HI-SCORE / SCORE2 headings, six-digit scores,
spare-ship icons, coin count and score flashes therefore remain authoritative.
The information pages and HUD leave the arcade RAM text untouched, including
copyright bytes checked by the original program.

Small numeric awards within the narrow game body still use compact 3×5
glyphs arranged for the six-line renderer. Full information, start and
GAME OVER screens use the larger font. No code, font or artwork from another
Atari port is used.

The five screen colours are black, cyan, pink, yellow and white. Revision 2
brightens playfield colour 1 to improve contrast. Two ROM banks
hold the two arcade palettes, decoded glyph rows, transparency masks and
star patterns. Colour assignment preserves distinct source inks rather than
merging similar arcade colours into a solid silhouette. Mothership tiles
use explicit cyan/pink/gold roles so the gold armour stays gold when the
original lime and yellow compete for the same Atari colour register.

| GTIA resource | Use |
| --- | --- |
| Player 0 | Original ship silhouette, eight sub-tile phases |
| Players 1 and 2 | Two player-shot slots |
| Missiles 0 through 3 | First four enemy-shot slots |
| Player 3 | Fifth enemy-shot slot |

All seven projectile slots remain available. GTIA collision latches are not
used: the original software collision map is authoritative. Original ship
and projectile tiles remain in collision RAM but are suppressed in the
character renderer. Shield and explosion graphics use the playfield.

## Joystick adapter and ship visibility

Revision 4 polls PIA PORTA (`$D300`) on each original game tick and forwards
the current active-low direction pins directly: bit 2 supplies LEFT, bit 3
supplies RIGHT. There is no previous-direction value, direction-change
detection, last-pressed preference, direction latch or repeat timer. Releasing
a direction removes it on the next poll; holding it keeps it asserted.

Both active pins are forwarded as both arcade input bits. The original
movement routine gives left priority in that case. No adapter-specific
opposite-direction resolver remains. Original fire/shield edge handling and
shield lockout are separate gameplay rules and are unchanged.

Startup explicitly selects the PIA direction register, makes all eight
joystick pins inputs, and restores port-data access. The focused revision-4
checks cover identical current inputs after different input histories,
sustained directions, the actual AltirraSDL frontend and held input across
death/respawn. Broader gameplay, graphics and timing results remain revision-3
evidence; see `TEST_REPORT-v3.md` and `results-v3/`.

A separate, reproducible display error was found: the PM renderer displayed
an intact ship using initialized player coordinates during death, respawn and
formation states that do not run player updates. Player-state `$9C` is not
a reliable death test: bit 7 participates in the original drawing flags.
The corrected visibility gate uses the original game state and wave phase.
P0 is eligible in game states 3, 6 or 7 and active player phases 1, 3, 5, 7
or `$B`; the existing player visibility bit still applies. Death state 4,
respawn/new-round states 0–2, GAME OVER state 5 and formation phases hide P0.
The native routine erases its old pixels and hides its horizontal position.
Original explosion/shield playfield graphics and game state are unaffected.
Hardware projectiles follow the same active phases. During death they remain
visible only until the original foreground clear at CounterA5 = `$20`; all
seven hardware projectile channels then clear through the respawn interval.
This revision-3 display correction remains unchanged in revision 4.

## Performance

The hot coordinate, object drawing, alien movement, animation and bird drawing
routines are native assembly. Small fixed object loops and bird shape writes
are unrolled. Background/foreground/star-only rendering has specialized
unrolled kernels, with a full compositor for overlaps. Lookup tables avoid
division in coordinates, sprite phases and audio.

Foreground damage is deduplicated in a bounded 832-cell queue. Background
writes accumulate in a 104-byte bitset. Final source tiles are cached so an
erase followed by an identical redraw causes no screen repaint. Occupancy
is updated once per affected group at render time. Scrolling damages both old
and new positions; the adjacent tile is needed only for fractional scrolling.

The screen renderer works in batches. The ship and shots update on each
game tick; character animation is less frequent. A fractional accumulator
targets the arcade's 61.03515625 Hz on both PAL and NTSC. Backlog saturates at
eight ticks and counts missed deadlines, preventing wraparound or a delayed
input burst. This preserves update order and per-tick rules, but heavy scenes
still have measurable real-time slowdown. The test report records it.

## Address map

| Atari range | Purpose |
| --- | --- |
| `$0020..$003F` | LLVM-MOS virtual registers |
| `$00C0..$00E7`, `$00F0..$00FD` | Renderer/assembly scratch |
| `$00E8` | DLI character-bank state |
| `$00E9..$00EA` | Private interrupt sound pointer/multiply scratch |
| `$0200..$053F`, `$0C00..$0F3F` | Dirty queue low/high bytes |
| `$0540..$05B7` | 40-column HUD screen map |
| `$0600..$064D` | Display list |
| `$0650..$069D` | HUD source-cell cache |
| `$0700` | Temporary boot loader |
| `$0800..$0AFF` | Normal game character screen |
| `$0800..$0BBF` | Information-page screen; temporarily overlaps BG cache |
| `$0B00..$0BFF`, `$1E00..$1FFF`, `$1D80..$1DBF` | Last rendered background tile IDs |
| `$1000..$1BFF` | Active arcade RAM bank |
| `$1400..$17FF` | HUD font in original unused RAM padding |
| `$1C00..$1C7F` | Platform variables, linker bounded |
| `$1C80..$1CE7` | Background occupancy bitset |
| `$1D00..$1D67` | Pending background writes |
| `$2000..$7DFF` | Main native code |
| `$7E00..$7FFF` | Software stack |
| `$8000..$97FF` | Six dynamic character sets |
| `$9800..$9FFF` | Single-line player/missile DMA area |
| `$A000..$BFEF` | Banked ROM window |
| `$C000..$CBFF` | Other player's arcade RAM bank |
| `$C400..$C73F` | Foreground cache in unused other-bank padding |
| `$CC00..$CF3F` | Dirty flags |
| `$D800..$FFEF` | Platform code and lookup tables under the OS |
| `$FFFA..$FFFF` | Interrupt and reset vectors |

The game disables OS/BASIC ROM after boot. Full redraw and font reload repair
the borrowed padding when player banks swap. Leaving an information page
restores the 32-column body map and forces a full redraw, rebuilding the
background cache overwritten by the wider page.

## Cartridge layout

Sixteen 8 KiB AtariMax banks form exactly 128 KiB. Bank 0 contains gameplay
constants; banks 1 and 2 contain decoded animation graphics and masks. Banks
3 through 7 contain packed RAM code. Banks 8–12 contain, respectively, the
score table, title, one-credit prompt, two-credit prompt and GAME OVER page.
Bank 14 contains the initial HUD font, restored game screen map, HUD screen
map, shifted glyphs and pointers. Bank 15 contains the boot stub, page records
and relocatable loader. Bank 13 remains reserved. Every bank has a safe
startup footer. RAM code is copied in 256-byte pages, avoiding the footer.
No cartridge RAM is assumed.

## Sound

The original command dispatcher and latches are retained. Offline generation
uses the MAME-derived discrete circuit model to derive tone-divider tables,
and the original MM6221AA/TMS36xx tune note sequences for music. Two POKEY
channels carry music; the other two carry effects, with noise priority for
explosions and shield sounds. Envelopes and noise are approximations. PAL and
NTSC use separate precomputed divider tables.

## Test boundaries

Game-RAM comparison invokes a native game tick using an original MAME state,
including the original counter/input update. It compares gameplay and video
RAM; it is not a video or analog-audio equivalence proof. The 8085 stack is
excluded. During bird waves, the unused former alien-history tail is also
excluded because the original CPU uses it as stack space. Renderer tests
independently compare incremental character data with complete recomposition
of a quiescent identical game state.

`tests/presentation.py` checks the five information pages, original attract
transition back to demo, one/two-credit prompts, GAME OVER, game-map
restoration and the dirty-queue bound. `tests/hud_parity.py` compares native
replacement/erasure of adjacent source characters with the independent
font composer and verifies the original foreground RAM is unchanged.

`tests/held_controls.py` supplies raw direction-pin levels to bypass the
Atari800 frontend's opposite-direction filter. Revision 4 verifies that
identical current pins produce identical direction bits regardless of prior
input, both active pins are both forwarded, and release removes the relevant
bit. It also covers shield recovery without a new direction edge,
all five wave-entry paths, 12,000 TV frames per held direction on each TV
standard
and recovery from an intentionally misconfigured PIA direction register.
These raw-pin checks do not reproduce a desktop keyboard frontend.

`tests/pm_visibility.py` checks actual P0 DMA bytes and the GTIA position
register across phases/states, then holds right continuously through a real
death and respawn to verify recovery without a new press.

`tests/altirra_keyboard.py` instead sends scripted SDL keyboard events through
the full AltirraSDL frontend. It records PORTA and the arcade input byte
through repeated direction/fire changes, deaths, respawns and opposite-key
transitions, together with emulator/cartridge hashes. Its Linux host and
profile describe the tested environment. The report records the tested
cartridge hash and distinguishes completed input polls from samples taken
before a game tick reaches the polling routine.
Physical Atari and flash-cartridge testing remains outstanding.
