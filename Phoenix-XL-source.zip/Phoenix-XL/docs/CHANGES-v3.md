# Revision 3 — 18 October 2026

## Original arcade text and presentation

Revision 2's invented information pages did not meet the requested arcade
presentation. They have been removed. The new pages read the original ROM's
literal text records and retain its graphics and composition:

- SCORE1 / HI-SCORE / SCORE2, both scores, spare ships and COIN count.
- INSERT COIN, one/two-player coin prices, SCORE AVERAGE TABLE, original
  numeric awards and the original bird examples.
- The large PHOENIX artwork built from the arcade's bird tiles.
- PHOENIX copyright, AMSTAR ELECTRONICS CORP. and PHOENIX AZ. U.S.A.
- PUSH / ONLY 1PLAYER BUTTON, or 1 OR 2PLAYERS BUTTON with two credits.
- GAME OVER and its original copyright lines.

Independently drawn 5×7 letters use a six-pixel advance. Forty-column ANTIC 4
provides enough width for all 26 arcade character positions. Gameplay keeps
its 32-column body; its three HUD rows use the same wider readable font.
The HUD reads original foreground cells and preserves score flashing. No
wave/round/shield overlay or HOW TO PLAY page remains.

The five page assets are precomputed in ROM banks 8–12. The source manifest
records ROM addresses, exact text bytes and adapted line positions. The
original title and score illustrations come from the arcade graphics ROM,
not another Atari port. Pages appear fully composed instead of typing each
character; line spacing fits 192 scanlines. GAME OVER uses a black backdrop
throughout, rather than clearing the previous background midway through.
Original game logic and the copyright-checksum RAM remain unchanged.

## Control investigation and a confirmed display fix

The user reported repeated left/right stalls in Altirra that appeared to
require a release and new press. Revision 2 addressed a raw opposing-pin
case, but the tested Altirra frontend neutralizes simultaneous left/right
before the PIA sees them. That earlier test did not establish the cause of
the user's report.

This investigation exercised the actual AltirraSDL core and its full desktop
input path. Scripted SDL physical keyboard events went through the normal
frontend/input manager, with PIA and arcade input bytes sampled during held
directions, fire changes and game-state transitions. No dropped direction
level was reproduced in those runs. The original movement routine remains
level-based; no repeat press is required by that routine.

A visible-state bug was reproduced. The hardware renderer kept displaying
an intact player ship during the original death/respawn states, and also
displayed it during initial formations before player updates began. The
ship looked available to control while the underlying game was in a death,
respawn or formation delay. P0 now requires both a living player state and
an active gameplay phase. Original explosions and shields remain in the
character playfield.

Stale hardware bullets also clear when the original death sequence clears
its foreground, and remain hidden during respawn and formation delays.

**This is a confirmed ship-visibility correction, not a confirmed resolution
of the user's entire release/repress symptom.** The frontend tests ran under
Linux AltirraSDL, not the user's exact OS, version, keyboard settings or input
profile. Further evidence is needed if the symptom persists in this build.

## Verification and limits

The report distinguishes native/arcade-RAM parity, page/font checks, raw-pin
controls and actual AltirraSDL frontend tests. Source scripts and captured
results are included. The Altirra test records emulator and cartridge hashes
so a result can be tied to the tested binaries. See `TEST_REPORT.md` for the
checks actually recorded for this revision.

Busy large-bird and mothership scenes still have measurable slowdown. POKEY
music/effects preserve original sequences and commands while approximating
the analog circuitry. Physical Atari hardware and flash-cartridge operation
have not been tested. The 128 KiB cartridge, stock 64 KiB RAM, five-colour
character graphics and no-VBXE target remain unchanged.
