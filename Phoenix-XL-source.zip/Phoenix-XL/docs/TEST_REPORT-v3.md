# Verification report — revision 3

Revision-3 emulator checks recorded on 18 October 2026. Physical Atari hardware and flash-cartridge operation remain untested. Prior-release evidence is identified separately.

**The user's repeated Altirra release/repress symptom is not confirmed resolved.** A separate ship-visibility bug was reproduced and corrected. The original movement routine remains level-sensitive; test results below are limited to the input paths and configurations actually exercised.

## Results

- **1,400 native-routine comparisons passed** against the host reference C implementation, using deterministic randomized states.
- **854 sampled game-frame comparisons passed** against original MAME RAM captures, without differences in the compared ranges. The set covers all five waves, the mothership ending and the next round.
- **40 incremental-render comparisons passed** against complete redraws of identical quiescent states.
- **PAL and NTSC controls passed:** movement, edge-triggered firing, shield activation, warm reset, two credits, two-player start, both player RAM banks and return to attract mode after game over.
- **Raw-pin held-input regression passed on PAL and NTSC:** 12,000 TV frames per standard with a continuously held right request, both overlap orders, simultaneous neutral input, shield recovery, all five wave-entry paths and PIA initialization. These tests bypass the emulator frontend.
- **Revision-2 overlap evidence remains a separate case:** the previous cartridge moved left when right was pressed while the left pin remained low. Its resolver follows the newest direction press. The tested Altirra frontend instead neutralizes opposing keys before PORTA; the raw-pin result did not establish the cause of the user's report.
- **Arcade-presentation checks passed on PAL and NTSC:** banks 8/9 show the original score table/title, 10/11 show one/two-credit prompts, and 12 shows GAME OVER. Font/screen data, return to the demo, game-map restoration and the dirty-queue bound were checked.
- **16 wave/round scenarios ran:** the five first-round wave types and opening waves in rounds 2, 3 and 7 on both TV standards. Scores and life loss were observed.
- **Mothership completion fixture passed:** an exposed pilot and colliding bullet produced the original explosion, a 3,800-point award and round 2. This is a collision fixture, not an unassisted human playthrough.
- **Audio capture passed:** all five wave clips contained non-silent 44.1 kHz, mono, 16-bit emulator output without digital clipping. This does not establish analog-sound equivalence.
- **Actual AltirraSDL frontend check passed:** 386 samples on PAL/NTSC received the expected PIA direction levels through scripted SDL keyboard-down/up events and the normal frontend/input manager. Repeated fire changes, deaths/respawns and opposite-key transitions produced no detected direction loss in this run. The recorded cartridge hash matches this build. The Linux host/profile differs from the user's setup; this is not a confirmed resolution of their symptom.
- **Native HUD composition passed:** 936 source-cell comparisons and 12 unchanged redraws verified adjacent 5×7 character replacement/erasure and preservation of original foreground RAM, including the source of scores and score flashes.
- **Ship visibility/held-direction transition checks passed on PAL and NTSC:** a direction remained held across death and respawn, movement resumed without a new press, and initialized/respawning ship coordinates no longer produced an intact hardware ship during noninteractive phases. Native visibility cases are recorded in `pm-visibility-results.json`; the cartridge hash matches this build.
- **Confirmed visibility correction:** an intact hardware ship was displayed during original death/respawn states or before its formation enabled player updates. P0 now checks the original game state and active player phases. Player-state bit 7 is an original drawing flag, not a standalone death test. This corrects a misleading visible ship during intentional death/respawn/formation delays; it does not prove a general input fix.
- **Revision-3 asset regeneration was identical:** generated graphics, readable pages, kernels, PM data, HUD assets and sound tables reproduced their checked-in hashes.
- **Revision-3 clean source rebuild passed:** a fresh package directory produced a byte-for-byte identical cartridge.
- **Bundled test-toolchain evidence is from the initial release:** packaged Atari800 test sources rebuilt successfully, and the compressed MAME fixture/host reference repeated parity checks. The emulator is an external test dependency, not cartridge code.
- **Cartridge checks passed:** exact 128 KiB payload, CART type 41, valid payload checksum and identical raw/headered payloads.

Current cartridge SHA-256: `7189b1b9ad2dee96bc819b216f1599f30f49510555f9370c474da3ca54816967`.

The MAME comparison excludes the original CPU stack at `$4BF0..$4BFF`; bird phases also exclude unused former alien-history bytes `$4BD8..$4BEF` used by that stack. Other phase data and video RAM are compared. Native-routine checks compare all 3,072 state bytes. These sampled comparisons do not prove equivalence for every input history.

## Revision-3 timing measurements

These measurements use the current revision-3 cartridge.

Each row covers a scripted 600-TV-frame interval after entering its wave while moving and firing. Workload/input sampling vary with timing; these are representative runs, not worst-case guarantees. Rates slightly above 61 reflect backlog at interval boundaries.

| TV | Wave | Logic updates/s | Character redraws/s | Missed tick deadlines |
| --- | --- | ---: | ---: | ---: |
| NTSC | 1 | 61.12 | 10.79 | 0 |
| NTSC | 2 | 61.02 | 15.48 | 0 |
| NTSC | 3 | 47.34 | 5.99 | 137 |
| NTSC | 4 | 44.34 | 5.59 | 162 |
| NTSC | 5 | 47.84 | 9.59 | 125 |
| PAL | 1 | 61.16 | 12.80 | 0 |
| PAL | 2 | 61.08 | 16.12 | 0 |
| PAL | 3 | 51.77 | 13.79 | 113 |
| PAL | 4 | 50.28 | 13.46 | 134 |
| PAL | 5 | 51.86 | 7.56 | 114 |

The target is 61.035 logic updates/s. Lower measured rates indicate real-time slowdown; busy bird and mothership scenes remain a limitation. Hardware players/missiles update each game tick, while the character field updates at the separately measured rate. No claim of cycle-perfect arcade speed is made.

## Reproduction and evidence

Scripts are in `tests/` and recorded results in `docs/results/`. Original MAME captures are included as compressed RAM plus frame metadata. `tools/mame_allwaves.lua` records its stage/exposed-core fixtures explicitly. MAME 0.264 generated the capture. Most Atari checks use the included instrumented Atari800 7.2.1 with the Altirra replacement OS; that is distinct from the actual AltirraSDL frontend test.

`tests/altirra_keyboard.py` requires an AltirraSDL executable with test-mode support selected using `ALTIRRA_SDL`. It sends keyboard events, not direct joystick-memory writes, through the full frontend. Its JSON records emulator/cartridge hashes, sampled PORTA and arcade input bytes. It does not reproduce the user's exact OS, keyboard settings or input profile.

`held-controls-baseline.json` preserves the previous raw-pin overlap failure. `held-controls-results.json` deliberately bypasses opposite-direction filtering. Its long run spans multiple game states and does not assert ship movement during original shield, formation, death or respawn lockouts.

`presentation-results.json` covers five original-content pages. `assets/presentation-manifest.json` records the exact program-ROM text bytes and adapted positions; `arcade-presentation-vram.bin` contains visible original foreground/background tile IDs. The shared HUD uses those original foreground cells, including score flashing. No invented instructions, wave/round/shield labels, or artwork from another Atari port remain.

Presentation adaptations are explicit: the original character-by-character reveal becomes complete static pages, line spacing fits 192 scanlines, and GAME OVER has a black background throughout its interval. Original text remains in arcade RAM for copyright checks.

The ROM disassembly/chip manifest, build instructions, known performance limitations and sound/display adaptations are included in the source package.
