# Revision 5 — independent sound clock and continuous effects

Two sound defects were established in the released revision 4:

1. `audio_tick` ran only from the foreground loop. Busy rendering held its
   POKEY registers and stopped music/noise envelopes for multiple TV frames.
2. The effect conversion reduced a time-varying analog circuit to one FFT
   peak for each command. An unchanged sound command could therefore become
   an indefinitely constant high tone even while the game kept running.

Revision 5 moves the audio driver into the vertical-blank interrupt, driven
by the existing 61.03515625 Hz fractional clock. It advances even when the
game backlog is full. Assembly avoids re-entering C and touching its virtual
registers, software stack, renderer scratch, or cartridge bank. The handler
saves X/Y; its existing NMI frame saves A/status. Audio owns E9/EA and its own
BSS. A bounded five-step multiply handles the circuit lookup arithmetic.

The original 555 oscillator duty cycles, capacitor selections, RC targets,
and divider values now drive continuously evolving effect pitches. Effect A
retains both slow oscillator phases and the C22 state. Its fastest oscillator
is averaged at the low service rate. Effect B retains the C7 charge state.
The values are derived from the MAME circuit description shipped in
`reference/phoenix_a.cpp`, using small generated fixed-point tables. They are
still a POKEY arrangement with quantized pitches and approximate filtering,
not an exact analog waveform reconstruction.

The old melody sequences and noise-envelope behavior are retained. Effect A
now obeys its half-amplitude selector. Effect B's filter bit selects a quieter
tone instead of the old incorrect noise distortion.

The foreground's shared `game_due` decrement is now one 6502 `DEC` instruction.
The previous compiled load/decrement/store sequence could overwrite a VBI
increment. This small timing race did not explain the reported persistent
direction-dependent fault.

No joystick or original gameplay rule was rewritten. The current-level
`hw_read_inputs` function is byte-for-byte unchanged at source level. No
direction-change detector, latch, repeat timer, or automatic direction guess
has been added. The cartridge is a normal game build without the diagnostic
overlay or any test fixture.

## Remaining control fault

The user's saved screenshot reads `CAP FF`, `PFF`, `SEF`, `INEF`, `GS03`,
`LV01`, `PS9C`, `X8D`, `F00`, `SAV`. Its saved raw PORTA and converted input
contain no left/right direction; fire is active in the converted byte. The
recorder retained those readings while gameplay continued.

The recorder also saves a deliberate no-direction interval after a previous
hold. Consequently this picture cannot establish whether that saved interval
was the physical held-key failure. `WHY NO INPUT` classifies the byte; it is
not an explanation of the cause. The later live counters also cannot prove
what was running at the exact time the user first noticed the problem.

Autonomous tests have not reproduced a failure that remains indefinitely
until direction changes. A complete PIA-write audit of old and new builds
found no gameplay port reconfiguration. The original movement and PM checks
also pass in the tested sessions. Those results do not invalidate the user's
report, establish an emulator fault, or demonstrate a control fix.

Rendering still causes short movement/polling gaps in busy scenes (up to nine
NTSC TV frames in this run). They recover with the direction unchanged and
are distinct from the reported indefinite failure. Sound now continues during
those gaps.
