# Verification report — revision 4

Revision 4 removes direction-change detection and remembered direction preferences. Each game tick reads current active-low PORTA pins and directly supplies the original LEFT/RIGHT input bits. It has no direction history, latch, edge requirement or repeat timer. Both active pins are forwarded; the original movement routine gives left priority.

Cartridge SHA-256: `2ff138c75dafef103963094558db78721ee95cbcb147f57d2231c2a1daec4a69`.

## Focused revision-4 checks

- **Direct polling confirmed in source and disassembly:** the adapter reads `$D300`; `previous_directions`, `last_direction` and their transition/resolution logic are removed. Evidence is in `input-polling-results.json` and `input-polling-disassembly.txt`.
- **History-independent input passed on PAL and NTSC:** four different preceding pin states produce the same pair of active direction bits when both current pins are low. Single directions and releases follow their current levels.
- **48,000 TV frames of held-input checks passed:** 12,000 per direction on each TV standard, plus shield recovery, all five wave-entry paths and explicit PIA initialization.
- **Normal controls passed on PAL and NTSC:** left/right movement, firing, shield activation, reset, credit/start handling, alternating player banks and return to attract mode.
- **Actual AltirraSDL frontend checks passed:** 386 keyboard-routing samples, including 381 samples after completed input polls, recorded no lost direction input. Scripted SDL key events traversed the normal frontend/input manager; both PORTA and the arcade input byte were checked. The emulator and cartridge hashes are recorded.
- **Held direction survived death/respawn on both TV standards:** movement resumed without releasing/repressing right. The same run checked 88 native ship-visibility cases and 182 projectile-visibility cases.
- **Cartridge structure passed:** 128 KiB raw image, CART type 41, matching checksum and identical headered/raw payloads.
- **Clean source rebuild passed:** a fresh package directory produced a byte-for-byte identical revision-4 cartridge.

The Altirra test runs on Linux through the full frontend. It distinguishes current hardware levels from an arcade input byte that has not yet reached its next game-tick poll. This is polling on game ticks, not on every television frame. Existing rendering or original game-state delays can postpone a poll.

## Retained revision-3 evidence

This revision changes horizontal input adaptation only. Full arcade/native parity, all-wave scenarios, presentation/HUD composition, renderer comparisons, sound capture, asset regeneration and timing were not rerun for this focused change. Their completed revision-3 evidence is preserved in `TEST_REPORT-v3.md` and `results-v3/`; it is not presented as new revision-4 testing.

The revision-3 report includes 1,400 native comparisons, 854 MAME frame comparisons, 40 renderer comparisons, five original-content information pages, 936 HUD cell checks, 16 wave/round scenarios and mothership completion. Its timing measurements continue to describe the known busy-scene slowdown, not a new revision-4 benchmark.

`Phoenix-XL-preview.mp4` remains the revision-3 capture. The input-only revision retains its graphics, original arcade text, sound and PM visibility corrections.

## Reproduction and limits

Run `tests/controls.py`, `tests/held_controls.py`, `tests/pm_visibility.py` and `tests/altirra_keyboard.py` after building. The first three use the bundled Atari800 test harness. The Altirra test requires `ALTIRRA_SDL` to select an AltirraSDL executable with test-mode support. Result JSON and the inspected input disassembly are included under `docs/results/`.

Original fire/shield edge handling, shield lockout and noninteractive formation/death/respawn states remain original gameplay rules. No horizontal direction-change logic remains in the adapter.

Physical Atari and flash-cartridge operation remain untested. Busy scenes still have measured slowdown, and POKEY effects/music approximate the arcade analog sound.
