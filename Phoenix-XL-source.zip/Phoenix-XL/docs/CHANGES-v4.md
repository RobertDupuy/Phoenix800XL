# Revision 4 — direct joystick polling

Left and right now come directly from the current PIA PORTA pins on every
game tick. All previous-direction tracking and last-pressed resolution have
been removed. Direction has no change detector, edge requirement, latch or
repeat timer.

A held direction remains active at every poll. Releasing it clears that
input on the next poll. If both physical pins are active, both direction bits
reach the original arcade movement routine; its original left priority
applies. Fire and shield retain their separate original gameplay rules.

This is an input-only cartridge change. Revision 3's readable original
arcade text/screens, HUD, ship/projectile visibility, sound and game logic
remain in place. The existing preview video is the revision-3 capture.

Focused validation checks direct, history-independent raw-pin mapping,
12,000 TV frames per direction on each of PAL/NTSC (48,000 total),
shield/formation transitions,
normal controls, full AltirraSDL keyboard routing, and held input through
death/respawn. The current report records completed checks and the cartridge
hash. Broader full-wave, text, renderer, audio and performance evidence is
preserved as revision-3 evidence in `TEST_REPORT-v3.md` and `results-v3/`.

Physical Atari and flash-cartridge operation remain untested. Existing busy
scene slowdown and approximate POKEY timbre are unchanged.
